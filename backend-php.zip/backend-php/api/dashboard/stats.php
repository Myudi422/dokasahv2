<?php
// backend-php/api/dashboard/stats.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit(); }

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../helpers/jwt.php';
    require_once __DIR__ . '/../../middleware/auth.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server config error: ' . $e->getMessage()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$admin = requireAdmin();

try {
    $pdo    = getDB();
    $stmt   = $pdo->query("
        SELECT 
            COUNT(fc.id) AS total,
            SUM(CASE WHEN COALESCE(fs.status, 'draft') = 'draft' THEN 1 ELSE 0 END) AS draft,
            SUM(CASE WHEN fs.status = 'submitted' THEN 1 ELSE 0 END)                AS submitted,
            SUM(CASE WHEN fs.status = 'proses'    THEN 1 ELSE 0 END)                AS proses,
            SUM(CASE WHEN fs.status = 'review'    THEN 1 ELSE 0 END)                AS review,
            SUM(CASE WHEN fs.status = 'selesai'   THEN 1 ELSE 0 END)                AS selesai
        FROM form_configurations fc
        LEFT JOIN form_submissions fs ON fc.id = fs.form_config_id
    ");
    $counts = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'counts'  => [
            'total'     => (int)$counts['total'],
            'draft'     => (int)$counts['draft'],
            'submitted' => (int)$counts['submitted'],
            'proses'    => (int)$counts['proses'],
            'review'    => (int)$counts['review'],
            'selesai'   => (int)$counts['selesai'],
        ],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
