<?php
// backend-php/api/forms/list.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit(); }

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../helpers/jwt.php';
    require_once __DIR__ . '/../../middleware/auth.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server config error: ' . $e->getMessage()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$currentUser = requireAuth();

try {
    $pdo = getDB();

    if ($currentUser['role'] === 'admin') {
        $stmt = $pdo->prepare("
            SELECT 
                fc.id, fc.form_type, fc.assigned_email, fc.slug, fc.note, fc.created_at,
                COALESCE(fs_struct.label, fc.form_type) AS form_label,
                fs_sub.status,
                fs_sub.updated_at AS last_updated
            FROM form_configurations fc
            LEFT JOIN form_structures fs_struct ON fc.form_type = fs_struct.form_type
            LEFT JOIN form_submissions fs_sub ON fc.id = fs_sub.form_config_id
            ORDER BY fc.created_at DESC
        ");
        $stmt->execute([]);
    } else {
        $stmt = $pdo->prepare("
            SELECT 
                fc.id, fc.form_type, fc.assigned_email, fc.slug, fc.note, fc.created_at,
                COALESCE(fs_struct.label, fc.form_type) AS form_label,
                fs_sub.status,
                fs_sub.updated_at AS last_updated
            FROM form_configurations fc
            LEFT JOIN form_structures fs_struct ON fc.form_type = fs_struct.form_type
            LEFT JOIN form_submissions fs_sub ON fc.id = fs_sub.form_config_id
            WHERE fc.assigned_email = ?
            ORDER BY fc.created_at DESC
        ");
        $stmt->execute([$currentUser['email']]);
    }

    $forms = array_map(function ($form) {
        return [
            'id'             => (int)$form['id'],
            'form_type'      => $form['form_type'],
            'form_label'     => $form['form_label'],
            'assigned_email' => $form['assigned_email'],
            'slug'           => $form['slug'],
            'note'           => $form['note'],
            'status'         => $form['status'] ?? 'draft',
            'link'           => "https://dokasah.web.id/form/{$form['slug']}",
            'created_at'     => $form['created_at'],
            'last_updated'   => $form['last_updated'],
        ];
    }, $stmt->fetchAll());

    echo json_encode(['success' => true, 'forms' => $forms, 'total' => count($forms)]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
