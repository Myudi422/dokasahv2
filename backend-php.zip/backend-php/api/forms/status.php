<?php
// backend-php/api/forms/status.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit(); }

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../helpers/jwt.php';
    require_once __DIR__ . '/../../middleware/auth.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server config error: ' . $e->getMessage()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$admin = requireAdmin();
$body  = json_decode(file_get_contents('php://input'), true) ?? [];
$slug  = trim($body['slug'] ?? $_GET['slug'] ?? '');
$status = trim($body['status'] ?? '');
$validStatuses = ['draft', 'submitted', 'proses', 'review', 'selesai'];

if (!$slug || !$status || !in_array($status, $validStatuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Slug dan status valid wajib disertakan.']);
    exit();
}

try {
    $pdo  = getDB();
    $stmt = $pdo->prepare('SELECT id FROM form_configurations WHERE slug = ? LIMIT 1');
    $stmt->execute([$slug]);
    $form = $stmt->fetch();

    if (!$form) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Formulir tidak ditemukan.']); exit(); }

    $stmt = $pdo->prepare("UPDATE form_submissions SET status = ?, updated_at = NOW() WHERE form_config_id = ?");
    $stmt->execute([$status, $form['id']]);

    if ($stmt->rowCount() === 0) {
        $stmt = $pdo->prepare("INSERT INTO form_submissions (form_config_id, data, status, updated_at) VALUES (?, '{}', ?, NOW())");
        $stmt->execute([$form['id'], $status]);
    }

    echo json_encode(['success' => true, 'message' => "Status berhasil diubah ke '$status'."]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
