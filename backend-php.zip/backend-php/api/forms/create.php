<?php
// backend-php/api/forms/create.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit(); }

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../helpers/jwt.php';
    require_once __DIR__ . '/../../middleware/auth.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server config error: ' . $e->getMessage()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$admin = requireAdmin();

$body     = json_decode(file_get_contents('php://input'), true) ?? [];
$email    = trim($body['email'] ?? '');
$formType = trim($body['formType'] ?? '');
$note     = trim($body['note'] ?? '');

if (!$email || !$formType) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email dan jenis formulir wajib diisi.']);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Format email tidak valid.']);
    exit();
}

try {
    $pdo = getDB();

    $stmt = $pdo->prepare('SELECT form_type, label FROM form_structures WHERE form_type = ? LIMIT 1');
    $stmt->execute([$formType]);
    $formStructure = $stmt->fetch();

    if (!$formStructure) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Jenis formulir tidak valid.']);
        exit();
    }

    $slug = generateSlug($pdo);

    $stmt = $pdo->prepare(
        'INSERT INTO form_configurations (form_type, assigned_email, slug, note, created_by, created_at, updated_at) 
         VALUES (?, ?, ?, ?, ?, NOW(), NOW())'
    );
    $stmt->execute([$formType, $email, $slug, $note, $admin['id']]);

    $formId = $pdo->lastInsertId();
    $link   = "https://dokasah.web.id/form/$slug";

    echo json_encode([
        'success'   => true,
        'message'   => 'Formulir berhasil dibuat.',
        'form_id'   => (int)$formId,
        'slug'      => $slug,
        'link'      => $link,
        'form_type' => $formStructure,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal membuat formulir: ' . $e->getMessage()]);
}

function generateSlug(PDO $pdo): string {
    do {
        $slug = bin2hex(random_bytes(8));
        $stmt = $pdo->prepare('SELECT id FROM form_configurations WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
    } while ($stmt->fetch());
    return $slug;
}
