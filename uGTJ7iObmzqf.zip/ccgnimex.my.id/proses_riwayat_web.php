<?php
// Start the session
session_start();

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Menentukan jumlah data per halaman
$limit = 9; // jumlah data per halaman untuk desktop
if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobi/', $_SERVER['HTTP_USER_AGENT'])) {
    // Jika user agent mengandung kata "Mobi", asumsikan pengguna menggunakan perangkat mobile
    $limit = 6; // jumlah data per halaman untuk mobile
}

// Menentukan halaman yang aktif
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Menghitung offset data
$offset = ($page - 1) * $limit;

$sql = "SELECT anime_id, MAX(episode_number) as episode_number, MAX(video_time) as video_time FROM waktu_terakhir_tontonan WHERE telegram_id = " . $_SESSION['telegram_id'] . " GROUP BY anime_id ORDER BY MAX(id) DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Create an array of anime IDs, episode numbers, and video times
    $anime_data = [];
    while ($row = $result->fetch_assoc()) {
        $anime_data[] = [
            'id' => $row["anime_id"],
            'episode_number' => $row["episode_number"],
            'video_time' => $row["video_time"]
        ];
    }

    // Extract the anime IDs into a separate array
    $anime_ids = array_column($anime_data, 'id');

    // Modify the GraphQL query to accept an array of IDs
    $query = '
    query ($ids: [Int]) {
      Page {
        media(id_in: $ids, type: ANIME) {
          id
          title {
            romaji
          }
          coverImage {
            large
          }
        }
      }
    }
    ';

    // Set the variables for the query
    $variables = [
        'ids' => $anime_ids
    ];

    // Send the API request and process the response as before
    $url = 'https://graphql.anilist.co';
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode([
                'query' => $query,
                'variables' => $variables
            ])
        ]
    ];
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $data = json_decode($response, true);

    // Process the API response and display the anime data in a grid format as before
    $max_columns = 9; // jumlah maksimum kolom per baris untuk desktop
    if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobi/', $_SERVER['HTTP_USER_AGENT'])) {
        // Jika user agent mengandung kata "Mobi", asumsikan pengguna menggunakan perangkat mobile
        $max_columns = 3; // jumlah maksimum kolom per baris untuk mobile
    }
    $current_column = 0; // kolom saat ini

    echo "<table><tr>";

    // Use the media data from Anilist for display
    $media_data = $data['data']['Page']['media'];

    // Create an array to store the sorted media data
    $sorted_media_data = [];

    // Loop through the anime data from the database
    foreach ($anime_data as $anime) {
        // Find the corresponding media data from Anilist
        $media = array_filter($media_data, function ($media) use ($anime) {
            return $media['id'] == $anime['id'];
        });

        // Add the media data to the sorted array
        if (!empty($media)) {
            $sorted_media_data[] = array_values($media)[0];
        }
    }

    // Use the sorted media data for display
    $media_data = $sorted_media_data;

foreach ($media_data as $media) {
    $title = $media['title']['romaji'];
    if (strlen($title) > 24) {
        $title = substr($title, 0, 21) . '...';
    }

    // Find the corresponding anime data from the database
    $anime = array_filter($anime_data, function ($anime) use ($media) {
        return $media['id'] == $anime['id'];
    });

    // Get the episode number and video time from the anime data
    $episode_number = !empty($anime) ? array_values($anime)[0]['episode_number'] : 1;
    $video_time = !empty($anime) ? array_values($anime)[0]['video_time'] : 0;

    $animeId = $media['id'];

    // Convert the video time to minutes and seconds
    $minutes = floor($video_time / 60);
    $seconds = floor($video_time % 60);

    echo "<td>
    <div style='position: relative;'>
        <a href='https://ccgnimex.my.id/streaming.php?id=" . $media["id"] . "&episode=" . $episode_number . "'>
            <img loading='lazy' src='" . $media['coverImage']['large'] . "'>
            <div style='position: absolute; top: 8px; left: 8px; background-color: rgba(0, 0, 0, 0.5); color: white; padding: 2px 4px; border-radius: 3px; font-size: 12px;'>$minutes:$seconds</div>
            <span>" . $title . "</span>
        </a>
        <div class='delete-icon' onclick='deleteAnime($animeId)' style='position: absolute; top: 33px; right: 8px; z-index: 2; background-color: rgba(0, 0, 0, 0.5); color: white; padding: 2px 4px; border-radius: 3px; font-size: 9px;'><i class='fas fa-trash'></i> Hapus</div>
        <div style='position: absolute; top: 8px; right: 8px; background-color: rgba(0, 0, 0, 0.5); color: white; padding: 2px 4px; border-radius: 3px; font-size: 12px;'>Eps $episode_number</div>
    </div>
</td>";

    // Cek apakah jumlah kolom sudah mencapai batas maksimum
    if (++$current_column >= $max_columns) {
        // Jika ya, tambahkan baris baru dan reset kolom saat ini
        echo "</tr><tr>";
        $current_column = 0;
    }
}
    echo "</tr></table>";

    // Hitung jumlah total halaman
    $sql = "SELECT COUNT(DISTINCT anime_id) as total FROM waktu_terakhir_tontonan WHERE telegram_id = " . $_SESSION['telegram_id'];
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $total_pages = ceil($row['total'] / $limit);

    // Cek apakah pengguna berada di halaman terakhir
    if ($page >= $total_pages) {
        // Jika ya, nonaktifkan tombol next
        echo '<script>document.querySelector(".next-button1").setAttribute("disabled", "disabled");</script>';
    }
} else {
    echo '<div class="text-center mt-3">';
    echo '<p><i class="fas fa-clock"></i> <strong>Belum ada anime yang kamu tonton. (tandai ceklis di episode anime ketika menonton, agar muncul animenya)</strong></p>';
}
$conn->close();
?>
