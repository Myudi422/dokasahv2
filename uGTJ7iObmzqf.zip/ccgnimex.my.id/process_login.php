<?php
// Start the session
session_start();

// Import database connection and class
require('db-config.php');

// Ambil data dari form
$email = $_POST['email'];
$password = $_POST['password'];

// Lakukan validasi atau sanitasi data jika diperlukan

// Buat query untuk memverifikasi login berdasarkan email
$sql = "SELECT * FROM users_web WHERE email=:email";

try {
    $stmt = $db->Select($sql, [':email' => $email]);
    if (count($stmt) === 1) {
        $auth_data = $stmt[0];
        // Verifikasi password
        if (password_verify($password, $auth_data['password'])) {
            // Login berhasil, set session

            // Set session variables to match Telegram login data
            $_SESSION['logged-in'] = true;
            $_SESSION['telegram_id'] = $auth_data['telegram_id'];
            $_SESSION['first_name'] = $auth_data['first_name'];
            $_SESSION['last_name'] = $auth_data['last_name'];
            $_SESSION['telegram_username'] = $auth_data['telegram_username'];
            $_SESSION['profile_picture'] = $auth_data['profile_picture'];
            $_SESSION['id'] = $auth_data['id'];

            // Redirect ke halaman utama (misalnya index.php)
            header("Location: index.php");
            exit();
        } else {
            // Password salah
            header("Location: /v2/index.php?error=invalid_password");
            exit();
        }
    } else {
        // Email tidak ditemukan
        header("Location: /v2/index.php?error=invalid_email");
        exit();
    }
} catch (Exception $e) {
    // Error ketika mengakses database
    header("Location: /v2/index.php?error=database_error");
    exit();
}
?>
