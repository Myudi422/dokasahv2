<?php
// Start the session
session_start();

require_once 'vendor/autoload.php';

use Stichoza\GoogleTranslate\GoogleTranslate;

// Di streaming.php
// Simpan URL halaman saat ini di $_SESSION['redirect_streaming']
$_SESSION['redirect_streaming'] = $_SERVER['REQUEST_URI'];

// Import database connection and class
require('db-config.php');

include 'jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};


$anime_id = $_GET['id'];
$query = '
query ($id: Int) {
  Media (id: $id, type: ANIME) {
    id
    title {
      romaji
      english
      native
    }
    description
    coverImage {
      large
    }
    bannerImage
    trailer {
      id
      site
      thumbnail
    }
    genres
    tags {
      name
    }
    format
    episodes
    duration
    status
    startDate {
      year
      month
      day
    }
    endDate {
      year
      month
      day
    }
    season
    studios {
      nodes {
        name
      }
    }
    relations {
        edges {
            relationType(version: 2)
            node {
                id
                title {
                    userPreferred
                }
            }
        }
    }
    recommendations(sort: RATING_DESC) {
      edges {
        node {
          mediaRecommendation {
            id
            title {
              romaji
              english
              native
            }
          }
        }
      }
    }
    characters {
      edges {
        node {
          name {
            full
          }
          image {
            large
          }
        }
        voiceActors {
          name {
            full
          }
          language: languageV2
          image {
            large
          }
        }
      }
    }    
  }
}
';

$variables = [
    'id' => (int) $anime_id
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
];

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://graphql.anilist.co');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query, 'variables' => $variables]));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

curl_close($ch);

$data = json_decode($result, true);



$anime_titlex = $data['data']['Media']['title']['romaji'];
$genres = $data['data']['Media']['genres'];
$tags = $data['data']['Media']['tags'];
$description = $data['data']['Media']['description'];
$average_score = $data['data']['Media']['averageScore'];

// Set the target language to Indonesian
$targetLanguage = 'id';

// Create a new GoogleTranslate object
$tr = new GoogleTranslate();

// Set the target language
$tr->setTarget($targetLanguage);

// Translate the text
$translatedDescription = $tr->translate($description);

$bannerImage = isset($data['data']['Media']['bannerImage']) ? $data['data']['Media']['bannerImage'] : 'assets/img/avatars/foto_banner.jpg';
$trailer = $data['data']['Media']['trailer'];

if ($trailer['site'] == "youtube") {
  $trailer_url = "https://www.youtube.com/watch?v=" . $trailer['id'];
} else {
  $trailer_url = "";
}
$format = $data['data']['Media']['format'];
$episodes = $data['data']['Media']['episodes'];
$duration = $data['data']['Media']['duration'];
$status = $data['data']['Media']['status'];
$start_date = $data['data']['Media']['startDate'];
$end_date = $data['data']['Media']['endDate'];
$season = $data['data']['Media']['season'];
$studios = array_map(function($studio) {
    return $studio['name'];
}, $data['data']['Media']['studios']['nodes']);

$relations = array_map(function($relation) {
    return [
        'relationType' => $relation['relationType'],
        'id' => $relation['node']['id'],
        'title' => $relation['node']['title']['userPreferred']
    ];
}, $data['data']['Media']['relations']['edges']);
// ...

$display_anime_id = strlen($anime_titlex) > 14 ? substr($anime_titlex, 0, 14) . '...' : $anime_titlex;

?>
<?php
// Koneksi ke database
$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

// Ambil id anime dari URL
$anime_id = $_GET['id'];

// Ambil judul anime dari database
$stmt = $db->prepare('SELECT title FROM anime WHERE id = ?');
$stmt->execute([$anime_id]);
$anime_title = $stmt->fetchColumn();

// Ambil resolusi dari URL atau gunakan nilai default
$resolusi = isset($_GET['resolusi']) ? $_GET['resolusi'] : 'en';

// Ambil daftar episode dari database dengan resolusi yang dipilih
$stmt = $db->prepare('SELECT * FROM nonton WHERE anime_id = ? AND resolusi = ? ORDER BY episode_number ASC');
$stmt->execute([$anime_id, $resolusi]);
$episodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Cek apakah ada episode sebelumnya
$prev_episode_number = $_GET['episode'] - 1;
$prev_episode_exists = array_reduce($episodes, function ($carry, $episode) use ($prev_episode_number) {
    return $carry || $episode['episode_number'] == $prev_episode_number;
}, false);

// Cek apakah ada episode berikutnya
$next_episode_number = $_GET['episode'] + 1;
$next_episode_exists = array_reduce($episodes, function ($carry, $episode) use ($next_episode_number) {
    return $carry || $episode['episode_number'] == $next_episode_number;
}, false);

// Ambil nomor episode dari URL
$episode_number = $_GET['episode'];

// Cek apakah tabel 'ditonton' sudah ada
$stmt = $db->prepare("SHOW TABLES LIKE 'ditonton'");
$stmt->execute();
$table_exists = $stmt->rowCount() > 0;

// Jika tabel 'ditonton' belum ada, buat tabel tersebut
if (!$table_exists) {
    $stmt = $db->prepare("CREATE TABLE `ditonton` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `anime_id` INT(11) NOT NULL,
        `episode_number` INT(11) NOT NULL,
        `telegram_id` INT(11) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $stmt->execute();
}

// Cari episode dengan nomor yang sama dengan nomor episode yang dipilih
$selected_episode = array_filter($episodes, function ($episode) use ($episode_number) {
    return $episode['episode_number'] == $episode_number;
});

// Ambil elemen pertama dari array yang difilter
$selected_episode = reset($selected_episode);

// Ambil id pengguna Telegram dari session
$telegram_id = $_SESSION['telegram_id'];

// Cek apakah episode telah ditonton oleh pengguna
$stmt = $db->prepare('SELECT * FROM ditonton WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
$stmt->execute([$anime_id, $episode_number, $telegram_id]);
$ditonton = $stmt->rowCount() > 0;

// Find the last episode the user watched
$stmt = $db->prepare('SELECT MAX(episode_number) FROM ditonton WHERE anime_id = ? AND telegram_id = ?');
$stmt->execute([$anime_id, $telegram_id]);
$last_watched_episode_number = $stmt->fetchColumn();

// Calculate the next episode number
$next_episode_number = $last_watched_episode_number + 1;

// Cek apakah tabel 'waktu_terakhir_tontonan' sudah ada
$stmt = $db->prepare("SHOW TABLES LIKE 'waktu_terakhir_tontonan'");
$stmt->execute();
$table_exists = $stmt->rowCount() > 0;

// Jika tabel 'waktu_terakhir_tontonan' belum ada, buat tabel tersebut
if (!$table_exists) {
    $stmt = $db->prepare("CREATE TABLE `waktu_terakhir_tontonan` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `anime_id` INT(11) NOT NULL,
        `episode_number` INT(11) NOT NULL,
        `telegram_id` INT(11) NOT NULL,
        `video_time` FLOAT NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $stmt->execute();
}

// Ambil id pengguna Telegram dari session
$telegram_id = $_SESSION['telegram_id'];

// Cek apakah ada waktu terakhir tontonan yang tersimpan di database
$stmt = $db->prepare('SELECT * FROM waktu_terakhir_tontonan WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
$stmt->execute([$anime_id, $episode_number, $telegram_id]);
$waktu_terakhir_tontonan = $stmt->fetch(PDO::FETCH_ASSOC);
$video_time = isset($waktu_terakhir_tontonan['video_time']) ? $waktu_terakhir_tontonan['video_time'] : null;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Nonton <?php echo $anime_titlex; ?> Sub Indo - Eps <?php echo $episode_number; ?></title>
    <meta name="description" content="Tonton dan download anime <?php echo $anime_title; ?> sub Indonesia secara gratis di ccgnimex. Kami menyediakan berbagai macam anime terbaru dan terpopuler, termasuk <?php echo $anime_title; ?> dalam kualitas HD 360p, 480p, 720p, dan 1080p, dan dalam format batch.">
<meta name="keywords" content="<?php echo "streaming $anime_titlex Sub indo, resolusi 240, 360, 480p, 720p, 1080p HD Sub indonesia format mp4. dan juga Download anime $anime_titlex Full Episode dan Nonton anime $anime_titlex subtitle indonesia tanpa ribet. Nonton $anime_titlex Sub Indo Gratis Tanpa Batas Streaming $anime_titlex Episode Terbaru Subtitle Indonesia, Download $anime_titlex Batch Sub Indo Gratis, Nonton $anime_titlex Online dengan Kualitas HD, Gratis Streaming $anime_titlex Sub Indo Full Episode, Download $anime_titlex Lengkap Subtitle Indonesia, Nonton $anime_titlex Tanpa Iklan Mengganggu"; ?>">
<meta name="author" content="ccgnimex">
<link rel="apple-touch-icon" sizes="57x57" href="/icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icon1/favicon-16x16.png">
<link rel="manifest" href="/icon1/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/icon1/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
    <meta name="google-site-verification" content="A1HYpSm2bOSTfTIoEl8SWJDrh9GWw_22ad73OvrsBWI" />
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/localforage/1.9.0/localforage.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/css/ion.rangeSlider.min.css" />

        <!-- Tambahkan event listener untuk merespon perubahan nilai dari dropdown resolusi -->
        <script>
            document.querySelector('#resolusi').addEventListener('change', function() {
                // Ambil nilai dari dropdown resolusi
                var resolusi = this.value;
                // Ubah URL halaman untuk menambahkan parameter resolusi
                var url = new URL(window.location.href);
                url.searchParams.set('resolusi', resolusi);
                window.location.href = url.toString();
            });
        </script>
        
        <script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', 'update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', 'retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
</head>
<style>
.video-container {
    position: relative;
    padding-bottom: 56.25%; /* 16:9 aspect ratio */
    height: 0;
}

.video-container .artplayer-app {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

    </style>
</head>

<body id="page-top" class>
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="komik"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="kategori"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET" action="https://ccgnimex.my.id/">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
                                </div>
                            </li>
                           <?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

function getAccessToken($clientId, $clientSecret) {
    $tokenUrl = 'https://anilist.co/api/v2/oauth/token';
    
    $postData = array(
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret
    );

    $ch = curl_init($tokenUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['access_token'])) {
        return $data['access_token'];
    } else {
        return null;
    }
}

// Database connection
$db_host = "localhost";
$db_name = "ccgnimex";
$db_user = "ccgnimex";
$db_password = "aaaaaaac";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
if (isset($_SESSION['telegram_id'])) {
    $telegramId = $_SESSION['telegram_id'];

    $sql = "SELECT * FROM notif_anime WHERE telegram_id = $telegramId AND is_read = 0 ORDER BY created_at DESC";
    $result = $conn->query($sql);

    $api_url = "https://graphql.anilist.co/";
?>

<li class="nav-item dropdown no-arrow mx-1">
    <div class="nav-item dropdown no-arrow">
        <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">
            <span class="badge bg-danger badge-counter"><?php echo $result->num_rows; ?></span>
            <i class="fas fa-bell fa-fw"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
            <h6 class="dropdown-header">Alerts Center</h6>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $animeId = $row['anilist_id'];
                    $notificationDate = date('F j, Y', strtotime($row['notification_date']));
                    $episode = $row['episode'];

                    $query = '{
                        Media(id: '.$animeId.', type: ANIME) {
                            id
                            title {
                                romaji
                            }
                            coverImage {
                                medium
                            }
                        }
                    }';

                    $ch = curl_init($api_url);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query]));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $accessToken,
                    ]);

                    $response = curl_exec($ch);
                    curl_close($ch);

                    $data = json_decode($response, true);

                    if (isset($data['data']['Media'])) {
                        $anime = $data['data']['Media'];
                        $title = $anime['title']['romaji'];
                        $coverImage = $anime['coverImage']['medium'];
                    }
            ?>
                    <a class="dropdown-item d-flex align-items-center" href="streaming.php?id=<?php echo $animeId; ?>&episode=<?php echo $episode; ?>" onclick="markAsRead(<?php echo $row['id']; ?>)">
                        <div class="me-3">
                            <img src="<?php echo $coverImage; ?>" alt="Anime Cover" width="40" height="40" class="rounded-circle">
                        </div>
                        <div>
                            <span class="small text-gray-500"><?php echo $notificationDate; ?></span>
                            <p><strong><?php echo $title; ?></strong> (Episode <?php echo $episode; ?>) Sudah Tersedia</p>
                        </div>
                    </a>
            <?php
                }
            } else {
                echo '<p class="dropdown-item text-center small text-gray-500">Tidak ada notifikasi tersedia, silahkan aktifkan notifikasi anime, dihalaman streaming, agar nanti muncul, jika admin update</p>';
            }
            ?>
            <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
        </div>
    </div>
</li>

<script>
function markAsRead(notificationId) {
    $.ajax({
        url: "update_notification.php",
        method: "POST",
        data: { notification_id: notificationId },
        success: function(response) {
            console.log("Notification marked as read");
            // Atur tampilan notifikasi sesuai keinginan Anda
        },
        error: function(error) {
            console.error("Error updating notification:", error);
        }
    });
}
</script>

<?php
    $conn->close();
} else {
}
?>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                                <div class="container-fluid">
                                    
                                    <?php
                                    // Database connection parameters
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create a connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

                                    
                                    // Retrieve a random advertisement data row from the database
$query = "
    SELECT 
        html, 
        video_url, 
        redirect_url, 
        total_duration,
        FLOOR(RAND() * (GREATEST(10, total_duration - 10) - 10 + 1)) + 10 AS play_duration
    FROM 
        advertisement_data
    ORDER BY RAND()
    LIMIT 1;
";

$result = $connection->query($query);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $advertisementHtml = $row['html'];
    $advertisementVideoUrl = $row['video_url'];
    $advertisementRedirectUrl = $row['redirect_url'];
    $advertisementTotalDuration = $row['total_duration'];
    $advertisementPlayDuration = $row['play_duration'];
}
?>
                 <?php
        if (isset($_GET['episode']) && count($episodes) > 0) {
            $videoUrl = $episodes[$_GET['episode'] - 1]['video_url'];
            $posterImage = isset($data['data']['Media']['bannerImage']) ? $data['data']['Media']['bannerImage'] : 'https://telegra.ph/file/c765a4126510cdd6c03d2.jpg';
        ?>
        <div class="video-container"style="
    bottom: 10px;
">
            <div class="artplayer-app"></div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/artplayer@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/artplayer-plugin-ads/dist/artplayer-plugin-ads.js"></script>
<script src="https://cdn.jsdelivr.net/npm/artplayer-plugin-control/dist/artplayer-plugin-control.js"></script>
<script>
    var art = new Artplayer({
        container: '.artplayer-app',
        url: "<?php echo $videoUrl; ?>",
        pip: true,
        hotkey: true,
        autoSize: true,
        setting: true,
        playbackRate: true,
        aspectRatio: true,
        fullscreen: true,
        backdrop: true,
        mutex: true,
        playsInline: true,
        airplay: true,
        lock: true,
        theme: '#23ade5',
        miniProgressBar: true,
        title: 'ccgnimex',
        poster: "<?php echo $posterImage; ?>",
        layers: [
            {
                name: 'myLayer',
                html: '<img width="120" src="https://subjective-tobye-myudi422.koyeb.app/14051/Frame+1+%284%29.png">',
                click: function () {
                    window.open('#');
                    console.info('mari nonton anime');
                },
                style: {
                    position: 'absolute',
                    top: '20px',
                    right: '20px',
                    opacity: '.9',
                },
            },
        ],
        
        plugins: [
            artplayerPluginControl(), 
            artplayerPluginAds({
                html: '<?php echo $advertisementHtml; ?>',
                video: '<?php echo $advertisementVideoUrl; ?>',
                url: '<?php echo $advertisementRedirectUrl; ?>',
                playDuration: 10,
                totalDuration: <?php echo $advertisementTotalDuration; ?>,
                muted: false,
                i18n: {
                    close: 'Tutup Iklan',
                    countdown: '%s Detik',
                    detail: 'Info Lebih Lanjut',
                    canBeClosed: `Iklan dapat ditutup setelah %s detik`,
                },
                
            }),
        ],
    });

    const videoElement = art.video; // Get the video element from Artplayer

    const anime_id = "<?php echo $anime_id; ?>";
    const episode_number = "<?php echo $episode_number; ?>";
    const telegram_id = "<?php echo $telegram_id; ?>";
    let video_time = <?php echo isset($video_time) ? $video_time : 'null'; ?>;

    // When the page is loaded, check if there's a saved video time in the database
    // If so, set the video time to the saved time
    art.once('ready', () => {
        if (video_time !== null) {
            videoElement.currentTime = video_time;
        }
    });

    // Save the current video time to the database when the page is unloaded or the video is paused
    const saveVideoTime = () => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "simpan_waktu_terakhir_tontonan.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(
            `anime_id=${anime_id}&episode_number=${episode_number}&telegram_id=${telegram_id}&video_time=${videoElement.currentTime}`
        );
    };

    window.addEventListener("beforeunload", saveVideoTime);
    videoElement.addEventListener("pause", saveVideoTime);
</script>

    <?php
    } else {
        echo "Video tidak tersedia untuk resolusi ini. Silakan ganti resolusinya.";
    }
    ?>
</div>
                <div class="container-fluid">
                    <div class="card mb-3" style="margin-bottom: calc(1.5rem + 10px) !important;">

  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <?php
      // Check if a search query was submitted
      if (isset($_GET['search'])) {
          // Get the search query from the URL parameter
          $search_query = $_GET['search'];
          // Change the text to "Hasil penelusuran" and display the search query
          echo '<span>Hasil penelusuran: ' . htmlspecialchars($search_query) . '</span>';
      } else {
          // Change the text to "ANIME"
         echo '<a href="https://ccgnimex.my.id/anime_detail?id=' . $anime_id . '"><span><strong>' . $display_anime_id . '</strong></span></a>';
      }
      ?>
<div class="d-flex">
    <div class="dropdown me-2">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="episodeDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <?php
            if (isset($_GET['episode'])) {
                // Get the current episode number from the URL parameter
                $current_episode_number = $_GET['episode'];
                // Find the current episode in the $episodes array
                $current_episode = array_filter($episodes, function ($episode) use ($current_episode_number) {
                    return $episode['episode_number'] == $current_episode_number;
                });
                // Get the first (and only) element from the filtered array
                $current_episode = reset($current_episode);
                // Display the current episode title
                echo $current_episode['title'];
            } else {
                // If no episode is selected, display "Pilih Episode"
                echo 'Pilih Episode';
            }
            ?>
        </button>
        <ul class="dropdown-menu" aria-labelledby="episodeDropdown">
    <li>
        <input type="text" class="form-control form-control-sm" id="searchEpisode" placeholder="Cari episode...">
    </li>
    <?php for ($i = 0; $i < count($episodes); $i++) { ?>
        <?php
        // Check if the current episode has been watched by the user
        $stmt = $db->prepare('SELECT * FROM ditonton WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
        $stmt->execute([$anime_id, $episodes[$i]['episode_number'], $telegram_id]);
        $ditonton = $stmt->rowCount() > 0;
        ?>
        <li class="episode-item"<?php if ($i >= 30) { ?> style="display: none;"<?php } ?>>
            <a class="dropdown-item" href="?id=<?php echo $anime_id; ?>&episode=<?php echo $episodes[$i]['episode_number']; ?>&resolusi=<?php echo $resolusi; ?>">
                <?php echo $episodes[$i]['title']; ?>
                <?php if ($ditonton) { ?>
                    <!-- Add a checkmark if the episode has been watched -->
                    &#x2713;
                <?php } ?>
            </a>
        </li>
    <?php } ?>
    <li><small class="text-muted text-center d-block">Jumlah Eps: <?php echo count($episodes); ?></small></li>
</ul>

<script>
    // Get the search input field and the list of episode items
    const searchInput = document.querySelector('#searchEpisode');
    const episodeItems = document.querySelectorAll('.episode-item');

    // Add an event listener to the search input field to listen for input events
    searchInput.addEventListener('input', function () {
        // Get the search keyword from the input field
        const searchKeyword = searchInput.value.toLowerCase();

        // Loop through the list of episode items
        let visibleCount = 0;
        episodeItems.forEach(function (item) {
            // Get the text content of the item
            const itemText = item.textContent.toLowerCase();

            // Check if the item text contains the search keyword
            if (itemText.includes(searchKeyword)) {
                // If it does, show the item
                item.style.display = 'block';
                visibleCount++;
            } else {
                // If it doesn't, hide the item
                item.style.display = 'none';
            }
        });

        // If there is no search keyword, only show the first 30 items
        if (searchKeyword === '') {
            for (let i = 30; i < episodeItems.length; i++) {
                episodeItems[i].style.display = 'none';
            }
        }
    });
</script>
    </div>
    <!-- Add a "Continue" button that takes the user to the next episode -->
    <a href="?id=<?php echo $anime_id; ?>&episode=<?php echo $next_episode_number; ?>&resolusi=<?php echo $resolusi; ?>" class="btn btn-primary" id="continueButton">Lanjutkan</a>

    <!-- Add a script to disable the "Continue" button when it is clicked -->
    <script>
        document.getElementById('continueButton').addEventListener('click', function() {
            this.disabled = true;
        });
    </script>
</div>

<script>
    document.querySelector('#searchEpisode').addEventListener('input', function() {
        // Ambil teks pencarian dari input
        var searchText = this.value.toLowerCase();
        // Saring daftar episode berdasarkan teks pencarian
        var episodeItems = document.querySelectorAll('.episode-item');
        episodeItems.forEach(function(episodeItem) {
            var episodeTitle = episodeItem.textContent.toLowerCase();
            if (episodeTitle.includes(searchText)) {
                episodeItem.style.display = '';
            } else {
                episodeItem.style.display = 'none';
            }
        });
    });
</script>
    </div>
  </div>
<div class="container">
    <div class="d-flex justify-content-between my-3">
        <div class="d-flex">
            <label for="resolusi" class="me-2 align-self-center mb-0">Resolusi:</label>
            <select id="resolusi" class="form-select form-select-sm">
    <option value="en"<?php if ($resolusi == 'en') { ?> selected<?php } ?>>720p</option>
    <option value="pt"<?php if ($resolusi == 'pt') { ?> selected<?php } ?>>360p</option>
    <option value="softsub"<?php if ($resolusi == 'softsub') { ?> selected<?php } ?>>Softsub</option>
</select>

        </div>
        <div>
            <?php if ($prev_episode_exists) { ?>
                <a href="?id=<?php echo $anime_id; ?>&episode=<?php echo $_GET['episode'] - 1; ?>&resolusi=<?php echo $resolusi; ?>" class="btn btn-primary btn-sm d-inline-flex align-items-center me-2">
    <i class="fas fa-arrow-left me-2 d-none d-md-inline-block"></i>Prev
</a>
            <?php } else { ?>
                <button class="btn btn-primary btn-sm d-inline-flex align-items-center me-2" disabled>
                    <i class="fas fa-arrow-left me-2 d-none d-md-inline-block"></i>Prev
                </button>
            <?php } ?>
            <?php if ($next_episode_exists) { ?>
                <a href="?id=<?php echo $anime_id; ?>&episode=<?php echo $_GET['episode'] + 1; ?>&resolusi=<?php echo $resolusi; ?>" class="btn btn-primary btn-sm d-inline-flex align-items-center">
    Next<i class="fas fa-arrow-right ms-2 d-none d-md-inline-block"></i>
</a>
            <?php } else { ?>
                <button class="btn btn-primary btn-sm d-inline-flex align-items-center" disabled>
                    Next<i class="fas fa-arrow-right ms-2 d-none d-md-inline-block"></i>
                </button>
            <?php } ?>
        </div>
    </div>
<br>


<?php
session_start();

// Simpan URL halaman saat ini di $_SESSION['redirect_streaming']
$_SESSION['redirect_streaming'] = $_SERVER['REQUEST_URI'];

// Cek apakah pengguna Telegram sudah login
if (isset($_SESSION['telegram_id'])) {
    // Pengguna sudah login, tampilkan fitur pemotongan video
    $videoUrl = $episodes[$_GET['episode'] - 1]['video_url']; // Ganti dengan URL video yang ingin dipotong
    ?>

    <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="enable_cutting" name="enable_cutting">
        <label class="form-check-label" for="enable_cutting">Aktifkan Potong Video</label>
    </div>
    <br>
    <div id="cutting_section" style="display: none;">
        <form action="" method="post">
            <div class="form-group">
                <label for="time_range">Potong Video</label>
                <input type="text" id="time_range_slider" name="time_range" class="form-control" />
                <small class="form-text text-muted"></small>
                <input type="hidden" name="start_time" id="start_time" required>
                <input type="hidden" name="end_time" id="end_time" required>
            </div>
            <br>
            <button type="button" class="btn btn-primary" id="cut_video_btn">Potong Video</button>
        </form>
    </div>

    <div id="duration_loading" style="display: none;">
        <i class="fa fa-spinner fa-spin"></i> Memuat durasi video...
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/js/ion.rangeSlider.min.js"></script>
    <script>
        var $j = jQuery.noConflict(); // Using $j as a replacement for $

        $j(document).ready(function() {
            var enableCuttingCheckbox = $j("#enable_cutting");
            var cuttingSection = $j("#cutting_section");
            var timeRangeSlider = $j("#time_range_slider");
            var cutVideoBtn = $j("#cut_video_btn");
            var startTimeInput = $j("#start_time");
            var endTimeInput = $j("#end_time");
            var durationLoading = $j("#duration_loading");

            enableCuttingCheckbox.on("change", function() {
                if (this.checked) {
                    durationLoading.show();
                    cuttingSection.hide();
                    //Fetch video duration using FFprobe
                    $j.ajax({
                        type: "POST",
                        url: "ffprobe_check.php",
                        data: {
                            video_url: "<?php echo $videoUrl; ?>"
                        },
                        success: function(response) {
                            var videoDuration = parseFloat(response);
                            durationLoading.hide();
                            cuttingSection.show();

                            // Set up time range slider with video duration
                            timeRangeSlider.ionRangeSlider({
                                type: "double",
                                grid: true,
                                min: 0,
                                max: videoDuration,
                                from: 0,
                                to: videoDuration,
                                step: 1,
                                prettify: function(value) {
                                    return formatTime(value);
                                },
                                onFinish: function(data) {
                                    startTimeInput.val(formatTime(data
.from));
endTimeInput.val(formatTime(data.to));
}
});
// Reset time range slider
                        timeRangeSlider.data("ionRangeSlider").reset();
                    }
                });
            } else {
                cuttingSection.hide();
            }
        });

        cutVideoBtn.on("click", function() {
            var startTime = startTimeInput.val();
            var endTime = endTimeInput.val();

            // Send the video cutting request to the server
            $j.ajax({
                type: "POST",
                url: "cut_video.php",
                data: {
                    video_url: "<?php echo $videoUrl; ?>",
                    start_time: startTime,
                    end_time: endTime
                },
                beforeSend: function() {
                    cutVideoBtn.attr("disabled", true);
                    cutVideoBtn.text("Memotong Video...");
                },
                success: function(response) {
                    cutVideoBtn.attr("disabled", false);
                    cutVideoBtn.text("Potong Video");

                    if (response === "success") {
    // Handle the success response (e.g., display a success message)
    alert("Video berhasil dipotong!");

    // Add download button for the cut video
    var downloadBtn = $j('<a>')
        .addClass('btn btn-success')
        .attr('href', 'cut_video.php?download=true&video_url=' + encodeURIComponent("<?php echo $videoUrl; ?>") + '&start_time=' + encodeURIComponent(startTime) + '&end_time=' + encodeURIComponent(endTime))
        .text('Download Video')
        .css('margin-top', '5px');
    $j('#cutting_section').append(downloadBtn);
} else {
    // Handle the error response (e.g., display an error message)
    alert("Terjadi kesalahan saat memotong video.");
}

                },
                error: function() {
                    cutVideoBtn.attr("disabled", false);
                    cutVideoBtn.text("Potong Video");

                    // Handle the error (e.g., display an error message)
                    alert("Terjadi kesalahan saat memotong video.");
                }
            });
        });

        function formatTime(seconds) {
            if (!isNumeric(seconds) || seconds < 0) {
                return "00:00:00";
            }
            var hours = Math.floor(seconds / 3600);
            var minutes = Math.floor((seconds % 3600) / 60);
            var secs = seconds % 60;

            return pad(hours) + ":" + pad(minutes) + ":" + pad(secs);
        }

        function pad(number) {
            return (number < 10) ? "0" + number : number;
        }

        function isNumeric(value) {
            return /^-?\d+$/.test(value);
        }
    });
</script>
<?php
} else {
// Pengguna belum login, tampilkan info bahwa fitur pemotongan hanya untuk pengguna yang login dengan akun Telegram
echo '<div class="alert alert-info mt-3" role="alert">
<i class="fa fa-info-circle"></i> Hilangkan Iklan dengan Login/create akun !! - Fitur pemotongan video hanya tersedia untuk pengguna yang sudah login, silahkan <a href="login.php">login</a>.

<script data-cfasync="false" type="text/javascript" data-adel="atag" src="//acdcdn.com/script/atg.js" czid="lq8iy3s2fz"></script>
</div>';
}
?>
<?php
// Ambil nomor episode dari URL
$episode_number = $_GET['episode'];

// Cari episode dengan nomor yang sama dengan nomor episode yang dipilih
$selected_episode = array_filter($episodes, function ($episode) use ($episode_number) {
    return $episode['episode_number'] == $episode_number;
});

// Ambil elemen pertama dari array yang difilter
$selected_episode = reset($selected_episode);
?>
<?php
// Koneksi ke database
$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

// Ambil id pengguna Telegram dari session
$telegram_id = $_SESSION['telegram_id'];

// Cek apakah episode telah ditonton oleh pengguna
$stmt = $db->prepare('SELECT * FROM ditonton WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
$stmt->execute([$anime_id, $episode_number, $telegram_id]);
$ditonton = $stmt->rowCount() > 0;
?>
<br>
<div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="fas fa-info-circle"></i> <strong>Info</strong></h5>
                <button id="toggleWatched" class="btn btn-primary btn-sm"><?php echo $ditonton ? 'Ditonton' : '<i class="fas fa-check"></i> Tandai Ditonton'; ?></button>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Episode</th>
                            <th scope="col">Resolusi</th>
                            <th scope="col">Media</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $selected_episode['episode_number']; ?></td>
                            <td>
                                <?php
                                $resolusi = $selected_episode['resolusi'];
                                if ($resolusi == 'en') {
                                    echo '720p';
                                } elseif ($resolusi == 'pt') {
                                    echo '360p';
                                } elseif ($resolusi == 'softsub') {
                                    echo 'Softsub';
                                }
                                ?>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <!-- Add the reCAPTCHA widget here -->
                                    <div class="g-recaptcha" data-sitekey="6LeUs5wlAAAAADeKiwyUz5rshLhkL22niH4FAsxY" data-callback="enableDownload"></div>
                                    

                                    <!-- Hide the download link by default -->
                                    <a href="<?php echo $selected_episode['video_url']; ?>" id="downloadLink" class="btn btn-primary" style="display: none;">Download</a>
</div>

                                    <!-- Add a script to hide the reCAPTCHA widget and show the download link after the user completes the CAPTCHA challenge -->
                                    <script>
                                        function enableDownload() {
  document.querySelector('.g-recaptcha').style.display = 'none';
  document.getElementById('downloadLink').style.display = 'inline';

  // Add a delay of 5 seconds before opening the new tab
  setTimeout(function() {
    window.open('https://t.me/downloadanimebatch', '_blank');
  }, 90);
}
                                        
                                        
                                    </script>
                                    
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://www.google.com/recaptcha/enterprise.js?render=6LcWjJwlAAAAAMvSBKHwsq8lnfzUoWY0lipkQzbJ"></script>
<script>
grecaptcha.enterprise.ready(function() {
    grecaptcha.enterprise.execute('6LcWjJwlAAAAAMvSBKHwsq8lnfzUoWY0lipkQzbJ', {action: 'login'}).then(function(token) {
       ...
    });
});
</script>
<script>
document.querySelector('#toggleWatched').addEventListener('click', function() {
    // Kirim permintaan ke server untuk mengubah status ditonton di database
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'toggle_watched.php');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Ubah teks tombol sesuai dengan status baru
            var watched = JSON.parse(xhr.responseText).watched;
            document.querySelector('#toggleWatched').textContent = watched ? 'Ditonton' : 'Belum Ditonton';
        }
    };
    xhr.send('anime_id=<?php echo $anime_id; ?>&episode_number=<?php echo $episode_number; ?>&telegram_id=<?php echo $telegram_id; ?>');
});
</script>

    </div>
    <br>
    </div>
    
    <style>
        /* Add custom CSS to make the reCAPTCHA widget smaller and responsive */
        .g-recaptcha {
            transform: scale(0.77);
            -webkit-transform: scale(0.77);
            transform-origin: 0 0;
            -webkit-transform-origin: 0 0;
        }
    </style>
    <script>
        // Add a script to disable right-clicking on the page
        document.addEventListener('contextmenu', function(event) {
            event.preventDefault();
        });
    </script>
<style>
  .keyword-box-container {
    display: flex;
    align-items: center;
  }
  .keyword-box {
    border: 1px solid #ced4da;
    padding: .375rem .75rem;
    border-radius: .25rem;
    max-height: 38px;
    overflow-y: hidden;
    margin-right: 10px;
  }
  .scroll-btn {
    display: flex;
    flex-direction: column;
  }
  .scroll-btn button {
    background-color: transparent;
    border: none;
    font-size: 12px;
    line-height: 1;
    padding: 2px;
  }
</style>
<div class="form-group">
  <div class="keyword-box-container">
    <div class="keyword-box" id="keyword_box">
      <?php echo "streaming $anime_titlex Sub indo, resolusi 240, 360, 480p, 720p, 1080p HD Sub indonesia format mp4. dan juga Download anime $anime_titlex Full Episode dan Nonton anime $anime_titlex subtitle indonesia tanpa ribet. Nonton $anime_titlex Sub Indo Gratis Tanpa Batas Streaming $anime_titlex Episode Terbaru Subtitle Indonesia, Download $anime_titlex Batch Sub Indo Gratis, Nonton $anime_titlex Online dengan Kualitas HD, Gratis Streaming $anime_titlex Sub Indo Full Episode, Download $anime_titlex Lengkap Subtitle Indonesia, Nonton $anime_titlex Tanpa Iklan Mengganggu"; ?>
    </div>
    <div class="scroll-btn">
      <button onclick="scrollUp()">&#9650;</button>
      <button onclick="scrollDown()">&#9660;</button>
    </div>
  </div>
</div>

<script>
  const keywordBox = document.getElementById('keyword_box');
  
  function scrollUp() {
    keywordBox.scrollTop -= 10;
  }
  
  function scrollDown() {
    keywordBox.scrollTop += 10;
  }
</script>
<br>
<button type="button" class="btn btn-primary w-100 mb-3" id="toggle-comments">Show Comments</button>
<div id="disqus_thread">
<script async src="https://comments.app/js/widget.js?3" data-comments-app-website="Aip8L2b2" data-limit="5"></script>
</div>

<script>
document.getElementById('disqus_thread').style.display = 'none';

var commentsVisible = false; // flag untuk menandai apakah komentar sedang tampil atau tidak
var toggleButton = document.getElementById('toggle-comments'); // mengambil tombol toggle dari DOM

// function untuk menampilkan atau menyembunyikan komentar
function toggleComments() {
  var commentsDiv = document.getElementById('disqus_thread');
  if (commentsVisible) {
    commentsDiv.style.display = 'none';
    toggleButton.innerHTML = 'Show Comments';
  } else {
    commentsDiv.style.display = 'block';
    toggleButton.innerHTML = 'Hide Comments';
  }
  commentsVisible = !commentsVisible; // toggle flag
}

// event listener untuk memanggil function toggleComments() ketika tombol di klik
toggleButton.addEventListener('click', toggleComments);
</script>

<style>
    
    .btn-responsive {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 1rem;
}

@media (min-width: 576px) {
  .btn-responsive {
    font-size: 0.875rem;
  }
}

@media (min-width: 768px) {
  .btn-responsive {
    font-size: 1rem;
  }
}

/* You can add more breakpoints as needed */
</style>
<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong><?php echo $anime_titlex; ?></strong>
      <i class="fas fa-male"></i>
    </div>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-md-4 col-12 text-center mb-3">
        <img src="<?php echo $data['data']['Media']['coverImage']['large']; ?>" class="img-fluid" alt="Anime Cover">
      </div>
      <div class="col-md-8 col-12 mb-3">
        <table class="table table-bordered">
          <tr style="background-color: #f7f7f7;">
            <th colspan="2">Deskripsi</th>
          </tr>
          <tr>
            <td colspan="2">
              <?php echo strlen($translatedDescription) > 256 ? substr($translatedDescription, 0, 256) . "..." : $translatedDescription; ?>
            </td>
          </tr>
          <tr style="background-color: #f7f7f7;">
            <th>Genre</th>
          </tr>
          <tr>
            <td colspan="2"><?php echo implode(', ', $genres); ?></td>
          </tr>
        </table>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="btn-group d-flex" role="group">
          <button class="btn btn-primary flex-fill btn-responsive">
            <i class="fas fa-heart"></i> Favorite
          </button>
          
          <?php
// Lakukan koneksi ke database
$connection = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");


$check_query_notif = "SELECT COUNT(*) as count FROM add_notif WHERE anime_id = '$anime_id' AND telegram_id = '$telegram_id'";
$result_notif = mysqli_query($connection, $check_query_notif);
$row_notif = mysqli_fetch_assoc($result_notif);
$is_anime_added = ($row_notif['count'] > 0);

// Tutup koneksi
mysqli_close($connection);
?>


<button id="notifButton" class="btn btn-<?php echo ($is_anime_added ? 'info' : 'success'); ?> flex-fill btn-responsive">
  <i class="fas fa-bell<?php echo ($is_anime_added ? '' : '-slash'); ?>"></i>
  <?php echo ($is_anime_added ? 'Hidup' : 'Mati'); ?>
</button>

<script>
document.addEventListener("DOMContentLoaded", function() {
  var notifButton = document.getElementById("notifButton");
  
  notifButton.addEventListener("click", function() {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "process_notification.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
        var response = xhr.responseText.trim();
        if (response === "success") {
          notifButton.innerHTML = '<i class="fas fa-bell"></i> Hidup';
          notifButton.classList.remove("btn-success");
          notifButton.classList.add("btn-info");
        } else if (response === "removed") {
          notifButton.innerHTML = '<i class="fas fa-bell-slash"></i> Mati';
          notifButton.classList.remove("btn-info");
          notifButton.classList.add("btn-success");
        }
      }
    };
    
    xhr.send("anime_id=<?php echo $anime_id; ?>&telegram_id=<?php echo $telegram_id; ?>");
  });
});
</script>
          <a href="/anime_detail?id=<?php echo $anime_id?>" class="btn btn-primary flex-fill btn-responsive">
            <i class="fas fa-info-circle"></i> Detail
          </a>
        </div>
      </div>
    </div>
  </div>
</div>


        <div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <span>Shorts - Terkait (Test)</span>
            <button id="refreshButton" class="btn btn-primary btn-sm">
                <i class="fas fa-sync-alt"></i>
                Random
            </button>
        </div>
    </div>
        <div class="card-body">
        <style>
            .video-list {
                display: grid;
                gap: 20px;

                /* Grid layout for desktop */
                grid-template-columns: repeat(3, minmax(250px, 1fr));
            }

            /* Responsive grid layout for larger screens */
            @media (min-width: 1260px) {
                .video-list {
                    grid-template-columns: repeat(3, minmax(250px, 1fr));
                }
            }

            /* Responsive grid layout for mobile */
            @media (max-width: 767px) {
                .video-list {
                    grid-template-columns: repeat(2, 1fr);
                }
            }

            .video-item {
                position: relative;
                padding-bottom: 0;
                overflow: hidden;
            }

            .video-thumbnail {
                width: 100%;
                height: auto;
            }
        </style>
            <div class="video-list">
                <?php
                $apiKey = 'AIzaSyDA-woUkqUGZ-omCDYxCgxFFbsYG9yMcZ0'; // Ganti dengan kunci API YouTube Anda
                $videoDuration = 'short'; // Filter video pendek
                
                $encodedKeyword = urlencode($anime_titlex . ' Shorts');
                $url = "https://www.googleapis.com/youtube/v3/search?key=$apiKey&q=$encodedKeyword&type=video&maxResults=15&videoDuration=$videoDuration";

                // Koneksi ke database
                $db_host = 'localhost';
                $db_user = 'ccgnimex';
                $db_pass = 'aaaaaaac';
                $db_name = 'ccgnimex';

                $connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

                if (!$connection) {
                    die("Database connection failed: " . mysqli_connect_error());
                }

                // Fungsi untuk memeriksa apakah video dengan judul anime tertentu sudah ada di database
                function videoWithTitleExistsInDatabase($title, $connection) {
                    $query = "SELECT * FROM youtube_search_results WHERE video_title LIKE '%$title%'";
                    $result = mysqli_query($connection, $query);
                    return mysqli_num_rows($result) > 0;
                }

                if (!videoWithTitleExistsInDatabase($anime_titlex, $connection)) {
                    $encodedKeyword = urlencode($anime_titlex . ' Shorts');
                    $url = "https://www.googleapis.com/youtube/v3/search?key=$apiKey&q=$encodedKeyword&type=video&maxResults=15&videoDuration=$videoDuration";

                    // Lakukan pencarian API dan simpan video baru ke database jika belum ada
                    $response = file_get_contents($url);
                    $data = json_decode($response, true);

                    if (isset($data['items'])) {
                        foreach ($data['items'] as $item) {
                            $videoId = $item['id']['videoId'];
                            $videoTitle = mysqli_real_escape_string($connection, $anime_titlex);

                            // Masukkan data video ke dalam database
                            $insertQuery = "INSERT INTO youtube_search_results (video_id, video_title) VALUES ('$videoId', '$videoTitle')";
                            mysqli_query($connection, $insertQuery);
                        }
                    }
                }

                // Dapatkan 6 video acak dari database yang sesuai dengan judul anime
                $selectQuery = "SELECT * FROM youtube_search_results WHERE video_title LIKE '%$anime_titlex%' ORDER BY RAND() LIMIT 6";
                $selectResult = mysqli_query($connection, $selectQuery);

                if (mysqli_num_rows($selectResult) > 0) {
                    while ($row = mysqli_fetch_assoc($selectResult)) {
                        $videoId = $row['video_id'];
                        $videoURL = "https://www.youtube.com/watch?v=$videoId";

                        echo "<div class='video-item'>
                                <a href='$videoURL' class='video-link mfp-iframe'>
                                    <img src='https://img.youtube.com/vi/$videoId/mqdefault.jpg' alt='Video Thumbnail' class='video-thumbnail'>
                                </a>
                            </div>";
                    }
                } else {
                    echo "No videos found.";
                }

                // Tutup koneksi ke database
                mysqli_close($connection);
                ?>
            </div>
        </div>
    </div>

   <script>
    // Function to initialize Magnific Popup
    function initializeMagnificPopup() {
        $('.video-link').magnificPopup({
            type: 'iframe'
        });
    }

    // Initial Magnific Popup initialization
    $(document).ready(function() {
        initializeMagnificPopup();

        $('#refreshButton').on('click', function() {
            $('.video-list').html('<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</div>');

            // Perform the automatic random refresh
            $.ajax({
                url: 'refresh_videos.php',
                success: function(response) {
                    $('.video-list').html(response);
                    initializeMagnificPopup(); // Reinitialize Magnific Popup after content is refreshed
                },
                error: function() {
                    $('.video-list').html('Failed to refresh videos.');
                }
            });
        });
    });
</script>
<style>
    .card-body {
        max-width: 100%;
        overflow: hidden;
    }

    .owl-carousel {
        max-width: 100%;
        margin: 0 auto;
    }

    @media (max-width: 600px) {
        .owl-carousel {
            max-width: 90%;
        }
    }
</style>


        
            
<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Tersedia Versi Web</strong>
      <i class="fas fa-male"></i>
    </div>
  </div>
  <div class="card-body">
      <?php
      include 'web_anime.php';
      ?>
            </div>
            </div>
<style>.card-body {
    max-width: 100%;
    overflow: hidden;
}
.owl-carousel {
            max-width: 100%;
            margin: 0 auto;
        }
@media (max-width: 600px) {
    .owl-carousel {
        max-width: 90%;
    }
}
        </style>
        <div class="card mb-3" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Anime Terbaik</strong>
      <i class="fas fa-male"></i>
    </div>
  </div>
      <?php
      include 'top_anime.php';
      ?>
            </div>
            </div>
                  
            </div>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Created by © ccgnimex v1.23</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script>$(document).ready(function() {
    // Collapse the sidebar upon page load
    $("#sidebarToggle").trigger("click");
});</script>
<?php
// Koneksi ke database
$db = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Membuat tabel sitemap jika belum ada
$query = "CREATE TABLE IF NOT EXISTS sitemap (id INT AUTO_INCREMENT PRIMARY KEY, url VARCHAR(255) NOT NULL)";
mysqli_query($db, $query);

// Mendapatkan URL halaman saat ini
$current_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// Query untuk mengecek apakah URL sudah ada di dalam database
$query = "SELECT * FROM sitemap WHERE url='$current_url'";
$result = mysqli_query($db, $query);

// Jika URL belum ada di dalam database, simpan ke dalam database
if (mysqli_num_rows($result) == 0) {
    $query = "INSERT INTO sitemap (url) VALUES ('$current_url')";
    mysqli_query($db, $query);
}
?>
    
        <!-- Tambahkan event listener untuk merespon perubahan nilai dari dropdown resolusi -->
        <script>
            document.querySelector('#resolusi').addEventListener('change', function() {
                // Ambil nilai dari dropdown resolusi
                var resolusi = this.value;
                // Ubah URL halaman untuk menambahkan parameter resolusi
                var url = new URL(window.location.href);
                url.searchParams.set('resolusi', resolusi);
                window.location.href = url.toString();
            });
        </script>
        
        <script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>
