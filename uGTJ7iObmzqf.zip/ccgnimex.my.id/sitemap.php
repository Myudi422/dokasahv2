<?php
// Koneksi ke database
$db = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Header untuk sitemap.xml
header("Content-Type: text/xml;charset=iso-8859-1");
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

// Query untuk mengambil semua URL dari database
$query = "SELECT url FROM sitemap";
$result = mysqli_query($db, $query);

// Loop untuk menampilkan semua URL dalam format sitemap.xml
while ($row = mysqli_fetch_assoc($result)) {
    $url = htmlspecialchars($row['url']);
    echo '<url>';
    echo '<loc>' . $url . '</loc>';
    echo '</url>';
}

echo '</urlset>';
?>