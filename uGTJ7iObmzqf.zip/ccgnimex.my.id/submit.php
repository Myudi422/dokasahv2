<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label for="base_url" class="form-label">Base URL:</label>
                        <input type="text" class="form-control" id="base_url" name="base_url" value="https://seahorse-app-kph57.ondigitalocean.app/">
                    </div>
                    <div class="mb-3">
                        <label for="start" class="form-label">Start:</label>
                        <input type="number" class="form-control" id="start" name="start" value="4444">
                    </div>
                    <div class="mb-3">
                        <label for="count" class="form-label">Count:</label>
                        <input type="number" class="form-control" id="count" name="count" value="20">
                    </div>
                    <input type="submit" class="btn btn-primary me-2" name="submit" value="Generate Links">
                    <?php
                    if (isset($_POST['submit'])) {
                        echo '<button type="button" class="btn btn-secondary" onclick="copyLinks()">Copy All</button>';
                    }
                    ?>
                </form>
            </div>
        </div>

        <?php
        if (isset($_POST['submit'])) {
            $base_url = $_POST['base_url'];
            $start = $_POST['start'];
            $count = $_POST['count'];
            ?>

            <div class="card mt-5">
                <div class="card-header">Generated Links</div>
                <ul class="list-group list-group-flush" id="links-list">
                    <?php
                    // Generate the links
                    for ($i = 0; $i < $count; $i++) {
                        $link = $base_url . ($start + $i);
                        echo '<li class="list-group-item"><a href="' . $link . '">' . $link . '</a></li>';
                    }
                    ?>
                </ul>
            </div>

            <?php
        }
        ?>
    </div>

    <script>
        function copyLinks() {
            const linksList = document.querySelector('#links-list');
            const links = Array.from(linksList.querySelectorAll('a')).map(a => a.href).join('\n');
            navigator.clipboard.writeText(links);
        }
    </script>
</body>
</html>