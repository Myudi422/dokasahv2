<?php
// Lakukan koneksi ke database
$host = '127.0.0.1';
$user = 'ccgnimex';
$password = 'aaaaaaac';
$dbname = 'ccgnimex';

$conn = mysqli_connect($host, $user, $password, $dbname);

// Cek koneksi
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Query untuk mengambil data anime dari tabel
$sql = "SELECT item FROM a_lists";
$result = mysqli_query($conn, $sql);

if (!$result) {
    echo "Failed to fetch data: " . mysqli_error($conn);
    exit();
}

// Buat array untuk menyimpan id anime dari tabel
$id_anime = array();

while ($row = mysqli_fetch_assoc($result)) {
    $id_anime[] = $row['item'];
}

// Lakukan koneksi ke API AniList untuk mengambil informasi anime
$endpoint = 'https://graphql.anilist.co';
$variables = [
    'id_in' => $id_anime,
    'type' => 'ANIME',
    'page' => 1,
    'perPage' => 5
];
$query = <<<'QUERY'
query ($id_in: [Int], $type: MediaType, $page: Int, $perPage: Int) {
    Page(page: $page, perPage: $perPage) {
        media(id_in: $id_in, type: $type) {
            id
            title {
                romaji
            }
            genres
            trailer {
                id
            }
        }
    }
}
QUERY;

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
];

$data = [
    'query' => $query,
    'variables' => $variables,
];

$options = [
    'http' => [
        'header' => implode("\r\n", $headers),
        'method' => 'POST',
        'content' => json_encode($data),
    ],
];

$context = stream_context_create($options);
$response = file_get_contents($endpoint, false, $context);
$result = json_decode($response, true);

// Tampilkan data anime dalam bentuk grid
echo '<div class="anime-grid">';
foreach ($result['data']['Page']['media'] as $anime) {
    echo '<div class="anime-item">';
    echo '<img src="https://img.anili.st/media/' . $anime['id'] . '" alt="' . $anime['title']['romaji'] . '">';
    echo '<h3 class="anime-title">' . substr($anime['title']['romaji'], 0, 24) . (strlen($anime['title']['romaji']) > 24 ? '...' : '') . '</h3>';
    echo '<p class="anime-genres">' . implode(", ", $anime['genres']) . '</p>';

    // Tampilkan link video trailer jika tersedia, atau tidak menampilkan apa-apa jika tidak tersedia
    if (isset($anime['trailer']['id'])) {
        echo '<a class="anime-trailer" href="https://www.youtube.com/watch?v=' . $anime['trailer']['id'] . '" target="_blank">
            <span class="sr-only">Trailer</span>
            <i class="fas fa-video"></i>
        </a>';
    }

    echo '<a class="anime-link" href="https://t.me/ccgnimeX_bot?start=anilme_'.$anime['id'].'" target="_blank">
      <span class="sr-only">Lihat</span>
      <i class="fas fa-arrow-circle-right"></i>
    </a>';

    echo '</div>';
}
echo '</div>';


// Tampilkan tombol "Load More" jika masih ada data yang belum ditampilkan
if (count($result['data']['Page']['media']) >= $variables['perPage']) {
    echo '<button class="load-more" onclick="loadMore(' . ($variables['page'] + 1) . ')">Load More</button>';
}

echo'<script>
function loadMore(page) {
    fetchAnimeData(page, function(response) {
        var animeGrid = document.querySelector(".anime-grid");
        response.data.Page.media.forEach(function(anime) {
            var animeItem = document.createElement("div");
            animeItem.classList.add("anime-item");
            animeItem.innerHTML = \'<img src="https://img.anili.st/media/\' + anime.id + \'" alt="\' + anime.title.romaji + \'"><h3 class="anime-title">\' + anime.title.romaji.substring(0, 24) + (anime.title.romaji.length > 24 ? "..." : "") + \'</h3><p class="anime-genres">\' + anime.genres.join(", ") + \'</p>\';
            if (anime.trailer !== null) {
                animeItem.innerHTML += \'<a class="anime-trailer" href="https://www.youtube.com/watch?v=\' + anime.trailer.id + \'" target="_blank"><span class="sr-only">Trailer</span><i class="fas fa-video"></i></a>\';
            }
            animeItem.innerHTML += \'<a class="anime-link" href="https://t.me/ccgnimeX_bot?start=anilme_\' + anime.id + \'" target="_blank"><span class="sr-only">Lihat</span><i class="fas fa-arrow-circle-right"></i></a>\';
            animeGrid.appendChild(animeItem);
        });
        if (response.data.Page.media.length < ' . $variables['perPage'] . ') {
            var loadMoreButton = document.querySelector(".load-more");
            loadMoreButton.parentNode.removeChild(loadMoreButton);
        }
    });
}

function fetchAnimeData(page, callback) {
    var endpoint = "https://graphql.anilist.co";
    var variables = ' . json_encode([
        "id_in" => $id_anime,
        "type" => "ANIME",
        "page" => $page,
        "perPage" => $variables['perPage'],
    ]) . ';
    var query = `query ($id_in: [Int], $type: MediaType, $page: Int, $perPage: Int) {
        Page(page: $page, perPage: $perPage) {
            media(id_in: $id_in, type: $type) {
                id
                title {
                    romaji
                }
                genres
                trailer {
                    id
                }
            }
        }
    }`;
    var headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    };
    var data = {
        "query": query,
        "variables": variables,
    };
    var options = {
        "method": "POST",
        "headers": headers,
        "body": JSON.stringify(data),
    };
    fetch(endpoint, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(responseData) {
            callback(responseData);
        });
}
</script>
';
mysqli_close($conn);

?>

<style>
/* Style untuk grid anime */
.anime-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
  grid-gap: 10px;
  justify-items: center;
  margin: 10px;
}

/* Style untuk item anime */
.anime-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  padding: 10px;
}

/* Style untuk judul anime */
.anime-title {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 5; /* jumlah baris maksimum */
  overflow: hidden;
  text-overflow: ellipsis;
  border: 1px solid #4e73df;
  padding: 7px;
  border-radius: 7px;
  font-size: 11px;
  font-weight: bold;
  margin: 7px 0px;
  text-align: center;
}

.anime-title {
  border: 1px solid #4e73df;
  padding: 7px;
  border-radius: 7px;
}

/* Style untuk genre anime */
.anime-genres {
  font-size: 7px;
  margin-bottom: 5px;
  text-align: center;
}

/* Style untuk tombol "Load More" */
/* Style untuk tombol "Load More" */
.load-more {
  display: block;
  margin: 10px auto;
  padding: 0.75em 1.5em;
  font-size: 1.2em;
  font-weight: bold;
  background-color: #0077ff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  max-width: 270px;
  box-sizing: border-box;
}

/* Style untuk tombol "Load More" pada layar yang lebih besar */
@media only screen and (min-width: 768px) {
  .load-more {
    max-width: none;
    padding: 1em 2em;
  }
}


/* Style untuk gambar anime */
.anime-item img {
  width: 100%;
  height: auto;
  border-radius: 5px;
  object-fit: cover; /* tambahkan properti object-fit */
}

/* Style untuk tampilan mobile */
@media only screen and (max-width: 768px) {
  /* Style untuk grid anime */
  .anime-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    grid-gap: 5px;
  }

  /* Style untuk judul anime */
  .anime-title {
    font-size: 14px;
  }

  /* Style untuk genre anime */
  .anime-genres {
    font-size: 10px;
  }

  /* Style untuk tombol "Load More" */
  .load-more {
    font-size: 14px;
    padding: 8px 16px;
  }
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

