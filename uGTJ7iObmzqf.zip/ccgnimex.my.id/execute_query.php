<?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

// Get query and variables from POST data
$query = $_POST['query'];
$variables = $_POST['variables'];

// Execute query and get results
$results = executeQuery($query, $variables, $accessToken);

// Return results as JSON
header('Content-Type: application/json');
echo json_encode($results);

function getAccessToken($clientId, $clientSecret) {
    // Set up cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://anilist.co/api/v2/oauth/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
    ]));
    // Execute cURL request and get response
    $response = curl_exec($ch);
    curl_close($ch);

    // Decode JSON response and return access token
    return json_decode($response)->access_token;
}

function executeQuery($query, $variables, $accessToken) {
    // Set up cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graphql.anilist.co');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . $accessToken,
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'query' => $query,
        'variables' => $variables,
    ]));
    // Execute cURL request and get response
    $response = curl_exec($ch);
    curl_close($ch);

    // Decode JSON response and return data
    return json_decode($response,true);
}