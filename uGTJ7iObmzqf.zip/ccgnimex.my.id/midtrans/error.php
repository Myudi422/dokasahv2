<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kesalahan Pembayaran</title>
</head>
<body>
    <h1>Oops! Terjadi kesalahan.</h1>
    <p>Maaf, tampaknya ada kesalahan saat memproses pembayaran Anda. Silakan coba lagi.</p>
</body>
</html>