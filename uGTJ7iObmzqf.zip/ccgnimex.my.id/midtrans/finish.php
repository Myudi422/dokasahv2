<?php
require_once('../vendor/autoload.php');

\Midtrans\Config::$serverKey = 'SB-Mid-server-Z0n-nKvhbWBD5qVZyKdGyxfY';
\Midtrans\Config::$isProduction = false;

$order_id = $_GET['order_id'];  // Assuming order_id is passed as a GET parameter

$status = \Midtrans\Transaction::status($order_id);
    
    // If the transaction status is pending, display a retry payment button
    if ($status->transaction_status == "pending") {
        echo "Your payment is still pending. <a href='index.php'>Click here</a> to retry payment.";
        exit();
    }
    

$coupon = "";
if ($status->transaction_status == "settlement") {
    $server = "localhost";
    $username = "ccgnimex";
    $password = "aaaaaaac";
    $dbname = "ccgnimex";

    $conn = new mysqli($server, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if order_id already exists in coupon_log
    $check_log = $conn->query("SELECT coupon FROM coupon_log WHERE order_id = '$order_id'");
    
    if ($check_log->num_rows > 0) {  // If order_id exists in coupon_log
        $coupon = $check_log->fetch_assoc()['coupon'];
    } else {
        $result = $conn->query("SELECT phone FROM transactions WHERE order_id = '$order_id'");
        $phone = $result->fetch_assoc()['phone'];
        $random_code = substr(md5(rand()), 0, 5);  // Generate a 5-character random code
        $coupon = $phone . " - " . $random_code;

        $expiry_date_choice = $status->custom_field3;

        if ($expiry_date_choice == "1_month") {
            $expiry_date = date("Y-m-d", strtotime("+1 month"));
        } else if ($expiry_date_choice == "1_week") {
            $expiry_date = date("Y-m-d", strtotime("+1 week"));
        } else {
            $expiry_date = date("Y-m-d"); // Default to current date if something goes wrong
        }

        $stmt = $conn->prepare("INSERT INTO devices (kupon, expiry_date) VALUES (?, ?)");
        $stmt->bind_param("ss", $coupon, $expiry_date);

        if (!$stmt->execute()) {
            die("Error inserting coupon: " . $stmt->error);
        }

        // Add the order_id and coupon to the coupon_log
        $conn->query("INSERT INTO coupon_log (order_id, coupon) VALUES ('$order_id', '$coupon')");

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Pembayaran Berhasil</title>
</head>
<body class="bg-gray-100 p-5">
    <div class="bg-white p-5 rounded shadow-md">
        <h1 class="text-2xl mb-4">Terima kasih!</h1>
        <p class="mb-4">Pembayaran Anda telah berhasil.</p>
        <?php if ($coupon): ?>
        <p class="text-xl font-semibold">Kupon Anda: <span class="bg-yellow-200 p-2 rounded"><?= $coupon ?></span></p>
        <?php endif; ?>
        <button class="mt-5 bg-blue-500 text-white px-4 py-2 rounded" onclick="location.reload()">Refresh</button>
    </div>
</body>
</html>