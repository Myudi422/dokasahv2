<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Bayar dengan Midtrans</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet"/>
</head>
<body class="bg-gray-100 py-20">
<div class="max-w-md mx-auto bg-white rounded-xl shadow-md p-8">
<h1 class="text-2xl font-bold mb-4">Masukkan Nomor Telepon Anda</h1>
<form action="process_payment.php" method="POST">
<div class="mb-4">
<label class="block text-sm font-medium text-gray-600" for="phone">Nomor Telepon</label>
<input class="mt-1 p-2 w-full border rounded-md" id="phone" name="phone" required="" type="text"/>
</div>
<div class="mb-4"><label class="block text-sm font-medium text-gray-600" for="expiry_date">Pilih Masa Kedaluwarsa</label><select class="mt-1 p-2 w-full border rounded-md" id="expiry_date" name="expiry_date"><option value="1_month">1 Bulan</option><option value="1_week">1 Minggu</option></select></div><button class="bg-blue-500 text-white p-2 rounded-md w-full" type="submit">Bayar dengan Midtrans</button>
</form>
</div>
</body>
</html>
