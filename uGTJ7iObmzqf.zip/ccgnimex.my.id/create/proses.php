<?php
// process_create_user.php

// Ambil data dari form
$first_name = $_POST['first_name'];  // Ubah dari 'first_name' menjadi 'name'
$email = $_POST['email'];
$password = $_POST['password'];

// Lakukan validasi atau sanitasi data jika diperlukan

// Lakukan koneksi ke database MySQL (gunakan parameter koneksi yang aman)
$servername = "localhost";
$username = "ccgnimex";
$password_db = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password_db, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Generate Telegram ID secara otomatis (web-randomNumber)
$telegram_id = "web-" . mt_rand(100000, 999999);

// Gunakan prepared statement untuk mencegah SQL injection
$stmt = $conn->prepare("INSERT INTO users_web (first_name, email, password, telegram_id) VALUES (?, ?, ?, ?)");

// Hash password sebelum disimpan ke database
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Bind parameter ke prepared statement
$stmt->bind_param("ssss", $first_name, $email, $hashed_password, $telegram_id);

// Eksekusi prepared statement
if ($stmt->execute()) {
    // Redirect ke halaman login jika berhasil
    header("Location: ../v2");
    exit();
} else {
    // Debug: Tampilkan pesan kesalahan
    echo "Error: " . $stmt->error;

    // Redirect kembali ke halaman create user dengan pesan error
    header("Location: /v2/index.php?error=registration_failed");
    exit();
}

// Tutup prepared statement
$stmt->close();

// Tutup koneksi
$conn->close();
?>
