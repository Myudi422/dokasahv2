<style>
    .container {
        padding-top: 5rem;
        padding-bottom: 5rem;
    }

    /* Customize Bootstrap */
    .form-group {
        margin-bottom: 0rem;
    }

    #title-desc {
        color: white;
    }
</style>

<script>
    // Your JavaScript logic goes here
    function checkError() {
        let error = "";

        const formElmts = document.querySelectorAll('#yourForm *[name]');

        for(let i=0; i<formElmts.length; i++){
            if(formElmts[i].value === ""){
                error += `${formElmts[i].name}: ${error}\n`;
            }
        }

        return error;
    }
</script>

<div id="blog_template" class="bg-white shadow">
    <div class="container">
        <div class="row gutter-l">
            <div class="col s12 ">
                <div class="card">
                    <div class="card-body">
                        <h2>Create Article</h2>

                        <label for="exampleInputEmail1">Title:</label>
                        <input type="text" name="title" required/>

                        <label for="exampleInputPassword1">Description:</label>
                        <textarea name="description" rows="8" cols="40" required></textarea>

                        <br />

                        <button class="btn waves-effect waves-light light-blue darken-1" type="submit" value="action" class="mb-2" style="border-radius: 0;">Submit</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function checkError(){
    let error=""

const formElmts=document.querySelectorAll("#yourForm *[name]")
for(let i=0;i<formElmts.length;i++){
    if(formElmts[i].value==""){
        error+=`${formElmts[i].name}: ${error}\n`
    }
}
return error
}
</script>