<div class="carousel">
  <div class="slide">
    <img src="" alt="">
    <div class="caption"></div>
  </div>
  <div class="slide">
    <img src="" alt="">
    <div class="caption"></div>
  </div>
  <div class="slide">
    <img src="" alt="">
    <div class="caption"></div>
  </div>
</div>

<style>.carousel {
  display: flex;
  justify-content: center;
  align-items: center;
}

.slide {
  margin: 0 10px;
  border-radius: 50%;
  overflow: hidden;
}

.slide img {
  width: 200px;
  height: 200px;
  object-fit: cover;
}

.caption {
  text-align: center;
}

@media screen and (max-width: 767px) {
  .carousel {
    flex-direction: column;
  }
  
  .slide {
    margin: 10px 0;
  }
  
  .slide img {
    width: 100%;
    height: auto;
  }
}

</style>

<script>const query = `
  query ($page: Int, $perPage: Int) {
    Page(page: $page, perPage: $perPage) {
      media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC) {
        id
        title {
          romaji
          english
          native
        }
        coverImage {
          extraLarge
        }
      }
    }
  }
`;

const variables = {
  page: 1,
  perPage: 3
};

fetch('https://graphql.anilist.co', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  body: JSON.stringify({
    query,
    variables
  })
})
  .then(response => response.json())
  .then(data => {
    const slides = document.querySelectorAll('.slide');
    slides.forEach((slide, index) => {
      const anime = data.data.Page.media[index];
      const image = slide.querySelector('img');
      const caption = slide.querySelector('.caption');

      image.src = anime.coverImage.extraLarge;
      image.alt = anime.title.romaji;
      caption.textContent = anime.title.romaji;
    });
  })
  .catch(error => {
    console.log(error);
  });
</script>