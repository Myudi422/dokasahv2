<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advertisement Data Form</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Advertisement Data Form</h1>
        <form action="insert_advertisement.php" method="post">
            <div class="form-group">
                <label for="html">Advertisement HTML:</label>
                <input type="text" class="form-control" name="html" id="html" required>
            </div>
            <div class="form-group">
                <label for="video_url">Video URL:</label>
                <input type="text" class="form-control" name="video_url" id="video_url" required>
            </div>
            <div class="form-group">
                <label for="redirect_url">Redirect URL:</label>
                <input type="text" class="form-control" name="redirect_url" id="redirect_url" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>