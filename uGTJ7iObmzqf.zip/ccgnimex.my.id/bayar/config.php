<?php

return [

    /**
     * Integration mode
     */
    'mode' => 'development',

    /**
     * Merchant code
     */
    'merchant_code' => 'T25718',

    /**
     * Api Key
     */
    'api_key' => 'DEV-uWJBx59dkDh01v8cpr0Zwb744BfBv1FMjd7dE52e',

    /**
     * Private Key
     */
    'private_key' => 'E7qad-BsAud-1eVYR-foGnM-wyxVJ',

    /**
     * Additional Guzzle options
     */
    'guzzle_options' => []

];