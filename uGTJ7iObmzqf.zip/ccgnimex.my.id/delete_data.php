<?php
// Koneksi ke database MySQL
$db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

// Get data from POST data
$recipient = $_POST['recipient'];
$item = $_POST['item'];

// Query untuk menghapus data dari tabel notify
$query = "DELETE FROM notify WHERE recipient = ? AND item = ?";

// Buat prepared statement
$stmt = mysqli_prepare($db, $query);

// Bind parameter ke prepared statement
mysqli_stmt_bind_param($stmt, 'ss', $recipient, $item);

// Eksekusi prepared statement
$query_result = mysqli_stmt_execute($stmt);

// Cek apakah query berhasil dijalankan
if ($query_result) {
    echo 'Data berhasil dihapus';
} else {
   echo 'Terjadi kesalahan saat menghapus data: ' . mysqli_error($db);
}
?>