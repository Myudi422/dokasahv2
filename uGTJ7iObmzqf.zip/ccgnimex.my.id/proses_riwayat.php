<?php
// Start the session
session_start();

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Menentukan jumlah data per halaman
$limit = 9; // jumlah data per halaman untuk desktop
if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobi/', $_SERVER['HTTP_USER_AGENT'])) {
    // Jika user agent mengandung kata "Mobi", asumsikan pengguna menggunakan perangkat mobile
    $limit = 6; // jumlah data per halaman untuk mobile
}

// Menentukan halaman yang aktif
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Menghitung offset data
$offset = ($page - 1) * $limit;

$sql = "SELECT DISTINCT e.anime FROM episodes e JOIN watched w ON e.id = w.episode WHERE w.user = " . $_SESSION['telegram_id'] . " ORDER BY w.id DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Create an array of anime IDs
    $anime_ids = [];
    while($row = $result->fetch_assoc()) {
        $anime_ids[] = $row["anime"];
    }

    // Modify the GraphQL query to accept an array of IDs
    $query = '
    query ($ids: [Int]) {
      Page {
        media(id_in: $ids, type: ANIME) {
          id
          title {
            romaji
          }
          coverImage {
            large
          }
        }
      }
    }
    ';

    // Set the variables for the query
    $variables = [
        'ids' => $anime_ids
    ];

    // Send the API request and process the response as before
    $url = 'https://graphql.anilist.co';
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode([
                'query' => $query,
                'variables' => $variables
            ])
        ]
    ];
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $data = json_decode($response, true);

    // Process the API response and display the anime data in a grid format as before
    $max_columns = 9; // jumlah maksimum kolom per baris untuk desktop
    if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobi/', $_SERVER['HTTP_USER_AGENT'])) {
        // Jika user agent mengandung kata "Mobi", asumsikan pengguna menggunakan perangkat mobile
        $max_columns = 3; // jumlah maksimum kolom per baris untuk mobile
    }
    $current_column = 0; // kolom saat ini
echo "<table><tr>";

// Ubah urutan data yang diterima dari Anilist
$media_data = array_reverse($data['data']['Page']['media']);

foreach ($media_data as $media) {
    $title = $media['title']['romaji'];
    if (strlen($title) > 24) {
        $title = substr($title, 0, 21) . '...';
    }
    echo "<td><img loading='lazy' src='" . $media['coverImage']['large'] . "'><a href='https://ccgnimex.my.id/anime_detail?id=" . $media["id"] . "'><span>" . $title . "</span></a></td>";

    // Cek apakah jumlah kolom sudah mencapai batas maksimum
    if (++$current_column >= $max_columns) {
        // Jika ya, tambahkan baris baru dan reset kolom saat ini
        echo "</tr><tr>";
        $current_column = 0;
    }
}
echo "</tr></table>";
// Hitung jumlah total halaman
    $sql = "SELECT COUNT(DISTINCT e.anime) as total FROM episodes e JOIN watched w ON e.id = w.episode WHERE w.user = " . $_SESSION['telegram_id'];
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $total_pages = ceil($row['total'] / $limit);

    // Cek apakah pengguna berada di halaman terakhir
    if ($page >= $total_pages) {
        // Jika ya, nonaktifkan tombol next
        echo '<script>document.querySelector(".next-button1").setAttribute("disabled", "disabled");</script>';
    }
} else {
    echo '<div class="text-center mt-3">';
    echo '<p><i class="fas fa-clock"></i> <strong>Belum ada anime yang kamu tonton. (tandai ceklis di episode anime ketika menonton dibot, agar muncul animenya)</strong></p>';
}

$conn->close();
?>