<?php include 'data-login.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Seacrh Anime - ccgnimex</title>
    <!-- Tambahkan link ke Tailwind CSS dan Font Awesome CSS di sini -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    
        <link rel="apple-touch-icon" sizes="57x57" href="../icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="../icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../icon1/favicon-16x16.png">


    <!-- Sertakan file CSS eksternal -->
    <?php include 'css/navbar_home.php'; ?>
    <?php include 'css/darkmode.php'; ?>
    <style>
        /* Sembunyikan ikon penutup */
#search-input::-webkit-search-cancel-button {
    display: none;
}
#search-input::-ms-clear {
    display: none;
}
    </style>
    
    <style>
    /* CSS untuk desktop */
    @media (min-width: 768px) {
        iframe {
            max-height: calc(100vh - 100px) !important; /* Sesuaikan nilai tinggi maksimum sesuai kebutuhan */
        }
    }

    /* CSS untuk perangkat mobile */
    @media (max-width: 767px) {
        .iframe-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 60px; /* Tinggi yang diinginkan di tengah layar mobile */
            overflow: hidden;
        }

        iframe {
            max-height: 100%; /* Biarkan elemen iframe mengisi tinggi container */
        }
    }
</style>
<meta name="octoclick-verification" content="487a78106719814adab9d29d12267714">
</head>
<body style="margin-bottom: 40px;">

<!-- Navbar -->
<nav class="bg-gray-100 p-2 flex justify-between items-center">
    <a href="/v2"> <!-- Tambahkan anchor untuk mengarahkan ke /v2 -->
        <div class="flex items-center">
            <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 30px; height: 30px;" />
            <div class="flex-1 text-left ml-2">
                <span style="font-family: 'Arial', sans-serif; font-weight: bold; font-size: 1rem;">ccgnimex</span>
            </div>
        </div>
    </a>
    <div class="flex items-center">
        <a href="#" id="dark-mode-button" class="mx-2"><i class="fas fa-sun mr-2"></i></a>
    </div>
</nav>



<div class="bg-red-100 p-3 sticky top-0">
    <div class="flex items-center">
        <a href="/v2" class="text-secondary btn btn-link text-decoration-none">
            <i class="fa fa-angle-left"></i>
        </a>

        <div class="ml-4 relative flex items-center w-full">
            <input
                id="search-input"
                class="w-full px-3 py-2 pr-10 border rounded-l-lg focus:outline-none focus:border-secondary bg-white text-success"
                type="search"
                placeholder="Cari Anime..."
                autocomplete="off"
            />
            <button
                class="absolute right-3 top-2 text-secondary"
                type="button"
                id="search-button"
            >
                <i class="fa fa-search"></i>
            </button>
            <button
                class="absolute right-10 top-2 text-secondary"
                type="button"
                id="settings-button"
            >
                <i class="fa fa-cog"></i>
            </button>
            <div id="settings-popup" class="hidden absolute right-10 top-10 bg-white border rounded-lg shadow-md p-2">
                <label for="available-checkbox">
                    <input type="checkbox" id="available-checkbox" class="mr-2"> Tersedia
                </label>
            </div>
        </div>
    </div>
</div>

<!-- Search Results -->
<div id="search-results" class="mt-4" style="margin-bottom: 70px;margin-left: 10px;margin-right: 10px;"></div>

<?php
// Inisialisasi sesi
session_start();

// Mengambil ID Telegram dari sesi
$telegram_id = $_SESSION['telegram_id'];

// Membuat koneksi ke database (gantilah dengan detail koneksi Anda)
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

try {
    $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set PDO error mode ke exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query ke database untuk memeriksa apakah ID Telegram ada dalam tabel "admins"
    $sql = "SELECT * FROM admins WHERE telegram_id = :telegram_id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':telegram_id', $telegram_id, PDO::PARAM_INT);
    $stmt->execute();

    $show_edit_icon = false;

    if ($stmt->rowCount() > 0) {
        $show_edit_icon = true;
    }
} catch (PDOException $e) {
    // Tangani kesalahan koneksi database
    die("Koneksi database gagal: " . $e->getMessage());
}
?>


    <script>
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const searchResults = document.getElementById('search-results');
    const settingsButton = document.getElementById('settings-button');
    const settingsPopup = document.getElementById('settings-popup');
    const availableCheckbox = document.getElementById('available-checkbox');
    availableCheckbox.checked = true; 

    settingsButton.addEventListener('click', () => {
        settingsPopup.classList.toggle('hidden');
    });

    searchButton.addEventListener('click', handleSearch);
    searchInput.addEventListener('input', debounce(handleSearch, 300));
    availableCheckbox.addEventListener('change', handleSearch);

    async function handleSearch() {
        const query = searchInput.value.trim();
        const onlyAvailable = availableCheckbox.checked;

        if (query === '') {
            searchResults.innerHTML = '';
            return;
        }

        try {
            const response = await fetch('https://graphql.anilist.co', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: `
                        query ($search: String) {
                            Page {
                                media(search: $search, type: ANIME) {
                                    id
                                    title {
                                        romaji
                                        english
                                        native
                                    }
                                    genres
                                    averageScore
                                    coverImage {
                                        medium
                                    }
                                    isAdult
                                }
                            }
                        }
                    `,
                    variables: { search: query },
                }),
            });

            const data = await response.json();
            const animeList = data.data.Page.media;

            let filteredAnimeList = animeList.filter(anime => !anime.isAdult);

            if (onlyAvailable) {
                const animeIds = filteredAnimeList.map((anime) => anime.id);
                const animeAvailability = await checkAnimeAvailability(animeIds);

                filteredAnimeList = filteredAnimeList.filter((anime) => {
                    return animeAvailability[anime.id] === "available";
                });
            }

            if (filteredAnimeList.length > 0) {
    const resultsHTML = filteredAnimeList.map((anime) => {
        const genres = anime.genres.slice(0, 3).join(', ');

        // Periksa apakah ID Telegram ada dalam tabel "admins"
        const showEditIcon = <?php echo $show_edit_icon ? 'true' : 'false'; ?>;

            return `
        <div class="flex items-center justify-between mt-4">
            <div class="flex items-center">
                <img src="${anime.coverImage.medium}" alt="${anime.title.romaji}" class="w-16 h-16 rounded-lg">
                <div class="ml-4">
                    <div class="font-bold">${anime.title.romaji}</div>
                    <div class="text-sm text-gray-500">${genres}</div>
                    <div class="text-sm text-gray-500">Rating: ${anime.averageScore}</div>
                </div>
            </div>
            <div class="flex items-center">
                <a class="text-secondary mx-2 play-button" href="streaming.php?anime_id=${anime.id}">
                            <i class="fa fa-play"></i>
                        </a>
                <button class="text-secondary mx-2" style="display: ${showEditIcon ? 'block' : 'none'};" 
                    data-anime-id="${anime.id}" onclick="openEditModal(${anime.id})">
                    <i class="fa fa-edit"></i>
                </button>
            </div>
        </div>
    `;
}).join('');

searchResults.innerHTML = resultsHTML;
} else {
    searchResults.innerHTML = 'No results found';
}
        } catch (error) {
            console.error(error);
            searchResults.innerHTML = 'An error occurred while fetching data';
        }
    }

    function debounce(func, wait) {
        let timeout;
        return function () {
            clearTimeout(timeout);
            timeout = setTimeout(func, wait);
        };
    }

    async function checkAnimeAvailability(animeIds) {
        try {
            const response = await fetch('check_anime.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(animeIds),
            });

            const data = await response.json();

            return data;
        } catch (error) {
            console.error(error);
            return {};
        }
    }

    function openEditModal(animeId) {
        const editModal = document.getElementById('edit-modal');
        editModal.classList.remove('hidden');

        editModal.setAttribute('data-anime-id', animeId);

        const iframe = document.getElementById('edit-iframe');
        iframe.src = `manage_anime.php?anime_id=${animeId}`;
    }

    function closeModal() {
        const editModal = document.getElementById('edit-modal');
        editModal.classList.add('hidden');
    }
   
    
    </script>

<div id="edit-modal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full max-w-full">
            <div class="bg-white">
                <div class="resizable">
                    <iframe id="edit-iframe" src="" frameborder="0" class="w-full max-h-screen" style="resize: both; overflow: auto; max-width: 100%; height: 80vh;"></iframe>
                </div>
                <button type="button" class="inline-flex items-center justify-center w-8 h-8 text-sm text-gray-700 bg-gray-200 border border-transparent rounded-full hover-bg-gray-300 focus:outline-none focus-visible-ring focus-visible-ring-gray-500 focus-visible-ring-opacity-75 absolute top-4 right-4" onclick="closeModal()">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>

<?php include 'navbar.php'; ?>
<script src="js/darkmode.js"></script>
<script src="js/smoothscroll/smooth-scroll.js"></script>
</body>
</html>
