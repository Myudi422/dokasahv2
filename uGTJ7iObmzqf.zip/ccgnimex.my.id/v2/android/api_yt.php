<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$apiKey = 'AIzaSyDA-woUkqUGZ-omCDYxCgxFFbsYG9yMcZ0'; // Replace with your YouTube API key
$videoDuration = 'short'; // Filter short videos

// Database connection
$db_host = 'localhost';
$db_user = 'ccgnimex';
$db_pass = 'aaaaaaac';
$db_name = 'ccgnimex';

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Function to check if a video with a specific video_title exists in the database
function videoWithTitleExistsInDatabase($video_title, $connection) {
    $escapedTitle = mysqli_real_escape_string($connection, $video_title);
    $query = "SELECT * FROM youtube_search_results WHERE video_title = '$escapedTitle'";
    $result = mysqli_query($connection, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($connection));
    }

    return mysqli_num_rows($result) > 0;
}

// Function to get YouTube video data based on video title and update the database
function getAndSaveYouTubeVideos($video_title, $connection, $apiKey, $videoDuration) {
    $encodedKeyword = urlencode($video_title . ' Shorts');
    $url = "https://www.googleapis.com/youtube/v3/search?key=$apiKey&q=$encodedKeyword&type=video&maxResults=15&videoDuration=$videoDuration";

    $response = file_get_contents($url);
    $data = json_decode($response, true);

    if (isset($data['items'])) {
        foreach ($data['items'] as $item) {
            $videoId = $item['id']['videoId'];
            $escapedTitle = mysqli_real_escape_string($connection, $video_title);

            // Insert video data into the database
            $insertQuery = "INSERT INTO youtube_search_results (video_title, video_id) VALUES ('$escapedTitle', '$videoId')";
            $insertResult = mysqli_query($connection, $insertQuery);

            if (!$insertResult) {
                die("Insert query failed: " . mysqli_error($connection));
            }
        }
    }
}

// Get video_title from the request (you should validate and sanitize input)
$video_title = isset($_GET['video_title']) ? $_GET['video_title'] : '';

if (!empty($video_title)) {
    // Check if videos for this video_title already exist in the database
    if (!videoWithTitleExistsInDatabase($video_title, $connection)) {
        // Retrieve videos from YouTube and save to the database
        getAndSaveYouTubeVideos($video_title, $connection, $apiKey, $videoDuration);
    }

    // Get 6 random videos for the specified video_title
    $escapedTitle = mysqli_real_escape_string($connection, $video_title);
    $selectQuery = "SELECT * FROM youtube_search_results WHERE video_title = '$escapedTitle' ORDER BY RAND() LIMIT 9";
    $selectResult = mysqli_query($connection, $selectQuery);

    if (!$selectResult) {
        die("Select query failed: " . mysqli_error($connection));
    }

    if (mysqli_num_rows($selectResult) > 0) {
        while ($row = mysqli_fetch_assoc($selectResult)) {
            $videoId = $row['video_id'];
            $videoURL = "https://www.youtube.com/watch?v=$videoId";

            // Output YouTube links
            echo $videoURL . PHP_EOL;
        }
    } else {
        echo "No videos found for the specified video_title.";
    }
} else {
    echo "Invalid video_title.";
}

// Close database connection
mysqli_close($connection);
?>
