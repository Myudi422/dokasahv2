<?php

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: *");

// URL API Python
$pythonApiUrl = "https://ongoing.ccgnimex.my.id/resolusi";

// Fungsi untuk memanggil API Python
function callPythonApi($url, $method = 'GET', $data = null) {
    $ch = curl_init();
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_URL => $url,
    ];

    if ($method === 'POST' && $data) {
        $options[CURLOPT_POSTFIELDS] = http_build_query($data);
        $options[CURLOPT_HTTPHEADER] = [
            'Content-Type: application/x-www-form-urlencoded'
        ];
    }

    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            'error' => true,
            'message' => "cURL Error: $error",
            'http_code' => $httpCode
        ];
    }

    curl_close($ch);
    return [
        'error' => false,
        'response' => $response,
        'http_code' => $httpCode
    ];
}

// Mendapatkan metode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Validasi metode HTTP (hanya mendukung GET)
if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => true, 'message' => 'Method Not Allowed']);
    exit;
}

// Mendapatkan parameter
$animeId = isset($_GET['anime_id']) ? $_GET['anime_id'] : null;
$episodeNumber = isset($_GET['episode_number']) ? $_GET['episode_number'] : null;

// Validasi parameter
if (!$animeId || !$episodeNumber) {
    http_response_code(400);
    echo json_encode(['error' => true, 'message' => 'Anime ID and Episode Number are required']);
    exit;
}

// Membentuk URL untuk API Python
$queryParams = http_build_query([
    'anime_id' => $animeId,
    'episode_number' => $episodeNumber
]);
$url = $pythonApiUrl . "/?" . $queryParams;

// Memanggil API Python
$result = callPythonApi($url, 'GET');

// Mengembalikan respons
if ($result['error']) {
    http_response_code(500);
    echo json_encode(['error' => true, 'message' => $result['message']]);
} else {
    http_response_code($result['http_code']);
    header('Content-Type: application/json');
    echo $result['response'];
}
?>
