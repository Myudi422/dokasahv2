<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database
$conn = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Menangani parameter page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Query untuk mengambil data acak pada halaman pertama
$randomQuery = "SELECT * FROM wallpaper_anime ORDER BY RAND() LIMIT $limit";

// Query utama berdasarkan halaman
$query = ($page === 1) ? $randomQuery : "
    SELECT w.* FROM wallpaper_anime w
    LEFT JOIN (
        SELECT art_id FROM wallpaper_anime ORDER BY RAND() LIMIT $offset
    ) t ON w.art_id = t.art_id
    WHERE t.art_id IS NULL
    ORDER BY RAND() LIMIT $limit
";

// Ambil data dari tabel
$result = $conn->query($query);

// Memeriksa apakah terdapat data
if ($result->num_rows > 0) {
    $data = [];

    // Memasukkan data ke dalam array
    while ($row = $result->fetch_assoc()) {
        // Add both "md" and "ori" versions of the image URL
        $row['arturl_md'] = transformImageUrl($row['arturl']);
        $row['arturl_ori'] = $row['arturl'];

        // Unset the original 'arturl' key if not needed in the response
        unset($row['arturl']);

        $data[] = $row;
    }

    // Menghasilkan respons JSON
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
} else {
    echo "No data found";
}

// Function to transform the original image URL to the new format
function transformImageUrl($originalUrl) {
    // Example transformation logic: replace 'ori' with 'md'
    return str_replace('/ori/', '/md/', $originalUrl);
}

// Tutup koneksi
$conn->close();
?>
