<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$url = "https://api.nekosapi.com/v3/images/random";

$params = array(
    'rating' => array('safe'), // Filter hanya gambar dengan rating safe
    'sensitivity' => 0 // Menambahkan default parameter sensitivity
);

$queryString = http_build_query($params);

$fullUrl = $url . '?' . $queryString;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $fullUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);

if ($response === false) {
    echo 'Error: ' . curl_error($ch);
} else {
    // Dekode respons JSON menjadi array
    $data = json_decode($response, true);

    // Check if items exist in the response
    if (isset($data['items']) && is_array($data['items']) && count($data['items']) > 0) {
        // Filter hanya item dengan rating "safe" dan tag "is_nsfw" yang tidak disetel ke true
        $safe_items = array_filter($data['items'], function($item) {
            return $item['rating'] === 'safe' && !in_array(true, array_column($item['tags'], 'is_nsfw'));
        });

        // Mengonversi data item ke format yang diinginkan
        $formatted_items = [];
        foreach ($safe_items as $item) {
            $formatted_item = array(
                'id_v2' => $item['id_v2'],
                'image_size' => $item['image_size'],
                'image_width' => $item['image_width'],
                'image_height' => $item['image_height'],
                'sample_size' => $item['sample_size'],
                'sample_width' => $item['sample_width'],
                'sample_height' => $item['sample_height'],
                'source' => $item['source'],
                'source_id' => $item['source_id'],
                'rating' => $item['rating'],
                'verification' => $item['verification'],
                'hash_md5' => $item['hash_md5'],
                'hash_perceptual' => $item['hash_perceptual'],
                'color_dominant' => $item['color_dominant'],
                'color_palette' => $item['color_palette'],
                'duration' => $item['duration'],
                'is_original' => $item['is_original'],
                'is_screenshot' => $item['is_screenshot'],
                'is_flagged' => $item['is_flagged'],
                'is_animated' => $item['is_animated'],
                'artist' => $item['artist'],
                'characters' => $item['characters'],
                'tags' => $item['tags'],
                'created_at' => $item['created_at'],
                'updated_at' => $item['updated_at'],
                'arturl_ori' => $item['image_url'], // Menggunakan image_url sebagai arturl_ori
                'arturl_md' => $item['sample_url'], // Menggunakan sample_url sebagai arturl_md
                'art_id' => strval($item['id']), // Menggunakan id sebagai art_id
                'sensitivity' => '0' // Menambahkan sensitivity dengan nilai 0
            );

            $formatted_items[] = $formatted_item;
        }

        // Set header response sebagai JSON
        header('Content-Type: application/json');

        // Tampilkan data JSON yang telah diformat
        echo json_encode($formatted_items);
    } else {
        // Jika tidak ada item, kirimkan pesan kosong
        echo json_encode([]);
    }
}

curl_close($ch);

?>
