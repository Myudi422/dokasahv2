<?php

// URL endpoint untuk antarmuka
$url = 'https://pic.re/image';

// Inisialisasi array untuk menyimpan respons
$responses = array();

// Lakukan 10 kali permintaan ke URL
for ($i = 0; $i < 10; $i++) {
    // Inisialisasi curl
    $ch = curl_init();

    // Set URL
    curl_setopt($ch, CURLOPT_URL, $url);

    // Set opsi untuk metode permintaan POST
    curl_setopt($ch, CURLOPT_POST, true);

    // Set opsi untuk mengembalikan konten sebagai string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Eksekusi curl dan simpan respons
    $response = curl_exec($ch);

    // Decode respons sebagai objek JSON
    $decoded_response = json_decode($response);

    // Modifikasi arturl_ori dan tambahkan arturl_md jika perlu
    if ($decoded_response && property_exists($decoded_response, 'file_url')) {
        $decoded_response->arturl_ori = fixArtUrl($decoded_response->file_url);
        $decoded_response->arturl_md = $decoded_response->arturl_ori;
        unset($decoded_response->file_url); // Hapus file_url yang lama
    }

    // Tambahkan respons yang telah dimodifikasi ke dalam array
    $responses[] = $decoded_response;

    // Tutup curl
    curl_close($ch);
}

// Set header JSON
header('Content-Type: application/json');

// Tampilkan data JSON yang diberikan
echo json_encode($responses, JSON_PRETTY_PRINT);

// Fungsi untuk memperbaiki arturl_ori jika perlu
function fixArtUrl($file_url) {
    // Periksa apakah arturl_ori sudah mengandung "https://"
    if (!preg_match("~^(?:f|ht)tps?://~i", $file_url)) {
        // Jika tidak, tambahkan "https://"
        $file_url = "https://" . $file_url;
    }
    return $file_url;
}
?>
