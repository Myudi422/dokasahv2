<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Connection to database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch slider data from the database
$sql = "SELECT id, image_url, link, page, anime_id FROM slider_img";
$result = $conn->query($sql);

$sliderData = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sliderData[] = $row;
    }
}

// Separate item with ID "1"
$item_with_id_1 = null;
$other_items = array();

foreach ($sliderData as $item) {
    if ($item['id'] == 1) {
        $item_with_id_1 = $item;
    } else {
        $other_items[] = $item;
    }
}

// Randomize other items and take 3 random items
shuffle($other_items);
$random_items = array_slice($other_items, 0, 3);

// Merge item with ID "1" and random items
$final_slider_data = array_merge(array($item_with_id_1), $random_items);

$conn->close();

// Output slider data as JSON
header('Content-Type: application/json');
echo json_encode($final_slider_data);
?>
