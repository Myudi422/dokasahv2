<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database
$host = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$koneksi = mysqli_connect($host, $username, $password, $database);

// Periksa koneksi
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Fungsi untuk mendapatkan anime berdasarkan seed
function getAnimeByHourlySeed($koneksi) {
    $seed = floor(time() / 3600); // Ubah seed setiap jam
    $query = "SELECT * FROM anilist_data ORDER BY RAND($seed) LIMIT 12";
    $result = mysqli_query($koneksi, $query);
    $animeArray = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $animeArray[] = $row;
    }

    return $animeArray;
}

// Fungsi untuk menghasilkan JSON
function generateJSON($koneksi) {
    $animeData = getAnimeByHourlySeed($koneksi);
    $jsonResponse = json_encode($animeData);

    return $jsonResponse;
}

// Mendapatkan JSON untuk API
$jsonData = generateJSON($koneksi);

// Mengatur header untuk memberitahu bahwa ini adalah JSON
header('Content-Type: application/json');

// Mencetak JSON
echo $jsonData;

// Menutup koneksi database
mysqli_close($koneksi);
?>
