<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$host = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

// Membuat koneksi ke database
$conn = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Mengambil data versi terbaru dari database
$query = "SELECT version, changelog, update_required FROM app_version ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);

// Memeriksa apakah data ditemukan
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $latestVersion = $row["version"];
    $changelog = $row["changelog"];
    
    // Memastikan nilai update_required sesuai dengan keinginan
    $updateRequired = $row["update_required"] === '1' ? true : false;
} else {
    // Jika tidak ada data, menetapkan versi terbaru dan log perubahan kosong
    $latestVersion = "0";
    $changelog = "";
    $updateRequired = false;
}

// Membuat respons JSON
$response = array(
    "update_required" => $updateRequired,
    "latest_version" => $latestVersion,
    "changelog" => $changelog
);

// Mengirim respons JSON
echo json_encode($response);

// Menutup koneksi database
$conn->close();
?>
