<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $allowed_extensions = ['gif', 'png', 'jpeg', 'jpg'];
    $telegram_id = $_POST['telegram_id'] ?? '';
    $banner_url = $_POST['banner_url'] ?? '';

    if (empty($telegram_id) || empty($banner_url)) {
        echo json_encode(['success' => false, 'message' => 'Telegram ID atau URL banner tidak boleh kosong']);
        exit;
    }

    // Cek ekstensi file dari URL
    $file_extension = strtolower(pathinfo(parse_url($banner_url, PHP_URL_PATH), PATHINFO_EXTENSION));

    if (!in_array($file_extension, $allowed_extensions)) {
        echo json_encode(['success' => false, 'message' => 'Format file tidak didukung. Hanya GIF, PNG, JPEG yang diperbolehkan.']);
        exit;
    }

    // Koneksi ke database
    $conn = new mysqli('localhost', 'ccgnimex', 'aaaaaaac', 'ccgnimex'); // Sesuaikan dengan detail database

    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'Koneksi database gagal: ' . $conn->connect_error]);
        exit;
    }

    $telegram_id = $conn->real_escape_string($telegram_id);
    $banner_url = $conn->real_escape_string($banner_url);

    // Update banner URL di tabel users_web
    $sql = "UPDATE users_web SET banner_picture = '$banner_url' WHERE telegram_id = '$telegram_id'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Banner berhasil diperbarui']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal memperbarui banner: ' . $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Metode request tidak valid']);
}
?>
