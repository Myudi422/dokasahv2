<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database (ganti dengan informasi koneksi sesuai dengan konfigurasi Anda)
$host = 'localhost';
$dbname = 'ccgnimex';
$username = 'ccgnimex';
$password = 'aaaaaaac';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Fungsi untuk mendapatkan data anime berdasarkan telegram_id
function getAnimeByTelegramId($telegram_id) {
    global $pdo;

    try {
        // Query untuk mendapatkan data anime berdasarkan telegram_id
        $query = "SELECT fav_anime.anime_id, fav_anime.created_at, anilist_data.judul, anilist_data.image 
                  FROM fav_anime 
                  INNER JOIN anilist_data ON fav_anime.anime_id = anilist_data.anime_id 
                  WHERE fav_anime.telegram_id = :telegram_id";

        $stmt = $pdo->prepare($query);
        $stmt->execute(array(':telegram_id' => $telegram_id));

        // Mengambil hasil query sebagai array asosiatif
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    } catch (PDOException $e) {
        return array('error' => 'Gagal mengambil data: ' . $e->getMessage());
    }
}

// Contoh penggunaan: mencari data anime berdasarkan telegram_id
$telegram_id = $_GET['telegram_id']; // Ambil parameter telegram_id dari URL
if ($telegram_id) {
    $anime_data = getAnimeByTelegramId($telegram_id);
    header('Content-Type: application/json');
    echo json_encode($anime_data);
} else {
    echo "Silakan berikan parameter telegram_id";
}
?>
