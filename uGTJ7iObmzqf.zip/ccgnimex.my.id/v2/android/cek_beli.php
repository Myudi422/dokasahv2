<?php
// Set header untuk memastikan respons JSON
header('Content-Type: application/json');

// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Fungsi untuk memeriksa apakah pengguna sudah berlangganan premium
function checkPremiumSubscription($conn, $telegramId) {
    // Pastikan nilai telegram_id tidak null atau kosong
    if (empty($telegramId)) {
        return array("error" => "Telegram ID tidak valid");
    }

    // Siapkan statement SQL untuk memeriksa apakah pengguna sudah berlangganan premium
    $sql = "SELECT * FROM users_web WHERE telegram_id = '$telegramId' AND akses = 'premium' AND expired > NOW()";

    // Periksa koneksi
    if ($conn->connect_error) {
        return array("error" => "Koneksi database gagal: " . $conn->connect_error);
    }

    // Eksekusi query SQL
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        // Ambil data expired jika pengguna sudah berlangganan premium
        $row = $result->fetch_assoc();
        $expired = $row['expired'];
        
        // Pengguna sudah berlangganan premium
        return array("premium" => true, "expired" => $expired);
    } else {
        // Pengguna belum berlangganan premium
        return array("premium" => false);
    }
}

// Buat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari parameter URL (GET request)
$telegramId = $_GET['telegram_id'] ?? null;

// Panggil fungsi untuk memeriksa apakah pengguna sudah berlangganan premium jika telegramId tidak kosong
if ($telegramId) {
    $response = checkPremiumSubscription($conn, $telegramId);
} else {
    $response = array("error" => "Telegram ID tidak valid");
}

// Tutup koneksi ke database
$conn->close();

// Mengembalikan respons dalam format JSON
echo json_encode($response);
?>
