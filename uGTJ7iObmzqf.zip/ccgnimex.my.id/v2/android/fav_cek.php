<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Database connection
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from POST request
$animeId = $_POST['animeId'];
$telegramId = $_POST['telegramId'];

// Check if the anime is already in favorites
$sqlCheck = "SELECT * FROM fav_anime WHERE anime_id = $animeId AND telegram_id = '$telegramId'";
$resultCheck = $conn->query($sqlCheck);

if ($resultCheck->num_rows > 0) {
    echo "Anime already in favorites";
} else {
    echo "Anime not in favorites";
}

$conn->close();

?>
