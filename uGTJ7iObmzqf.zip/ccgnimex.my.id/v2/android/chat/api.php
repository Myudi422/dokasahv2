<?php
// Daftar kata yang ingin difilter
$filterWords = array(
    "promosi", "join", "judi", "tolol", "anjing", 
    "ngentot", "memek", "kontol", "bokep", "hentai", 
    "kode", "nekopoi", "jav", "xnxx", "vpn", "gore"
);

// Karakter pengganti untuk kata yang difilter
$replacement = "**badword**";

// Sesuaikan dengan detail koneksi ke database Anda
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Buat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set karakter set untuk koneksi
$conn->set_charset("utf8mb4");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    $telegramId = $conn->real_escape_string($data->sender_telegram_id);
    $messageText = $conn->real_escape_string($data->message_text);
    $firstName = $conn->real_escape_string($data->first_name);
    $premiumStatus = $conn->real_escape_string($data->akses);
    $profilePicture = $conn->real_escape_string($data->profile_picture);

    // Filter kata
    foreach ($filterWords as $word) {
        $messageText = str_ireplace($word, $replacement, $messageText);
    }

    // Pengecekan pesan tidak boleh kosong atau mengandung tautan
    if (empty($messageText) || preg_match('/https?:\/\/\S+/', $messageText)) {
        echo "Error: Pesan tidak boleh kosong atau mengandung tautan.";
        exit;
    }

    // Cek pesan duplikat dalam 5 detik terakhir
    $checkDuplicateSql = "SELECT * FROM chatroom_messages 
                          WHERE telegram_id = ? 
                          AND message_text = ? 
                          AND timestamp > NOW() - INTERVAL 5 SECOND";
    
    $checkStmt = $conn->prepare($checkDuplicateSql);
    $checkStmt->bind_param("ss", $telegramId, $messageText);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        echo "Error: Pesan duplikat dalam 5 detik terakhir tidak diizinkan.";
        exit;
    }

    $checkStmt->close();

    // Insert pesan baru
    #$sql = "INSERT INTO chatroom_messages (telegram_id, message_text, first_name, akses, profile_picture) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $telegramId, $messageText, $firstName, $premiumStatus, $profilePicture);

    if ($stmt->execute()) {
        echo "Pesan berhasil dikirim ke chatroom";

        // Hapus pesan paling lama jika jumlah pesan melebihi batas
        $limit = 100;
        $deleteOldMessageSql = "DELETE FROM chatroom_messages 
                                WHERE id = (SELECT id FROM chatroom_messages 
                                ORDER BY timestamp ASC LIMIT 1 OFFSET $limit)";

        $conn->query($deleteOldMessageSql);
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();

} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Mengambil data gabungan dari users_web dan chatroom_messages
    // Hanya jika telegram_id dan profile_picture cocok
    $sql = "SELECT 
        cm.telegram_id,
        cm.message_text,
        uw.first_name,
        uw.akses,
        uw.profile_picture,
        uw.id_web,
        CONVERT_TZ(cm.timestamp, 'SYSTEM', '+00:00') as timestamp
    FROM chatroom_messages cm
    INNER JOIN users_web uw 
    ON cm.telegram_id = uw.telegram_id 
    AND cm.profile_picture = uw.profile_picture
    ORDER BY cm.timestamp ASC;";

    $result = $conn->query($sql);

    $combinedData = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $filteredRow = [];

            // Memasukkan hanya nilai yang tidak null
            foreach ($row as $key => $value) {
                if ($value !== null) {
                    $filteredRow[$key] = $value;
                }
            }

            $combinedData[] = $filteredRow;
        }
    }

    #header('Content-Type: application/json');
    #echo json_encode($combinedData, JSON_PRETTY_PRINT);
}

$conn->close();
?>
