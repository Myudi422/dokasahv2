<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Headers: *");

$server = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

$conn = new mysqli($server, $username, $password, $database);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$telegram_id = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : null;
$latest_chat = isset($_POST['latest_chat']) ? $_POST['latest_chat'] : null;

if (empty($telegram_id) || empty($latest_chat)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing telegram_id or latest_chat parameter']);
    $conn->close();
    exit();
}

// Debug: Log received parameters
error_log("Telegram ID received: $telegram_id");
error_log("Latest chat received: $latest_chat");

// Update latest_chat for the given telegram_id
$sql_update = "UPDATE users_web SET latest_chat='$latest_chat' WHERE telegram_id='$telegram_id'";
if ($conn->query($sql_update) === TRUE) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error updating record: ' . $conn->error]);
}

$conn->close();
?>
