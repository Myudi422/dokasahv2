<?php
// Fungsi untuk mengirim notifikasi menggunakan FCM
function sendNotification($fcmToken, $message) {
    $serverKey = 'AAAAGNTCOh4:APA91bGx5SsfMsv3dQfUpivkZlxesI4wNISaE-Ix68Nr5efhDI6Dx5q4MzWwBJ6cKUj02-cFpRCBg7esIfJd18lV91BjiaR39CLZl3-NziUKez2MbevDG34JbkTi8RyYonMYv8-TX--B';
    $url = 'https://fcm.googleapis.com/fcm/send';

    $fields = [
        'to' => $fcmToken,
        'notification' => [
            'title' => 'Notification Test',
            'body'  => $message,
        ],
    ];

    $headers = [
        'Authorization: key=' . $serverKey,
        'Content-Type: application/json'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if(curl_errno($ch)) {
        $result = 'Error: ' . curl_error($ch);
    }
    curl_close($ch);

    return "HTTP Code: $httpCode, Response: $result";
}


$response = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fcmToken = trim($_POST['fcmToken'] ?? '');
    $message  = trim($_POST['message'] ?? '');

    if ($fcmToken && $message) {
        $response = sendNotification($fcmToken, $message);
    } else {
        $response = 'Field token atau message tidak boleh kosong.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Send Notification</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        label { display: block; margin-top: 10px; }
        input[type="text"], textarea { width: 100%; max-width: 500px; padding: 8px; }
        input[type="submit"] { margin-top: 10px; padding: 10px 20px; }
        .response { margin-top: 20px; background: #f4f4f4; padding: 10px; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <h1>Kirim Notifikasi via FCM</h1>
    <form method="post" action="">
        <label for="fcmToken">FCM Token:</label>
        <input type="text" id="fcmToken" name="fcmToken" required>

        <label for="message">Pesan:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <input type="submit" value="Kirim Notifikasi">
    </form>

    <?php if ($response): ?>
        <div class="response">
            <h3>Response:</h3>
            <pre><?php echo htmlspecialchars($response); ?></pre>
        </div>
    <?php endif; ?>
</body>
</html>
