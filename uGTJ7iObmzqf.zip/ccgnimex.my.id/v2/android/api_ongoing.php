<?php

// Set the URL of the API you want to access
$target_url = "https://ongoing.ccgnimex.my.id/anime";

// Initialize a cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $target_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json', // Adjust headers if needed
]);

// Execute the cURL request and get the response
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'error' => 'Failed to fetch data from target API',
        'details' => curl_error($ch)
    ], JSON_PRETTY_PRINT);
    curl_close($ch);
    exit;
}

// Get HTTP status code of the response
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Close the cURL session
curl_close($ch);

// Forward the response with the same HTTP status code as the target API
http_response_code($http_code);
header('Content-Type: application/json'); // Ensure JSON response format

echo json_encode(json_decode($response), JSON_PRETTY_PRINT);

?>
