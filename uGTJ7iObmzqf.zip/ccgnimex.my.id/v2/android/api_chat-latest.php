<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Konfigurasi database
$server = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

// Membuat koneksi ke database
$conn = new mysqli($server, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed']));
}

// Cek apakah method request adalah POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mendapatkan data dari POST request
    $telegram_id = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
    $latest_chat = isset($_POST['latest_chat']) ? $_POST['latest_chat'] : '';

    // Validasi input
    if (!empty($telegram_id) && !empty($latest_chat)) {
        // Query untuk mengupdate latest_chat berdasarkan telegram_id
        $query = "UPDATE users_web SET latest_chat = ? WHERE telegram_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('is', $latest_chat, $telegram_id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'latest_chat updated successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update latest_chat']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Menutup koneksi database
$conn->close();
?>
