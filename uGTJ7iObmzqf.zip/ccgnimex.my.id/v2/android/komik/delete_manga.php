<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Get parameters from request
$telegram_id = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
$manga_url = isset($_POST['manga_url']) ? $_POST['manga_url'] : '';

if (empty($telegram_id) || empty($manga_url)) {
    echo json_encode(["status" => "error", "message" => "Missing parameters"]);
    exit;
}

// Prepare SQL query to delete manga from favorites
$query = "DELETE FROM fav_manga WHERE telegram_id = ? AND komik_url = ?";  // Menggunakan 'komik_url' sesuai kolom yang ada di 'add manga'
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $telegram_id, $manga_url);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Manga removed from favorites"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Manga not found in favorites"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Failed to remove manga from favorites"]);
}

$stmt->close();
$conn->close();
?>
