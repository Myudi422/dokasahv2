<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Get parameters from request
$telegram_id = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
$manga_url = isset($_POST['manga_url']) ? $_POST['manga_url'] : '';

if (empty($telegram_id) || empty($manga_url)) {
    echo json_encode(["status" => "error", "message" => "Missing parameters"]);
    exit;
}

// Prepare SQL query to check if manga is a favorite
$query = "SELECT * FROM fav_manga WHERE telegram_id = ? AND komik_url = ?";  // Sesuaikan 'komik_url' dengan nama kolom yang benar
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $telegram_id, $manga_url);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["status" => "success", "isFavorite" => true, "message" => "Manga is in favorites"]);
} else {
    echo json_encode(["status" => "success", "isFavorite" => false, "message" => "Manga is not in favorites"]);
}

$stmt->close();
$conn->close();
?>
