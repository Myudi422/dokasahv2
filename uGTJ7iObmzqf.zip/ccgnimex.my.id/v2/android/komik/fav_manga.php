<?php
header('Content-Type: application/json');

// Connect to the database
$conn = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Collect POST data
$telegram_id = $_POST['telegram_id'];
$manga_url = $_POST['manga_url'];
$title = $_POST['title'];
$link_gambar = $_POST['link_gambar'];

// Check if the manga already exists in the fav_manga table
$checkStmt = $conn->prepare("SELECT * FROM fav_manga WHERE komik_url = ? AND telegram_id = ?");
$checkStmt->bind_param("ss", $manga_url, $telegram_id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Manga already added to favorites"]);
} else {
    // Insert data into fav_manga table
    $stmt = $conn->prepare("INSERT INTO fav_manga (komik_url, title, telegram_id, link_gambar) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $manga_url, $title, $telegram_id, $link_gambar);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Manga added to favorites"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add manga"]);
    }
    $stmt->close();
}

$checkStmt->close();
$conn->close();
