<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");
// Database connection parameters
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

// Set the Content-Type header to application/json
header("Content-Type: application/json");

// Check if 'telegram_id' is provided in the request
if (!isset($_GET['telegram_id'])) {
    echo json_encode(["status" => "error", "message" => "telegram_id parameter is required"]);
    exit;
}

// Sanitize and assign 'telegram_id' parameter
$telegram_id = $conn->real_escape_string($_GET['telegram_id']);

// Query to fetch favorite manga data for the provided telegram_id
$sql = "SELECT komik_url, title, link_gambar FROM fav_manga WHERE telegram_id = '$telegram_id'";
$result = $conn->query($sql);

// Check if any data was retrieved
if ($result && $result->num_rows > 0) {
    $mangaList = [];

    // Fetch each row and add it to the manga list array
    while ($row = $result->fetch_assoc()) {
        $mangaList[] = [
            "komik_url" => $row["komik_url"],
            "title" => $row["title"],
            "link_gambar" => $row["link_gambar"]
        ];
    }

    // Output the manga list as JSON
    echo json_encode(["status" => "success", "data" => $mangaList]);
} else {
    // Output an empty data array if no manga found for the user
    echo json_encode(["status" => "success", "data" => []]);
}

// Close the database connection
$conn->close();
?>
