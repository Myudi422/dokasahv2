<?php

// Fungsi untuk melakukan koneksi ke database
function connectToDatabase() {
    $host = 'localhost';
    $username = 'ccgnimex';
    $password = 'aaaaaaac';
    $database = 'ccgnimex';

    $connection = new mysqli($host, $username, $password, $database);

    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    return $connection;
}

// Fungsi untuk mendapatkan data dari tabel manga_history berdasarkan telegram_id dan image_url
function getMangaHistoryByTelegramId($telegramId, $imageUrl, $connection) {
    $query = "SELECT title_eps FROM manga_history WHERE telegram_id = ? AND image = ?";
    $statement = $connection->prepare($query);
    $statement->bind_param("ss", $telegramId, $imageUrl);
    $statement->execute();
    $result = $statement->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['title_eps'];
    } else {
        return '';
    }
}

// Membuat koneksi ke database
$databaseConnection = connectToDatabase();

// URL base
$baseUrl = 'https://mangakita.id';
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$order = isset($_GET['order']) ? $_GET['order'] : 'update';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$genres = isset($_GET['genre']) ? $_GET['genre'] : [];
$telegramId = isset($_GET['telegram_id']) ? $_GET['telegram_id'] : '';

// Membuat URL dengan parameter pencarian, status, order by, dan genre
if (!empty($searchQuery)) {
    $url = $baseUrl . '/?s=' . urlencode($searchQuery);
} else {
    $url = $baseUrl . '/manga?page=' . $page . '&order=' . $order . '&status=' . $status;
    foreach ($genres as $genre) {
        $url .= '&genre%5B%5D=' . $genre;
    }
}

// Menyiapkan header untuk permintaan HTTP
$options = [
    'http' => [
        'method' => 'GET',
        'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
    ],
];

// Membuat context stream dengan opsi header
$context = stream_context_create($options);

// Memuat konten HTML dari URL dengan context stream
$html = file_get_contents($url, false, $context);

// Membuat DOMDocument dari konten HTML yang diperoleh
$dom = new DOMDocument();
libxml_use_internal_errors(true); // Mematikan error dan warning ketika parsing HTML
$dom->loadHTML($html);

// Mengaktifkan XPath untuk pencarian elemen
$xpath = new DOMXPath($dom);

// Mencari semua div dengan class 'listupd'
$listUpdDivs = $xpath->query("//div[contains(@class, 'listupd')]");

// Array untuk menyimpan data komik
$comics = [];

// Array untuk menyimpan URL komik yang sudah diambil
$visitedUrls = [];

// Iterasi melalui setiap div 'listupd'
foreach ($listUpdDivs as $listUpdDiv) {
    // Mencari semua elemen div dengan class 'bs' di dalam div 'listupd'
    $bsDivs = $xpath->query(".//div[contains(@class, 'bs')]", $listUpdDiv);

    // Iterasi melalui setiap elemen div 'bs'
    foreach ($bsDivs as $bsDiv) {
        // Mengambil URL komik dari atribut href
        $url = $xpath->evaluate("string(.//a/@href)", $bsDiv);

        // Memeriksa apakah URL komik sudah diambil sebelumnya
        if (in_array($url, $visitedUrls)) {
            continue; // Lewati jika sudah diambil sebelumnya
        }

        // Mengambil URL gambar
        $image = ''; // Default kosong jika tidak dapat menemukan URL gambar
        // Cek atribut src terlebih dahulu
        $imageNode = $xpath->query(".//img/@src", $bsDiv);
        if ($imageNode->length == 0) {
            // Jika tidak ada atribut src, coba atribut data-src
            $imageNode = $xpath->query(".//img/@data-src", $bsDiv);
        }

        if ($imageNode->length > 0) {
            // Ambil nilai atribut src atau data-src dari elemen img
            $imageUrl = $imageNode->item(0)->nodeValue;
            // Hapus parameter query untuk konsistensi dengan data di database
            $image = strtok($imageUrl, '?');
            if (!filter_var($image, FILTER_VALIDATE_URL)) {
                $image = '';
            }
        }

        // Menambahkan URL komik ke array visitedUrls
        $visitedUrls[] = $url;

        // Mengambil informasi komik
        $title = $xpath->evaluate("string(.//div[contains(@class, 'tt')])", $bsDiv);
        $chapter = $xpath->evaluate("string(.//div[contains(@class, 'epxs')])", $bsDiv);
        // Hapus bagian "bahasa indonesia" dari chapter
        $chapter = preg_replace('/\s*bahasa indonesia\s*/i', '', $chapter);
        // Bersihkan spasi ekstra dan newline pada title
        $title = trim($title);
        // Mengambil informasi kategori warna jika ada
        $colorCategory = $xpath->evaluate("string(.//span[contains(@class, 'colored')])", $bsDiv);

        // Mengambil *title_eps* dari history database berdasarkan telegram_id dan image_url
        $titleEps = '';
        if (!empty($telegramId)) {
            $titleEps = getMangaHistoryByTelegramId($telegramId, $image, $databaseConnection);
            // Jika perlu, format title_eps (misal hanya mengambil angka chapter)
            $titleEps = preg_replace("/Chapter (\d+(\.\d+)?).*/i", "$1", $titleEps);
        }

        // Menyimpan data komik ke dalam array
        $comics[] = [
            'title'         => $title,
            'url'           => $url,
            'chapter'       => $chapter,
            'image'         => $image,
            'colorCategory' => $colorCategory,
            'title_eps'     => $titleEps,
        ];
    }
}

// Mengembalikan data komik sebagai JSON response
header('Content-Type: application/json');
echo json_encode($comics, JSON_PRETTY_PRINT);

// Menutup koneksi ke database
$databaseConnection->close();

?>
