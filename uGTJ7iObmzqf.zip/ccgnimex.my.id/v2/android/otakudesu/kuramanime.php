<?php

// URL yang ingin di-scrape
$url = 'https://kuramanime.bid/anime/2428/bai-lian-cheng-shen-2nd-season/episode/40';

// Inisialisasi cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$html = curl_exec($ch);
curl_close($ch);

// Muat HTML ke DOMDocument
$dom = new DOMDocument;
libxml_use_internal_errors(true); // Supaya tidak terganggu dengan kesalahan parsing HTML
$dom->loadHTML($html);
libxml_clear_errors();

// Inisialisasi DOMXPath
$xpath = new DOMXPath($dom);

// Coba mencari elemen video dengan berbagai cara
$videoElements = $xpath->query('//video');
if ($videoElements->length > 0) {
    foreach ($videoElements as $videoElement) {
        $sources = $xpath->query('.//source', $videoElement);
        foreach ($sources as $source) {
            $src = $source->getAttribute('src');
            $type = $source->getAttribute('type');
            $size = $source->getAttribute('size');
            echo "URL: " . $src . "\n";
            echo "Type: " . $type . "\n";
            echo "Size: " . $size . "\n\n";
        }
    }
} else {
    echo "Video element not found.\n";
}

// Debug: Tampilkan sebagian HTML untuk pemeriksaan lebih lanjut
echo "Partial HTML for debugging:\n";
echo substr($html, 0, 2000); // Menampilkan 2000 karakter pertama dari HTML
