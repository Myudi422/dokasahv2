<?php
// Function to fetch and scrape anime data from the website using cURL
function fetchAnimeData($page) {
    $url = "https://otakudesu.cloud/ongoing-anime/page/" . $page;

    // Initialize cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // Enable SSL verification for security
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'); // Set User-Agent
    
    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        throw new Exception('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    // Check if the response is empty
    if (empty($response)) {
        throw new Exception('Empty response from the server.');
    }

    // Load the HTML content
    $animeList = [];
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress warnings due to malformed HTML
    $dom->loadHTML($response);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);

    // Select the anime list elements
    $items = $xpath->query('//*[@id="venkonten"]//div[contains(@class, "venutama")]//div[contains(@class, "rseries")]//ul/li');

    foreach ($items as $item) {
        $titleNode = $xpath->query('.//div/div[contains(@class, "thumb")]/a/div/h2', $item)->item(0);
        $thumbnailNode = $xpath->query('.//div/div[contains(@class, "thumb")]/a/div/img', $item)->item(0);
        $episodeNode = $xpath->query('.//div/div[contains(@class, "epz")]', $item)->item(0);
        $hrefNode = $xpath->query('.//div/div[contains(@class, "thumb")]/a', $item)->item(0);

        $title = $titleNode ? trim($titleNode->nodeValue) : null;
        $thumbnail = $thumbnailNode ? $thumbnailNode->getAttribute('src') : null;
        $episode = $episodeNode ? trim($episodeNode->nodeValue) : null;
        $href = $hrefNode ? $hrefNode->getAttribute('href') : null;

        // Extract anime ID from the URL
        $idParts = $href ? explode('/', trim($href, '/')) : [];
        $id = !empty($idParts) ? end($idParts) : null; // Get the last part

        // Extract the episode number
        $latestEpisode = preg_replace('/[^0-9]/', '', $episode);

        // Add anime to the list if valid data is found
        if (!empty($title) && !empty($thumbnail) && !empty($latestEpisode) && !empty($id)) {
            $animeList[] = [
                'anime_id' => $id, // The ID is a string
                'judul' => $title,
                'gambar' => $thumbnail,
                'latest_episode' => (int) $latestEpisode,
            ];
        }
    }

    return $animeList;
}

try {
    // Pages to scrape
    $pages = [1, 2, 3, 4];
    $allAnimeData = [];

    foreach ($pages as $page) {
        $animeData = fetchAnimeData($page);
        $allAnimeData = array_merge($allAnimeData, $animeData);

        // Optional: Add a delay to avoid overloading the server
        sleep(1);
    }

    // Return JSON response in the desired format
    header('Content-Type: application/json');
    echo json_encode([
        'ongoing_anime_data' => $allAnimeData,
    ]);
} catch (Exception $e) {
    // Handle any errors
    header('Content-Type: application/json', true, 500);
    echo json_encode([
        'status' => 500,
        'message' => $e->getMessage(),
    ]);
}
