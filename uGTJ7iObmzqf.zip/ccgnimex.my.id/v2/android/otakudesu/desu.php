<?php
$url = "https://desudrive.com/dstream/updesu/index.php?id=ZlkwdUo1OWJmWWQrUk95NUJzcUlhQT09";

// Initialize cURL session
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'); // Set User-Agent

// Execute the cURL request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
    curl_close($ch);
    exit;
}

curl_close($ch);

// Check if the response is empty
if (empty($response)) {
    echo 'Empty response from the server.';
    exit;
}

// Load HTML into DOMDocument
$dom = new DOMDocument;
libxml_use_internal_errors(true); // Suppress errors for invalid HTML
$dom->loadHTML($response);
libxml_clear_errors();

// Create a new DOMXPath object
$xpath = new DOMXPath($dom);

// Query for all script elements
$nodes = $xpath->query('//script');

// Extract content from the relevant script tag
$videoUrl = '';
foreach ($nodes as $node) {
    $scriptContent = $node->nodeValue;
    // Check if the script contains the video URL pattern
    if (strpos($scriptContent, 'sources: [{\'file\':') !== false) {
        // Extract the video URL using regex
        if (preg_match('/sources:\s*\[\{\'file\':\'(.*?)\'\}\]/', $scriptContent, $matches)) {
            $videoUrl = $matches[1];
            break;
        }
    }
}

if ($videoUrl) {
    // Create an array with the video URL
    $data = array(
        'video_url' => $videoUrl
    );

    // Encode the array into JSON format
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    echo json_encode(array('error' => 'No video URL found.'));
}
?>
