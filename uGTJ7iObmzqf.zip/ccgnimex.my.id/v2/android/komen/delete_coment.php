<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE");
header("Access-Control-Allow-Headers: *");
header('Content-Type: application/json');

// Enable error reporting for development (disable for production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Retrieve and sanitize DELETE data
$data = json_decode(file_get_contents("php://input"), true);
$id = isset($data['id']) ? intval($data['id']) : 0;
$telegram_id = isset($data['telegram_id']) ? $conn->real_escape_string($data['telegram_id']) : '';

// Validate input parameters
if ($id == 0 || empty($telegram_id)) {
    error_log("Invalid parameters. id: $id, telegram_id: $telegram_id");
    echo json_encode(["error" => "Invalid parameters."]);
    exit();
}

// Prepared statement to prevent SQL Injection
$sql = "DELETE FROM comments_app WHERE id = ? AND telegram_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
    exit();
}

$stmt->bind_param("is", $id, $telegram_id);

// Log parameters before execution (for debugging)
error_log("Deleting comment with id: $id and telegram_id: $telegram_id");

// Execute the statement
if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => "Comment deleted successfully."]);
    } else {
        echo json_encode(["error" => "No rows deleted. Check id and telegram_id."]);
    }
} else {
    error_log("Execute failed: " . $stmt->error);
    echo json_encode(["error" => "Failed to delete comment."]);
}

$stmt->close();
$conn->close();
?>
