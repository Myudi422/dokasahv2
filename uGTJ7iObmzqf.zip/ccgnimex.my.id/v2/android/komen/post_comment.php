<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$anime_id = isset($_POST['anime_id']) ? intval($_POST['anime_id']) : 0;
$episode_id = isset($_POST['episode_id']) ? intval($_POST['episode_id']) : 0;
$telegram_id = isset($_POST['telegram_id']) ? $conn->real_escape_string($_POST['telegram_id']) : '';
$comment = isset($_POST['comment']) ? $conn->real_escape_string($_POST['comment']) : '';

if ($anime_id == 0 || $episode_id == 0 || empty($telegram_id) || empty($comment)) {
    echo "Error: Missing required fields";
} else {
    // Get the user's access level
    $accessQuery = $conn->prepare("SELECT akses FROM users_web WHERE telegram_id = ?");
    $accessQuery->bind_param("s", $telegram_id);
    $accessQuery->execute();
    $accessResult = $accessQuery->get_result();
    $userAccess = $accessResult->fetch_assoc()['akses'];
    $accessQuery->close();

    // Set comment limits based on access level
    $maxComments = ($userAccess === 'Premium') ? 5 : 2;

    // Check the number of comments by this user for this anime and episode
    $countQuery = $conn->prepare("SELECT COUNT(*) as comment_count FROM comments_app WHERE anime_id = ? AND episode_id = ? AND telegram_id = ?");
    $countQuery->bind_param("iis", $anime_id, $episode_id, $telegram_id);
    $countQuery->execute();
    $countResult = $countQuery->get_result();
    $commentCount = $countResult->fetch_assoc()['comment_count'];
    $countQuery->close();

    if ($commentCount >= $maxComments) {
        echo "anda terkena limit, max 2 komen, premium max 5 komentar per episode";
    } else {
        // Insert the new comment
        $stmt = $conn->prepare("INSERT INTO comments_app (anime_id, episode_id, telegram_id, comment) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("iiss", $anime_id, $episode_id, $telegram_id, $comment);
            if ($stmt->execute()) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

$conn->close();
?>
