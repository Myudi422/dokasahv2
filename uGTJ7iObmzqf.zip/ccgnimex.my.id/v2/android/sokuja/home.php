<?php

// URL base
$baseUrl = 'https://x1.sokuja.uk/anime/';

// Membaca parameter query jika ada
$status = isset($_GET['status']) ? $_GET['status'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$order = isset($_GET['order']) ? $_GET['order'] : 'update';

// Membuat URL dengan parameter pencarian, status, order by, dan genre
$url = $baseUrl . '?status=' . urlencode($status) . '&type=' . urlencode($type) . '&order=' . urlencode($order);

// Menyiapkan header untuk permintaan HTTP
$options = [
    'http' => [
        'method' => 'GET',
        'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
    ],
];

// Membuat context stream dengan opsi header
$context = stream_context_create($options);

// Memuat konten HTML dari URL dengan context stream
$html = file_get_contents($url, false, $context);

// Membuat DOMDocument dari konten HTML yang diperoleh
$dom = new DOMDocument();
libxml_use_internal_errors(true); // Mematikan error dan warning ketika parsing HTML
$dom->loadHTML($html);

// Mengaktifkan XPath untuk pencarian elemen
$xpath = new DOMXPath($dom);

// Mencari semua div dengan class 'listupd'
$listUpdDivs = $xpath->query("//div[contains(@class, 'listupd')]");

// Array untuk menyimpan data anime
$ongoingAnimes = [];

// Array untuk menyimpan URL anime yang sudah diambil
$visitedUrls = [];

// Iterasi melalui setiap div 'listupd'
foreach ($listUpdDivs as $listUpdDiv) {
    // Mencari elemen article dengan class 'bs' di dalam div 'listupd'
    $articles = $xpath->query(".//article[contains(@class, 'bs')]", $listUpdDiv);

    // Iterasi melalui setiap elemen article 'bs'
    foreach ($articles as $article) {
        // Mengambil URL anime dari atribut href
        $animeUrl = $xpath->evaluate("string(.//a/@href)", $article);

        // Memeriksa apakah URL anime sudah diambil sebelumnya
        if (in_array($animeUrl, $visitedUrls)) {
            continue; // Lewati jika sudah diambil sebelumnya
        }

        // Mengambil URL gambar
        $image = '';
        $imageNode = $xpath->query(".//img/@src", $article);
        if ($imageNode->length > 0) {
            $imageUrl = $imageNode->item(0)->nodeValue;

            // Periksa apakah nilai src adalah URL gambar yang valid
            if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                $image = $imageUrl;
            }
        }

        // Menambahkan URL anime ke array visitedUrls
        $visitedUrls[] = $animeUrl;

        // Mengambil informasi anime
        $titleNodes = $xpath->query(".//div[contains(@class, 'tt')]", $article);
        $title = '';
        foreach ($titleNodes as $node) {
            $title .= $node->textContent; // Menggabungkan semua teks jika ada beberapa node
        }

        // Remove newline characters, tabs, and extra whitespaces from the title
        $title = trim(preg_replace('/\s+/', ' ', $title));

        // Placeholder for anime_id and latest_episode
        $animeId = ''; // Kosongkan jika tidak ada
        $latestEpisode = 'NEW'; // Default value for new anime

        // Example extraction logic for anime_id and latest_episode
        // You need to update this according to how these values are found in the HTML
        // $animeId = extract_anime_id($article); // Define this function as needed
        // $latestEpisode = extract_latest_episode($article); // Define this function as needed

        // Menyimpan data anime ke dalam array
        $ongoingAnimes[] = [
            'anime_id' => $animeId,
            'judul' => $title,
            'gambar' => $image,
            'latest_episode' => $latestEpisode,
        ];
    }
}

// Mengembalikan data anime sebagai JSON response
header('Content-Type: application/json');
echo json_encode(['ongoing_anime_data' => $ongoingAnimes], JSON_PRETTY_PRINT);
?>
