<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $allowed_extensions = ['gif', 'png', 'jpeg', 'jpg'];
    $telegram_id = $_POST['telegram_id'] ?? '';
    
    // Check if a file has been uploaded
    if (!isset($_FILES['banner']) || empty($telegram_id)) {
        echo json_encode(['success' => false, 'message' => 'Telegram ID atau file banner tidak boleh kosong']);
        exit;
    }

    $file = $_FILES['banner'];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($file_extension, $allowed_extensions)) {
        echo json_encode(['success' => false, 'message' => 'Format file tidak didukung. Hanya GIF, PNG, JPEG yang diperbolehkan.']);
        exit;
    }

    // Upload file to Buzzheavier
    $file_path = $file['tmp_name'];
    $file_name = $file['name'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://w.buzzheavier.com/$file_name");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_PUT, true);
    curl_setopt($ch, CURLOPT_INFILE, fopen($file_path, 'r'));
    curl_setopt($ch, CURLOPT_INFILESIZE, filesize($file_path));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ABMMQsx3W94'));

    $response = curl_exec($ch);
    curl_close($ch);

    if (!$response) {
        echo json_encode(['success' => false, 'message' => 'Gagal mengupload file ke Buzzheavier']);
        exit;
    }

    $banner_url = "https://w.buzzheavier.com/$file_name";

    // Koneksi ke database
    $conn = new mysqli('localhost', 'ccgnimex', 'aaaaaaac', 'ccgnimex'); // Sesuaikan dengan detail database

    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'Koneksi database gagal: ' . $conn->connect_error]);
        exit;
    }

    $telegram_id = $conn->real_escape_string($telegram_id);
    $banner_url = $conn->real_escape_string($banner_url);

    // Update banner URL di tabel users_web
    $sql = "UPDATE users_web SET banner_picture = '$banner_url' WHERE telegram_id = '$telegram_id'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Banner berhasil diperbarui', 'banner_url' => $banner_url]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal memperbarui banner: ' . $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Metode request tidak valid']);
}
?>
