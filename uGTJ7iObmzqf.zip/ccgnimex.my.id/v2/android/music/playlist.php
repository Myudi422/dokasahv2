<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Ambil data dari Flutter
$telegramId = isset($_GET['telegram_id']) ? $_GET['telegram_id'] : '';

// Logging
error_log("Received Telegram ID: " . $telegramId);

// Lakukan validasi data
if (empty($telegramId)) {
    $response = array('success' => false, 'message' => 'Invalid data provided');
    echo json_encode($response);
    exit();
}

// Logging
error_log("Data validation passed. Continuing with database operation.");

// Simpan ke database
$mysqli = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

if ($mysqli->connect_error) {
    die('Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error);
}

$stmt = $mysqli->prepare("SELECT DISTINCT playlist_name FROM playlists WHERE telegram_id = ?");
$stmt->bind_param("s", $telegramId);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $playlists = array();

    while ($row = $result->fetch_assoc()) {
        $playlists[] = $row;
    }

    $response = array('success' => true, 'playlists' => $playlists);
    // Logging
    error_log("Retrieved playlists successfully.");
} else {
    $response = array('success' => false, 'message' => 'Error retrieving playlists');
    // Logging
    error_log("Error retrieving playlists. MySQL error: " . $stmt->error);
}

$stmt->close();
$mysqli->close();

echo json_encode($response);
?>
