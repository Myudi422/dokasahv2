<?php
// Menghubungkan ke database (gantilah dengan informasi koneksi database Anda)
$host = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$conn = new mysqli($host, $username, $password, $database);

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Mengambil data dari formulir
$anime_id = $_POST['anime_id'];
$link = $_POST['link'];

// Query untuk menyimpan data ke dalam tabel slider
$sql = "INSERT INTO slider (anime_id, link) VALUES ('$anime_id', '$link')";

if ($conn->query($sql) === TRUE) {
    echo "Data berhasil disimpan.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi database
$conn->close();
?>
