<?php
// Koneksi Database
$host = 'localhost';
$dbname = 'ccgnimex';
$user = 'ccgnimex';
$password = 'aaaaaaac';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anime_id = $_POST['anime_id'];
    $slug = $_POST['slug'];
    $base_video_url = $_POST['base_video_url'];
    $judul = $_POST['judul']; // Judul dari input form
    $add_to_schedule = isset($_POST['add_to_schedule']);
    $schedule_time = $_POST['schedule_time'] ?? null;
    $schedule_day = $_POST['schedule_day'] ?? null;

    try {
        // Insert ke tabel sokuja
        $stmt = $pdo->prepare("INSERT INTO sokuja (anime_id, slug, base_video_url) VALUES (?, ?, ?)");
        $stmt->execute([$anime_id, $slug, $base_video_url]);

        // Jika judul diinputkan, masukkan langsung ke tabel anilist_data
        if (!empty($judul)) {
            $stmt = $pdo->prepare("INSERT INTO anilist_data (anime_id, judul) VALUES (?, ?)
                                   ON DUPLICATE KEY UPDATE judul = VALUES(judul)");
            $stmt->execute([$anime_id, $judul]);
        }

        // Jika 'Tambahkan ke Jadwal' dicentang
        if ($add_to_schedule && $schedule_time && $schedule_day) {
            $stmt = $pdo->prepare("INSERT INTO jadwal (anime_id, jam, hari) VALUES (?, ?, ?)");
            $stmt->execute([$anime_id, $schedule_time, $schedule_day]);
        }

        // Trigger scraping
        $scraping_url = "https://ccgnimex.my.id/v2/android/scrapping/index.php";
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $scraping_url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query(['anime_id' => $anime_id]),
            CURLOPT_RETURNTRANSFER => true,
        ]);

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($http_code === 200) {
            // Update judul jika kosong
            if (empty($judul)) {
                $stmt = $pdo->prepare("SELECT judul FROM anilist_data WHERE anime_id = ?");
                $stmt->execute([$anime_id]);
                $judul_scraped = $stmt->fetchColumn();

                if ($judul_scraped) {
                    echo "<p>Judul berhasil diperbarui setelah scraping: {$judul_scraped}</p>";
                } else {
                    echo "<p>Judul tidak ditemukan setelah scraping.</p>";
                }
            }
        } else {
            echo "<p>Scraping gagal untuk Anime ID {$anime_id}. Status Code: {$http_code}</p>";
        }

    } catch (Exception $e) {
        echo "<p>Error: " . $e->getMessage() . "</p>";
    }
}



if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM sokuja WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Scraping</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">
    <div class="container mx-auto bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-2xl font-bold mb-6 text-center">Management Scraping</h1>

        <!-- Tab Bar -->
        <div class="flex mb-6">
            <button class="tab-button px-4 py-2 bg-blue-500 text-white rounded-l-lg" data-target="#input-tab">+Input</button>
            <button class="tab-button px-4 py-2 bg-gray-200 rounded-r-lg" data-target="#manage-tab">Manage</button>
        </div>

<div id="input-tab" class="tab-content block">
    <form action="" method="POST" class="space-y-4">
        <div>
            <label for="anime_search" class="block font-medium">Search Anime:</label>
            <input type="text" id="anime_search" class="border p-2 rounded w-full" placeholder="Search by title">
            <button type="button" onclick="searchAnime()" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded">Search</button>
            <div id="search_results" class="mt-2"></div>
        </div>

        <div>
            <label for="anime_id" class="block font-medium">Anime ID:</label>
            <input type="text" name="anime_id" id="anime_id" class="border p-2 rounded w-full" required>
        </div>

        <div>
            <label for="slug" class="block font-medium">Slug:</label>
            <input type="text" name="slug" id="slug" class="border p-2 rounded w-full" required>
        </div>

        <div>
            <label for="base_video_url" class="block font-medium">Base Video URL:</label>
            <input type="url" name="base_video_url" id="base_video_url" class="border p-2 rounded w-full" required>
        </div>

        <div>
            <label for="judul" class="block font-medium">Judul:</label>
            <input type="text" name="judul" id="judul" class="border p-2 rounded w-full">
            <small class="text-gray-500">Judul akan diperbarui setelah proses scraping jika kosong.</small>
        </div>

        <div>
            <label for="add_to_schedule" class="inline-flex items-center">
                <input type="checkbox" name="add_to_schedule" id="add_to_schedule" class="mr-2">
                Tambahkan ke Jadwal
            </label>
        </div>

        <div id="schedule_fields" class="hidden">
            <div>
                <label for="schedule_time" class="block font-medium">Jam:</label>
                <input type="time" name="schedule_time" id="schedule_time" class="border p-2 rounded w-full">
            </div>

            <div>
                <label for="schedule_day" class="block font-medium">Hari:</label>
                <select name="schedule_day" id="schedule_day" class="border p-2 rounded w-full">
                    <option value="">Pilih Hari</option>
                    <option value="Senin">Senin</option>
                    <option value="Selasa">Selasa</option>
                    <option value="Rabu">Rabu</option>
                    <option value="Kamis">Kamis</option>
                    <option value="Jumat">Jumat</option>
                    <option value="Sabtu">Sabtu</option>
                    <option value="Minggu">Minggu</option>
                </select>
            </div>
        </div>

        <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded">Submit</button>
    </form>
</div>


        <!-- Manage Tab -->
        <div id="manage-tab" class="tab-content hidden">
            <table class="table-auto w-full border-collapse border border-gray-300">
                <thead>
                    <tr>
                        <th class="border border-gray-300 px-4 py-2">ID</th>
                        <th class="border border-gray-300 px-4 py-2">Anime ID</th>
                        <th class="border border-gray-300 px-4 py-2">Slug</th>
                        <th class="border border-gray-300 px-4 py-2">Base Video URL</th>
                        <th class="border border-gray-300 px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $pdo->query("SELECT * FROM sokuja");
                    while ($row = $stmt->fetch()) {
                       echo "<tr>
        <td class='border border-gray-300 px-4 py-2'>{$row['id']}</td>
        <td class='border border-gray-300 px-4 py-2'>{$row['anime_id']}</td>
        <td class='border border-gray-300 px-4 py-2'>{$row['slug']}</td>
        <td class='border border-gray-300 px-4 py-2'>{$row['base_video_url']}</td>
        <td class='border border-gray-300 px-4 py-2'>
            <a href='?delete={$row['id']}' onclick='return confirm(\"Are you sure?\")' class='text-red-500'>Delete</a>
        </td>
      </tr>";

                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const addToSchedule = document.getElementById('add_to_schedule');
        const scheduleFields = document.getElementById('schedule_fields');

        addToSchedule.addEventListener('change', () => {
            scheduleFields.classList.toggle('hidden', !addToSchedule.checked);
        });

       function searchAnime() {
    const query = document.getElementById('anime_search').value;
    fetch(`https://graphql.anilist.co`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            query: `
            query ($search: String) {
                Page(perPage: 5) {
                    media(search: $search, type: ANIME) {
                        id
                        title {
                            romaji
                            english
                        }
                        coverImage {
                            medium
                        }
                    }
                }
            }`,
            variables: { search: query }
        })
    })
    .then(response => response.json())
    .then(data => {
        const resultsDiv = document.getElementById('search_results');
        resultsDiv.innerHTML = '';

        if (data.data.Page.media.length > 0) {
            data.data.Page.media.forEach(anime => {
                const animeDiv = document.createElement('div');
                animeDiv.classList.add('anime-item', 'mb-4');
                animeDiv.innerHTML = `
                    <img src="${anime.coverImage.medium}" alt="${anime.title.romaji || anime.title.english}" class="w-32 h-48 object-cover mb-2">
                    <p>${anime.title.romaji || anime.title.english} (ID: ${anime.id})</p>
                    <button type="button" onclick="selectAnime(${anime.id})" class="bg-blue-500 text-white px-4 py-2 rounded">Select</button>
                `;
                resultsDiv.appendChild(animeDiv);
            });
        } else {
            resultsDiv.innerHTML = '<p class="text-red-500">No results found</p>';
        }
    })
    .catch(error => {
        console.error('Error fetching data:', error);
        const resultsDiv = document.getElementById('search_results');
        resultsDiv.innerHTML = '<p class="text-red-500">An error occurred while fetching data</p>';
    });
}

function selectAnime(animeId) {
    document.getElementById('anime_id').value = animeId;
}

        
        document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Reset semua tab dan konten
            tabs.forEach(t => t.classList.replace('bg-blue-500', 'bg-gray-200'));
            tabContents.forEach(tc => tc.classList.add('hidden'));

            // Aktifkan tab dan konten yang dipilih
            tab.classList.replace('bg-gray-200', 'bg-blue-500');
            document.querySelector(tab.dataset.target).classList.remove('hidden');
        });
    });
});



    </script>
</body>
</html>
