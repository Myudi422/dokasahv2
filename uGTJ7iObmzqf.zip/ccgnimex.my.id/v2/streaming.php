<?php include 'data-login.php'; ?>
<?php
require '../vendor/autoload.php';

use Stichoza\GoogleTranslate\GoogleTranslate;

$anime_id = $_GET['anime_id'];

$query = '
query ($id: Int) {
    Media (id: $id, type: ANIME) {
        title {
            romaji
            english
            native
        }
        description
        coverImage {
            large
        }
        bannerImage
        genres
        startDate {
            year
            month
            day
        }
        status
    }
}';

$variables = [
    'id' => (int) $anime_id,
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
];

$ch = curl_init('https://graphql.anilist.co');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query, 'variables' => $variables]));
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['data']['Media'])) {
    $anime_title_native = $data['data']['Media']['title']['native'];
    $anime_title_romaji = $data['data']['Media']['title']['romaji'];
    $anime_title_english = $data['data']['Media']['title']['english'];
    $bannerImage = $data['data']['Media']['bannerImage'];

    $anime_title = !empty($anime_title_romaji) ? $anime_title_romaji : (!empty($anime_title_native) ? $anime_title_native : $anime_title_english);

    $anime_description = $data['data']['Media']['description'];
    $anime_cover_image = $data['data']['Media']['coverImage']['large'];
    $release_date = $data['data']['Media']['startDate']['year'] . "-" . str_pad($data['data']['Media']['startDate']['month'], 2, '0', STR_PAD_LEFT) . "-" . str_pad($data['data']['Media']['startDate']['day'], 2, '0', STR_PAD_LEFT);
    $status = $data['data']['Media']['status'];
}

// Inisialisasi objek GoogleTranslate
$translator = new GoogleTranslate();

// Menentukan bahasa asal (asli) dan bahasa tujuan (dalam contoh ini, bahasa Indonesia)
$fromLanguage = 'auto'; // Bahasa asal akan dideteksi otomatis
$toLanguage = 'id'; // Kode bahasa untuk bahasa Indonesia

// Menerjemahkan judul anime ke bahasa Indonesia
$translated_deskripsi = $translator->setSource($fromLanguage)->setTarget($toLanguage)->translate($anime_description);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Streaming & Download Anime <?php echo htmlspecialchars($anime_title); ?> - Sub Indo</title>
    <meta name="description" content="Situs streaming anime dengan koleksi lengkap dan update gratis. Anime <?php echo htmlspecialchars($anime_title); ?> adalah anime bergenre <?php echo htmlspecialchars($genre); ?> yang menceritakan tentang <?php echo htmlspecialchars($translated_deskripsi); ?>.">
<meta name="keywords" content="anime, batch sub indo, streaming anime, situs streaming anime, anime terbaru, Sub indo, <?php echo htmlspecialchars($genre); ?>, <?php echo htmlspecialchars($anime_title); ?>, episode terbaru, <?php echo htmlspecialchars($anime_title); ?> sub indo">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="ccgnimex">
    <meta property="og:description" content="Situs streaming anime dengan koleksi lengkap dan update.">
    <meta property="og:image" content="https://example.com/image.jpg">
    <link rel="apple-touch-icon" sizes="57x57" href="../icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="../icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../icon1/favicon-16x16.png">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include 'css/navbar_home.php'; ?>
    <?php include 'css/darkmode.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/localforage/1.10.0/localforage.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/artplayer@latest"></script>
    <style>
    #ap {
        width: 100%;
        position: -webkit-sticky; /* For Safari */
        position: sticky;
        top: 0;
        margin: 0;
        z-index: 1000; /* Ensure video is on top */
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); /* Add shadow */
    }

    /* Default height for larger screens */
    @media (min-width: 640px) {
        #ap {
            height: 300px;
        }
    }

    /* Smaller height for smaller screens */
    @media (max-width: 639px) {
        #ap {
            height: 180px;
        }
    }

    .art-video {
        padding-bottom: 5px;
    }
    </style>
</head>
<body style="margin-bottom: 40px;">

<!-- Navbar -->
<nav class="bg-gray-100 p-2 flex justify-between items-center">
    <a href="/v2"> <!-- Tambahkan anchor untuk mengarahkan ke /v2 -->
        <div class="flex items-center">
            <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 30px; height: 30px;" />
            <div class="flex-1 text-left ml-2">
                <span style="font-family: 'Arial', sans-serif; font-weight: bold; font-size: 1rem;">ccgnimex</span>
            </div>
        </div>
    </a>
    <div class="flex items-center">
        <a href="#" id="dark-mode-button" class="mx-2"><i class="fas fa-sun mr-2"></i></a>
    </div>
</nav>

<?php
// Your PHP Code for Fetching Data

// Start the session if it's not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['anime_id'])) {
    $anime_id = $_GET['anime_id'];
    $episode_number = isset($_GET['EP']) ? $_GET['EP'] : 1; // Default to EP=1 if not specified

    // Connect to your database and fetch the video URLs and resolutions for the given episode
    // Replace the following code with your actual database connection and query
    $servername = "localhost";
    $username = "ccgnimex";
    $password = "aaaaaaac";
    $dbname = "ccgnimex";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to protect against SQL Injection
    $stmt = $conn->prepare("SELECT video_url, resolusi FROM nonton WHERE anime_id = ? AND episode_number = ?");
    $stmt->bind_param("ii", $anime_id, $episode_number); // Assuming both parameters are integers

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Video information found in the database
        $videos = [];
        while ($row = $result->fetch_assoc()) {
            $resolusi = $row['resolusi'];
            $video_url = $row['video_url'];

            // Only add resolutions with valid video URLs
            if ($video_url) {
                $videos[$resolusi] = $video_url;
            }
        }

        // Close the database connection
        $conn->close();

        // Determine the default resolution dynamically
        $defaultResolution = 'en'; // Default to 'en'

        // Sort the $videos array based on resolution
        ksort($videos);

        // Check if 'en' resolution is available
        if (isset($videos['en'])) {
            // If 'en' resolution is available, set it as the default
            $defaultResolution = 'en';
        } else if (isset($videos['pt'])) {
            // If 'en' resolution is not available but 'pt' (360p) is, set 'pt' as the default
            $defaultResolution = 'pt';
        }

        // Initialize the $video_time variable
        $video_time = null;

        // Check if the user is logged in and get their Telegram ID from the session
        if (isset($_SESSION['telegram_id'])) {
            $telegram_id = $_SESSION['telegram_id'];

            // Create a new PDO connection
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

            // Prepare and execute the SQL query to fetch video_time
            $stmt = $pdo->prepare('SELECT video_time FROM waktu_terakhir_tontonan WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
            $stmt->execute([$anime_id, $episode_number, $telegram_id]);

            // Fetch the result
            $waktu_terakhir_tontonan = $stmt->fetch(PDO::FETCH_ASSOC);

            // Check if video_time exists in the result
            if ($waktu_terakhir_tontonan && isset($waktu_terakhir_tontonan['video_time'])) {
                $video_time = $waktu_terakhir_tontonan['video_time'];
            }
        }

        // Render the video player with Artplayer and define the quality options
        ?>
        <div id="ap"></div>
        <script>
            const videoUrls = <?php echo json_encode($videos); ?>;
            const defaultResolution = '<?php echo $defaultResolution; ?>'; // Use the default resolution

            const art = new Artplayer({
                container: '#ap',
                pip: true,
                hotkey: true,
                setting: true,
                playbackRate: true,
                aspectRatio: true,
                fullscreen: true,
                backdrop: true,
                mutex: true,
                playsInline: true,
                airplay: true,
                lock: true,
                miniProgressBar: true,
                title: 'ccgnimex',
                theme: '#f00',
                poster: "<?php echo isset($bannerImage) ? htmlspecialchars($bannerImage) : 'https://telegra.ph/file/356861f71921095db0600.jpg'; ?>" ,
                url: videoUrls[defaultResolution], // Use the default resolution
                quality: [
                    <?php
                    foreach ($videos as $resolusi => $video_url) {
                        if ($video_url) {
                            // Set label based on resolution
                            $label = ($resolusi === 'en') ? 'HD 720P' : 'SD 360P';
                            echo "{ html: '$label', url: '" . htmlspecialchars($video_url) . "' },";
                        }
                    }
                    ?>
                ],
                layers: [
                    {
                        name: 'myLayer',
                        html: '<img width="120" src="https://subjective-tobye-myudi422.koyeb.app/14051/Frame+1+%284%29.png">',
                        click: function () {
                            window.open('#');
                            console.info('mari nonton anime');
                        },
                        style: {
                            position: 'absolute',
                            top: '20px',
                            right: '20px',
                            opacity: '.9',
                        },
                    },
                ],
            });
            const videoElement = art.video; // Get the video element from Artplayer

            const anime_id = "<?php echo $anime_id; ?>";
            const episode_number = "<?php echo $episode_number; ?>";
            const telegram_id = "<?php echo $telegram_id; ?>";
            let video_time = <?php echo isset($video_time) ? $video_time : 'null'; ?>;

            // When the page is loaded, check if there's a saved video time in the database
            // If so, set the video time to the saved time
            art.once('ready', () => {
                if (video_time !== null) {
                    videoElement.currentTime = video_time;
                }
            });

            // Save the current video time to the database when the page is unloaded or the video is paused
            const saveVideoTime = () => {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "save_duration.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send(
                    `anime_id=${anime_id}&episode_number=${episode_number}&telegram_id=${telegram_id}&video_time=${videoElement.currentTime}`
                );
            };

            window.addEventListener("beforeunload", saveVideoTime);
            videoElement.addEventListener("pause", saveVideoTime);
        </script>
    <?php
    }
}
?>




            <div class="bg-red-100">
    <div class="p-2 sm:p-4 bg-red-500 text-white text-sm sm:text-lg font-bold">
        <h1 class="text-sm sm:text-lg font-bold">Episode <?php echo isset($_GET['EP']) ? intval($_GET['EP']) : 1; ?> - <?php echo htmlspecialchars($anime_title); ?></h1>
    </div>
</div>

                <div class="flex flex-row p-2 sm:p-4 items-start sm:items-center">
                    <div class="flex-shrink-0 mr-2 sm:mr-4">
                        <img src="<?php echo htmlspecialchars($anime_cover_image); ?>" alt="<?php echo htmlspecialchars($anime_title); ?>" class="w-20 h-20 sm:w-32 sm:h-32 object-cover rounded-lg">
                    </div>
                    <div class="flex-grow space-y-1 sm:space-y-2">
                        <p class="text-sm sm:text-lg font-bold"><?php echo htmlspecialchars($anime_title); ?></p>
                        <?php 
                            $anime_genres_array = array_slice($data['data']['Media']['genres'], 0, 4);
                            foreach($anime_genres_array as $genre) {
                                echo "<span class='inline-block bg-red-500 text-white px-1 sm:px-2 py-1 rounded-full text-xs sm:text-sm mr-1 sm:mr-2 mb-1 sm:mb-2'>" . htmlspecialchars($genre) . "</span>";
                            }
                        ?>
                        <p class="text-xs sm:text-sm"><strong>Nama Asli:</strong> <?php echo htmlspecialchars($anime_title_native); ?></p>
                        <p class="text-xs sm:text-sm"><strong>Tayang:</strong> <?php echo htmlspecialchars($release_date); ?> | <strong>Status:</strong> <?php echo htmlspecialchars($status); ?></p>
                    </div>
                </div>
                <div class="p-2 sm:p-4 bg-teal-100 text-teal-700">
                    <p class="text-xs sm:text-sm overflow-hidden whitespace-nowrap sm:whitespace-normal overflow-ellipsis"><strong>Sinopsis:</strong> <?php echo htmlspecialchars($translated_deskripsi); ?></p>
                </div>
            </div>
<style>
    .current-episode {
    background-color: #FFD700 !important;
    color: #000 !important;
}

    /* Add this CSS to highlight the selected group */
    .selected {
        background-color: #3498db;
        color: #fff;
    }

    /* Add this CSS to highlight the group that contains the current episode */
    .group-highlight {
        background-color: #3498db;
        color: #fff;
    }
</style>
<style>
    .disabled {
        pointer-events: none; /* Menonaktifkan klik */
        opacity: 0.5; /* Mengurangi kecerahan tombol */
        cursor: not-allowed; /* Mengubah kursor menjadi "not-allowed" */
    }
.watched {
    background-color: #4CAF50;
    color: #FFF;
}
</style>

<?php
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initializing variables
$anime_id = isset($_GET['anime_id']) ? intval($_GET['anime_id']) : 0;
$anime_not_found = false;
$episodes = [];
$minEpisode = $maxEpisode = $currentEpisode = $selectedEpisode = 0;
$hasPreviousEpisode = $hasNextEpisode = false;

// Validating and Fetching Anime Data
$stmt = $conn->prepare("SELECT COUNT(*) as anime_count FROM nonton WHERE anime_id = ?");
$stmt->bind_param("i", $anime_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$anime_not_found = ($row['anime_count'] == 0);

if ($row['anime_count'] == 0) {
    // Anime with the specified ID doesn't exist in the database.
    $anime_not_found = true; // Flag to indicate that anime is not found
} else {
    // If anime_id exists, proceed to fetch episode data
    $query = "SELECT DISTINCT episode_number FROM nonton WHERE anime_id = $anime_id ORDER BY episode_number ASC";
    $result = $conn->query($query);

    $episodes = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $episodes[] = $row['episode_number'];
        }
    }

    // Determine the range of available episodes
    $minEpisode = min($episodes);
    $maxEpisode = max($episodes);

    // Check if EP parameter exists, otherwise default to 1
    $currentEpisode = isset($_GET['EP']) ? intval($_GET['EP']) : 1;
    

    // Determine the group of the current episode
    function getEpisodeGroup($episodeNumber, $groupSize) {
        return ceil($episodeNumber / $groupSize);
    }

    $groupSize = 20; // Adjust this to your group size
    $currentGroup = getEpisodeGroup($currentEpisode, $groupSize);
}

// Add this line to store the selected episode
$selectedEpisode = isset($_GET['EP']) ? intval($_GET['EP']) : 0;
$hasPreviousEpisode = in_array($selectedEpisode - 1, $episodes);
$hasNextEpisode = in_array($selectedEpisode + 1, $episodes);


function isEpisodeWatched($conn, $telegram_id, $anime_id, $episode_number) {
    // Jika pengguna tidak login, selalu kembalikan false
    if ($telegram_id === null) {
        return false;
    }

    $stmt = $conn->prepare("SELECT * FROM ditonton WHERE telegram_id = ? AND anime_id = ? AND episode_number = ?");
    $stmt->bind_param("iii", $telegram_id, $anime_id, $episode_number);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Memeriksa apakah pengguna login
$telegram_id = null;
if (isset($_SESSION['telegram_id'])) {
    $telegram_id = $_SESSION['telegram_id'];
}

?>

<style>
    .desktop-only {
  display: none; /* Sembunyikan elemen di semua perangkat terlebih dahulu */
}

@media (min-width: 768px) {
  .desktop-only {
    display: block; /* Tampilkan elemen pada layar dengan lebar lebih besar atau sama dengan 768px (desktop) */
  }
}
</style>
<script async="async" data-cfasync="false" src="//pl21597780.toprevenuegate.com/7e08807fc94cfaf2f27d5d31d2eaef4a/invoke.js"></script>
<div id="container-7e08807fc94cfaf2f27d5d31d2eaef4a"></div>


<!-- Tombol "EPS Sebelumnya" dan "EPS Berikutnya" -->
<div class="flex items-center justify-between my-4 mx-4 bg-red-100">
    <a href="streaming.php?anime_id=<?= $anime_id ?>&EP=<?= ($selectedEpisode - 1) ?>" class="prev-episode px-2 py-1 border rounded cursor-pointer hover:bg-gray-200 whitespace-nowrap <?= !$hasPreviousEpisode ? 'disabled' : '' ?>">
        <i class="fas fa-chevron-left"></i>
    </a>
    <span class="text-lg">Semua Episode</span>
    <a href="streaming.php?anime_id=<?= $anime_id ?>&EP=<?= ($selectedEpisode + 1) ?>" class="next-episode px-2 py-1 border rounded cursor-pointer hover:bg-gray-200 whitespace-nowrap <?= !$hasNextEpisode ? 'disabled' : '' ?>">
        <i class="fas fa-chevron-right"></i>
    </a>
</div>

<!-- Episode Groups Buttons -->
<div id="episode_groups" class="flex items-center my-4 mx-4 overflow-x-auto space-x-2 no-scrollbar">
    <?php
    if (empty($episodes)) {
        // Jika tidak ada episode, tampilkan tombol "Request"
        echo '<button class="load_episodes px-2 py-1 border rounded cursor-pointer hover:bg-gray-200 whitespace-nowrap" disabled>Request</button>';
    } else {
        $grouped_episodes = array_chunk($episodes, $groupSize);
        foreach ($grouped_episodes as $index => $group) {
    // Add a class to highlight the selected group
    $selectedClass = ($index + 1 == $currentGroup) ? 'selected' : '';
    // Add a class to highlight the group containing the current episode
    $groupHighlightClass = (min($group) <= $currentEpisode && $currentEpisode <= max($group)) ? 'group-highlight' : '';

    if ($currentEpisode == 1 && empty($_GET['EP'])) {
        // Tandai episode pertama jika 'EP' tidak ada dalam URL
        $selectedClass = ($index === 0) ? 'current-episode' : '';
    }
    ?>
    <button class="load_episodes px-2 py-1 border rounded cursor-pointer hover:bg-gray-200 whitespace-nowrap <?= $selectedClass ?> <?= $groupHighlightClass ?>"
            data-start="<?= $group[0] ?>" data-end="<?= end($group) ?>">
        <?= $group[0] ?> - <?= end($group) ?>
    </button>
    <?php
}
    }
    ?>
</div>

<!-- Daftar Episode (Awalnya Disembunyikan) -->
<div class="flex items-center my-4 ml-4 mr-4 pb-4 overflow-x-auto space-x-2 no-scrollbar" id="episode-list" style="display: none;">
    <?php
    if (empty($episodes)) {
        // Jika tidak ada episode, tampilkan tombol "Request"
        echo '<button class="episode px-3 py-1 border rounded cursor-pointer bg-red-500 text-white">Request</button>';
    } else {
        // Tampilkan hanya episode yang sesuai dengan grup yang dipilih
for ($i = $minEpisode; $i <= $maxEpisode; $i++) {
    $cssClass = ($i == $currentEpisode) ? 'current-episode' : '';

    if (in_array($i, $episodes) || $i == 1) {
        if (in_array($i, $episodes)) {
            $watchedClass = isEpisodeWatched($conn, $telegram_id, $anime_id, $i) ? 'watched' : '';
            // Menambahkan logika untuk menentukan kelas episode saat ini
            $currentClass = ($i == $selectedEpisode) ? 'current-episode' : '';
            echo '<a href="streaming.php?anime_id=' . $anime_id . '&EP=' . $i . '" data-episode="' . $i . '" class="episode px-3 py-1 border rounded ' . $currentClass . ' ' . $watchedClass . '">' . $i . '</a>';
        } else {
            echo '<button class="episode px-3 py-1 border rounded cursor-not-allowed bg-gray-300 text-gray-500 ' . $cssClass . '">' . $i . '</button>';
        }
    } else {
        echo '<button class="episode px-3 py-1 border rounded cursor-not-allowed bg-gray-300 text-gray-500 ' . $cssClass . '">' . $i . '</button>';
    }
}
    }
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
    function showEpisodes(start, end) {
        $('#episode-list .episode').hide();
        $('#episode-list .episode').slice(start, end).show();
    }

    function loadEpisodeList(start, end) {
        showEpisodes(start, end);
    }

    $('.load_episodes').click(function () {
        var start = $(this).data('start') - 1;
        var end = $(this).data('end');
        loadEpisodeList(start, end);

        $('.load_episodes').removeClass('selected');
        $(this).addClass('selected');
        
        $('#episode-list').show();
    });

    $('#episode-list .episode').hide();
    
    loadEpisodeList(0, <?php echo count($episodes); ?>);

    function addWatchedAndRedirect(animeId, episodeNumber, telegramId, redirectUrl) {
        if (animeId && episodeNumber && redirectUrl) {
            if (telegramId) {
                $.ajax({
                    url: 'add_watched.php',
                    type: 'POST',
                    data: {
                        anime_id: animeId,
                        episode_number: episodeNumber,
                        telegram_id: telegramId
                    },
                    success: function (data) {
                        console.log("Success:", data);
                        window.location.href = redirectUrl;
                    },
                    error: function (error) {
                        console.error("Error:", error);
                        alert('Terjadi kesalahan. Silakan coba lagi.');
                    }
                });
            } else {
                window.location.href = redirectUrl;
            }
        } else {
            console.error("Invalid parameters:", {animeId, episodeNumber, telegramId, redirectUrl});
        }
    }

    $(document).on('click', '.episode, .next-episode, .prev-episode', function (e) {
        e.preventDefault();  

        var episodeNumber;
        var animeId = <?= $anime_id ?>;  
        var telegramId = <?= json_encode($_SESSION['telegram_id'] ?? null) ?>; 
        var redirectUrl = $(this).attr('href');

        if ($(this).hasClass('episode')) {
            episodeNumber = $(this).data('episode');
        } else if ($(this).hasClass('next-episode')) {
            episodeNumber = <?= $selectedEpisode + 1 ?>;
        } else if ($(this).hasClass('prev-episode')) {
            episodeNumber = <?= $selectedEpisode - 1 ?>;
        }

        addWatchedAndRedirect(animeId, episodeNumber, telegramId, redirectUrl);
    });

    if (!window.location.search.includes("EP=")) {
        var animeId = <?= $anime_id ?>;
        var telegramId = <?= json_encode($_SESSION['telegram_id'] ?? null) ?>; 

        if (<?= in_array(1, $episodes) ? 'true' : 'false' ?>) {
            addWatchedAndRedirect(animeId, 1, telegramId, "streaming.php?anime_id=" + animeId + "&EP=1");
        }
    }
});
</script>




<?php
$conn->close();
?>



<?php include 'ongoing.php'; ?>
<?php include 'top.php'; ?>
<?php include 'navbar.php'; ?>


<script>
    // Menonaktifkan context menu
    document.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });
    
    // Menonaktifkan membuka Inspect Element
    document.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'i') {
            e.preventDefault();
        } else if (e.ctrlKey && e.shiftKey && e.key === 'i') {
            e.preventDefault();
        }
    });
</script>


<script src="js/darkmode.js"></script>
<script src="js/smoothscroll/smooth-scroll.js"></script>
</body>
</html>
