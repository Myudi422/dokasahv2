<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Periksa koneksi
if (mysqli_connect_errno()) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Proses data form jika form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $pesan = mysqli_real_escape_string($koneksi, $_POST['pesan']);

    // Simpan data ke dalam database
    $query = "INSERT INTO dukungan (nama, pesan) VALUES ('$nama', '$pesan')";

    if (mysqli_query($koneksi, $query)) {
        $pesan_sukses = "Terima kasih atas dukungannya!";
    } else {
        $pesan_error = "Gagal menyimpan data: " . mysqli_error($koneksi);
    }
}

// Ambil data dukungan dari database dengan GROUP BY nama
$query_select = "SELECT nama, MAX(pesan) AS pesan FROM dukungan GROUP BY nama ORDER BY id DESC LIMIT 5";
$result = mysqli_query($koneksi, $query_select);

// Tutup koneksi
mysqli_close($koneksi);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Ade Wahyudin | Calon Legislatif</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
    <link rel="stylesheet" href="https://cdn.plyr.io/3.6.3/plyr.css">
    
    <style>
        /* Add your custom styles here */

    <style>

.slider {
      width: 80%; /* 80% width of the parent container */
      margin: 0 auto;
      background: linear-gradient(45deg, #3498db, #2c3e50); /* Gradient background color */
      padding: 4px; /* Add padding for better visibility */
      border-radius: 10px; /* Optional: Add border-radius for rounded corners */
    }
        /* Customize the appearance of the slider */
.slider {
    width: 80%;
    margin: 0 auto;
    overflow-x: hidden; /* Add this line to prevent horizontal scrolling */
    /* Add other styles as needed */
}
    
        .slick-prev, .slick-next {
          font-size: 24px;
        }
    
        .slick-prev {
          left: -40px;
        }
    
        .slick-next {
          right: -40px;
        }
    
        .slick-dots {
          bottom: 20px;
        }
    
        /* Make images responsive */
        .slick-slide {
          height: auto;
          width: 100%; /* 100% width of the parent container */
          max-width: 800px; /* Set a maximum width for desktop */
          margin: 0 auto; /* Center the image */
        }
    
        .slick-slide img {
          width: 100%; /* 100% width of the parent container */
          max-width: 100%; /* Ensure the image doesn't exceed its original size */
          height: auto; /* Maintain aspect ratio */
        }
      </style>
</head>

<body class="bg-blue-100 font-sans">

    <div class="info-modal bg-white mx-auto p-4">
        <!-- Logo -->
        <div class="flex items-center justify-center">
            <img src="logo.png" alt="Logo" class="object-contain h-16">
        </div>
        
        </div>

<div class="relative flex flex-col py-16 lg:flex-row lg:py-0">
    <div class="w-full lg:w-7/12 bg-blue-100 overflow-hidden">
        <img class="object-cover w-full h-auto lg:h-full" src="fotoxz.png" alt="" />
    </div>
    <div class="flex flex-col justify-center items-start w-full max-w-xl px-4 mx-auto md:px-0 lg:px-8 mt-8 lg:mt-0">
        <div class="mb-16 lg:mb-0">
            <p class="mb-4 text-xs font-semibold tracking-wider text-teal-900 uppercase">
                MENUJU CALEG DPR RI KOTA & KAB. SUKABUMI
            </p>
            <h2 class="mb-5 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl sm:leading-none">
                Ade Wahyudin<br class="hidden md:block" />
            </h2>
            <p class="mb-5 text-base text-gray-700 md:text-lg">
                <b>Ade Wahyudin, ST,</b> pengusaha muda dan alumni sarjana teknik, memiliki komitmen mendasar "menebar manfaat untuk orang lain." Selain aktif dalam kegiatan sosial, ia juga berperan sebagai dosen, pembicara seminar, dan penceramah di berbagai komunitas keagamaan. Terkenal agamis dan berbakat multi talent, Ade Wahyudin juga menjabat sebagai imam dan penceramah Jumat di berbagai masjid di Sukabumi. <br><br>Selain itu, dia merupakan pemimpin partai Gelora dan Ketua Umum para pengusaha di Sukabumi di bawah KADIN setelah sebelumnya memimpin pengusaha muda di bawah bendera HIPMI. Dengan pengalaman sebagai eksportir dan importir, Ade Wahyudin terampil dalam manajemen dan kepemimpinan di berbagai aktivitasnya.
            </p>
        </div>
    </div>
</div>

          <section class="p-8 bg-blue-400 text-white">
            <div class="max-w-2xl mx-auto">
              <h2 class="text-3xl font-bold mb-6">Let's Stand Together</h2>
              
              <p class="text-lg mb-4">“Arah Baru Menuju Super Power Baru”</p>
            </div>
          </section>

        <section class="p-8 bg-gray-100 rounded-t-lg">
            <div class="max-w-2xl mx-auto">
              <h2 class="text-3xl font-bold mb-6">Ade Wahyudin Sebagai Pemimpin</h2>
              
              <p class="text mb-4">Partai Gelombang Rakyat Indonesia (Gelora) Kota Sukabumi mencermati ketidakarahan dalam memandu bangsa menuju pencapaian tertinggi. Dalam konteks global, krisis kompleks dan pergeseran kekuatan antara negara-negara besar meningkatkan ketidakpastian. Sebagai bagian dari sejarah Indonesia, kita telah melewati dua gelombang penting: menjadi Indonesia dan menjadi negara-bangsa modern. <br><br>Saatnya memasuki gelombang ketiga, di mana Indonesia menjadi kekuatan utama dunia dan berkontribusi pada keseimbangan global. Gerakan kebangkitan rakyat Indonesia harus kuat, menyatukan semua elemen kekuatan rakyat, dan didorong oleh semangat cinta tanah air.<br><br>Dengan tawakal kepada Allah SWT, kita, sebagai pemegang estafet sejarah, bersatu untuk membawa bangsa ini menjadi kekuatan baru yang menentukan arahnya.</p>
            </div>
          </section>
          
          
          
            <!-- Visi Section -->
  <section class="py-16 bg-blue-500 text-white px-4">
    <div class="container mx-auto text-center">
      <h2 class="text-3xl font-bold mb-4">Visi</h2>
      <p class="text-lg italic">"Konsisten Memegang Amanah yang diemban dan memperjuangkan cita-cita besar bangsa melalui peta jalan yang telah disepakati menuju Indonesia super power baru."</p>
    </div>
  </section>

  <!-- Misi Section -->
  <section class="py-16 px-4">
    <div class="container mx-auto">
      <h2 class="text-3xl font-bold mb-8 text-gray-800">Misi</h2>

      <!-- Misi Item 1 -->
      <div class="flex items-center mb-6">
        <div class="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mr-4">
          <span class="text-white font-bold text-xl">1</span>
        </div>
        <div>
          <h3 class="text-xl font-bold mb-2">Memperjuangkan Nilai-nilai Amal Ma’ruf Nahi Mungkar</h3>
          <p class="text-gray-700">Berupaya sekuat tenaga dalam memegang nilai-nilai kebajikan dan menolak segala bentuk keburukan.</p>
        </div>
      </div>

      <!-- Misi Item 2 -->
      <div class="flex items-center mb-6">
        <div class="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mr-4">
          <span class="text-white font-bold text-xl">2</span>
        </div>
        <div>
          <h3 class="text-xl font-bold mb-2">Aktif dalam Memperjuangkan UMKM Naik Kelas</h3>
          <p class="text-gray-700">Berusaha maksimal untuk mendukung dan meningkatkan kualitas Usaha Mikro, Kecil, dan Menengah (UMKM).</p>
        </div>
      </div>

      <!-- Misi Item 3 -->
      <div class="flex items-center mb-6">
        <div class="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mr-4">
          <span class="text-white font-bold text-xl">3</span>
        </div>
        <div>
          <h3 class="text-xl font-bold mb-2">Mengawal dan Mendukung Kemakmuran dan Kesejahteraan Rakyat</h3>
          <p class="text-gray-700">Berkonsentrasi penuh dalam mengawal segala upaya yang terintegrasi untuk mencapai kemakmuran dan kesejahteraan rakyat.</p>
        </div>
      </div>

      <!-- Misi Item 4 -->
      <div class="flex items-center mb-6">
        <div class="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mr-4">
          <span class="text-white font-bold text-xl">4</span>
        </div>
        <div>
          <h3 class="text-xl font-bold mb-2">Berkonsentrasi Penuh dalam Menekan Kemiskinan Rakyat Menuju Kesetaraan dan Keadilan</h3>
          <p class="text-gray-700">Menekan tingkat kemiskinan dengan fokus pada menciptakan kesetaraan dan keadilan dalam masyarakat.</p>
        </div>
      </div>

    </div>
  </section>
                    
<!-- Pengalaman Hidup -->
<section class="p-8">
     <h2 class="text-2xl font-bold mb-4 text-center">PENGALAMAN HIDUP</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">

<!-- Tabel Organisasi -->
<div class="rounded-lg shadow-md bg-gradient-to-br from-green-400 to-blue-500 text-white p-4 text-center">
    <h3 class="text-xl font-semibold mb-4">
        <i class="fas fa-users mr-2"></i> Organisasi
    </h3>
    <p class="mb-2">- Ketua OSIS (1993-1994)</p>
    <p class="mb-2">- Ketua FeMa UNPAS (1998-1999)</p>
    <p class="mb-2">- Ketua Presidium HIMASI (1999-2000)</p>
    <p class="mb-2">- Ketua Umum HIPMI Sukabumi Raya (2013-2017)</p>
    <p class="mb-2">- Dosen UMI (2016-2017)</p>
    <p class="mb-2">- Pembina Nasional DPP Travel Halal Indonesia (2017-2019)</p>
    <p class="mb-2">- Executive Price Presiden Nasional DPP GENPRO (2017 - 2019)</p>
    <p class="mb-2">- Pembina Koperasi Nasional SLI (2018-2019)</p>
    <p class="mb-2">- Wakil Ketua APINDO Kota Sukabumi (2018-2019)</p>
    <p class="mb-2">- Ketua KADIN Kota Sukabumi (2019-sekarang)</p>
    <p class="mb-2">- Ketua Pembina SEA (Sukabumi Entrepreneur Association) (2019-sekarang)</p>
</div>


        <!-- Tabel Perusahaan -->
        <!-- Tabel Perusahaan -->
<div class="rounded-lg shadow-md bg-gradient-to-br from-purple-500 to-pink-500 text-white text-center p-4">
    <h3 class="text-xl font-semibold mb-4">
        <i class="fas fa-building mr-2"></i> Perusahaan
    </h3>
    <p class="mb-2">- <a href="#perusahaan">Direktur Utama PT Bumi Muda</a></p>
    <p class="mb-2">- <a href="#perusahaan">Direktur Muassasah ASSEHLY (Arab Saudi)</a></p>
    <p class="mb-2">- <a href="#perusahaan">Direktur PT Robithah Mubarrok Indonesia</a></p>
    <p class="mb-2">- <a href="#perusahaan">CEO dan Founder CV Lingga Furniture</a></p>
    <p class="mb-2">- <a href="#perusahaan">CEO dan Founder Batik Kenarie</a></p>
    <p class="mb-2">- <a href="#perusahaan">CEO dan Founder BUMI MECCA Tours dan Travel</a></p>
    <!-- ... (Tambahkan entri-entri perusahaan lainnya) ... -->
</div>

    </div>
</section>



                <section class="slider">
            <div><img src="https://subjective-tobye-myudi422.koyeb.app/17643" alt="Image 1"></div>
            <div><img src="https://subjective-tobye-myudi422.koyeb.app/17644" alt="Image 2"></div>
            <div><img src="https://subjective-tobye-myudi422.koyeb.app/17645" alt="Image 3"></div>
            <div><img src="https://subjective-tobye-myudi422.koyeb.app/17646" alt="Image 4"></div>
          </section>
          
          <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script>
  // Initialize the slider
  $(document).ready(function(){
    $('.slider').slick({
      autoplay: true,
      autoplaySpeed: 3000, // Adjust the speed (in milliseconds) of the slider
      dots: true, // Show dots for navigation
      prevArrow: '<button type="button" class="slick-prev">Previous</button>',
      nextArrow: '<button type="button" class="slick-next">Next</button>'
    });
  });
</script>

<div class="bg-blue-100 mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4 text-center text-blue-700">Dukung Ade Wahyudin</h1>
    <p class="text-gray-600 mb-4 text-center text-blue-700">
        Berikan dukungan Anda dengan meninggalkan komentar di bawah ini.
    </p>

    <form action="" method="POST">
        <label for="nama" class="block text-sm font-medium text-gray-600">Nama</label>
        <input type="text" name="nama" id="nama" class="mt-1 p-2 w-full border rounded-md">

        <label for="pesan" class="block mt-4 text-sm font-medium text-gray-600">Pesan</label>
        <textarea name="pesan" id="pesan" rows="3" class="mt-1 p-2 w-full border rounded-md"></textarea>

        <button type="submit" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md w-full">Kirim</button>

    </form>

    <style>
        .chat-container {
            max-width: 400px;
            margin: 0 auto;
        }

        .chat-header {
            text-align: center;
            margin-bottom: 20px;
            color: #3498db; /* Ganti warna header */
        }

        .chat-bubble {
            border: 1px solid #3498db; /* Ganti warna border */
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 8px;
            background-color: #ecf0f1; /* Ganti warna latar belakang */
        }

        .sender-name {
            font-weight: bold;
            margin-bottom: 5px;
            display: inline-block;
            margin-right: 5px;
            color: #e74c3c; /* Ganti warna nama pengirim */
        }

        .message-content {
            display: inline-block;
            color: #2ecc71; /* Ganti warna isi pesan */
        }

        .icon {
            margin-left: 5px;
            font-size: 16px;
            color: #3498db; /* Ganti warna ikon */
        }
    </style>
    
        <div class="chat-container" style="padding-bottom: 10px; padding-top: 20px;">
        <h2 class="text-2xl font-bold chat-header">Dukungan Terbaru</h2>

        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <?php
            $nama = $row['nama'];
            $pesan = $row['pesan'];
            $pesan_sms = substr($pesan, 0, 50);
            ?>
            <div class="chat-bubble">
                <span class="sender-name"><?= $nama ?>:</span>
                <span class="message-content"><?= $pesan_sms ?></span>
                <i class="fas fa-comment-dots icon"></i>
            </div>
        <?php endwhile; ?>
    </div>


<section class="bg-blue-500 p-8 pt-4 text-blue-100 rounded-t-md">

    <div class="flex items-center justify-center mb-8" style="
    padding-top: 30px;
">
      <div class="mr-4">
        <i class="fas fa-heart text-4xl"></i>
        <span class="block text-xl font-bold">Dukungan</span>
        <span class="text-3xl font-bold">1444 Orang</span>
      </div>
      <div>
        <i class="fas fa-hands-helping text-4xl"></i>
        <span class="block text-xl font-bold">Relawan</span>
        <span class="text-3xl font-bold">345 Orang</span>
      </div>
    </div>
  <section>
  
</div>
</div>
    <style>
        /* Add your custom styles here */
        .instagram-button {
            background-color: #e4405f; /* Sesuaikan warna latar belakang */
            color: #fff; /* Sesuaikan warna teks */
            padding: 10px 20px; /* Sesuaikan padding */
            border-radius: 5px; /* Sesuaikan border radius */
            text-decoration: none;
            display: inline-block;
        }

        .instagram-button:hover {
            background-color: #d83a57; /* Warna latar belakang saat dihover */
        }
    </style>
    
    <section class="bg-classic p-8">
        <div class="container mx-auto text-center">
            <!-- Video element with Plyr class -->
            <video id="myVideo" class="plyr w-full" controls>
                <source src="https://subjective-tobye-myudi422.koyeb.app/17514/Pak+ade+Wahyudin.mp4" type="video/mp4">
            </video>

            <div class="text-center p-8">
                <h3 class="text-xl font-bold">
                    Dukungan Anda Adalah Semangat Kami
                </h3>
                <h3 class="text-2xl font-bold mt-2">
                    "Mohon Dukung dan Doa Restu Untuk Pencalonan Ade Wahyudin Sebagai DPR RI KOTA & KAB. SUKABUMI"
                </h3>
                <p class="mt-4">
                    Bergabunglah dalam grup WhatsApp kami dan dukung
                    <strong>Ade Wahyudin</strong>
                    sebagai
                    <strong>Calon Anggota DPR RI KOTA & KAB. SUKABUMI</strong>.
                    Ayo, bergabung sekarang!
                </p>

                <div class="mt-8 flex flex-col space-y-4">
                    <!-- WhatsApp (Gabung Sekarang) button -->
                    <a href="https://chat.whatsapp.com/CGxZMN8PN2868PsCG9dkeU" class="whatsapp-button bg-blue-500 text-white py-2 px-4 rounded-full inline-block">
                        <i class="fab fa-whatsapp"></i> Gabung Sekarang
                    </a>
                    <!-- WhatsApp (Nomor Aduan) button -->
                    <a href="https://wa.me/6285819250398" class="whatsapp-button bg-green-500 text-white py-2 px-4 rounded-full inline-block">
                        <i class="fab fa-whatsapp"></i> Aduan
                    </a>
                </div>

                <!-- Instagram button -->
                <div class="mt-4">
                    <a href="https://www.instagram.com/adewahyudin.st?igshid=NGVhN2U2NjQ0Yg==" target="_blank" class="instagram-button text-xl text-gray-600 mx-2">
                        <i class="fab fa-instagram"></i> Instagram Ade Wahyudin
                    </a>
                </div>

                <div class="mt-8">
                    <h2 class="text-lg">
                        Sesudah menekan tombol, anda otomatis tergabung dalam Grup Whatsapp
                    </h2>
                </div>
            </div>
        </div>
    </section>

    <footer class="mt-8 text-center text-gray-600">
      <p>&copy; Tokohsukabumi | Ade Wahyudin</p>
    </footer>
  </div>


<!-- Include Plyr JavaScript -->
<script src="https://cdn.plyr.io/3.6.3/plyr.js"></script>

<!-- Initialize Plyr on the video element -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const player = new Plyr('#myVideo');
    });
</script>

</body>

</html>
