<?php
// Get anime id and Telegram user id from POST data
$animeId = $_POST['animeId'];
$telegramId = $_POST['telegramId'];

// Koneksi ke database MySQL
$db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

// Query untuk mengambil data dari tabel notify
$query = "SELECT * FROM notify WHERE item = '" . $animeId . "' AND recipient = '" . $telegramId . "'";
$query_result = mysqli_query($db, $query);

// Cek apakah id anime terdapat dalam tabel notify
if (mysqli_num_rows($query_result) > 0) {
    // Data ditemukan
    echo 'exists';
} else {
    // Data tidak ditemukan
    echo 'not exists';
}