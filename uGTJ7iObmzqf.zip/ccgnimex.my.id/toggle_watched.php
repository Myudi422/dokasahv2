<?php
// Koneksi ke database
$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

// Ambil data dari permintaan POST
$anime_id = $_POST['anime_id'];
$episode_number = $_POST['episode_number'];
$telegram_id = $_POST['telegram_id'];

// Cek apakah episode telah ditonton oleh pengguna
$stmt = $db->prepare('SELECT * FROM ditonton WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
$stmt->execute([$anime_id, $episode_number, $telegram_id]);
$ditonton = $stmt->rowCount() > 0;

// Ubah status ditonton di database
if ($ditonton) {
    // Jika episode telah ditonton, hapus data dari tabel
    $stmt = $db->prepare('DELETE FROM ditonton WHERE anime_id = ? AND episode_number = ? AND telegram_id = ?');
    $stmt->execute([$anime_id, $episode_number, $telegram_id]);
} else {
    // Jika episode belum ditonton, tambahkan data ke tabel untuk semua resolusi
    $stmt = $db->prepare('INSERT INTO ditonton (anime_id, episode_number, telegram_id) VALUES (?, ?, ?)');
    foreach (['en', 'pt'] as $resolusi) {
        $stmt->execute([$anime_id, $episode_number, $telegram_id]);
    }
}

// Perbarui variabel $ditonton
$ditonton = !$ditonton;

// Kirim respon ke klien
header('Content-Type: application/json');
echo json_encode(['watched' => $ditonton]);