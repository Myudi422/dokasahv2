<?php
$anime_id = $_POST['anime_id'];

$connection = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

$check_query_fav = "SELECT COUNT(*) as count FROM favorit_web WHERE anime_id = '$anime_id'";
$result_fav = mysqli_query($connection, $check_query_fav);
$row_fav = mysqli_fetch_assoc($result_fav);
$is_anime_favorited = ($row_fav['count'] > 0);

if ($is_anime_favorited) {
    $delete_query_fav = "DELETE FROM favorit_web WHERE anime_id = '$anime_id'";
    mysqli_query($connection, $delete_query_fav);
    echo "removed";
} else {
    $insert_query_fav = "INSERT INTO favorit_web (telegram_id, anime_id, created_at) VALUES ('$telegram_id', '$anime_id', NOW())";
    mysqli_query($connection, $insert_query_fav);
    echo "added";
}

mysqli_close($connection);
?>
