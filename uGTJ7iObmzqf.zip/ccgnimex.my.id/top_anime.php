  <!-- Stylesheets -->
<link rel="stylesheet" href="owl/docs/assets/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="owl/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
<script src="owl/docs/assets/vendors/jquery.min.js"></script>
<script src="owl/docs/assets/owlcarousel/owl.carousel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/localforage/1.9.0/localforage.min.js"></script>
<!-- Menambahkan CSS tambahan untuk menampilkan slider dengan benar -->
    <style>
        .owl-carousel .item {
    position: relative;
    text-align: center;
}

.owl-carousel .item img {
    display: block;
    max-width: 100%;
    height: auto;
    margin: 0 auto;
    border-radius: 10px;
    object-fit: cover;
}

.owl-carousel .item p {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    margin: 0;
    padding: 10px;
    color: white;
    background-color: rgba(0, 0, 0, 0.7);
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
}

@media (max-width: 600px) {
    .owl-carousel .item p {
        font-size: smaller;
        /* tambahkan gaya lain yang ingin diubah untuk perangkat mobile di sini */
    }
}
    </style>
    <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
<!-- Konten halaman Anda -->
    <div class="card-body">
      <div class="large-12 columns">
        <div class="owl-carousel owl-theme">
          <!-- Elemen <div> dengan class "item" akan dihapus oleh JavaScript -->
          <div class="item">
            <img src="images/owl-1.png" >
          </div>
          <div class="item">
            <img src="images/owl-2.png" >
          </div>
        </div>
      </div>
      </div>
      </div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
    <!-- Menyertakan file JavaScript jQuery -->
    <!-- Menyertakan file JavaScript Owl Carousel -->
    <script src="owl/docs/assets/owlcarousel/owl.carousel.js"></script>
    <!-- Menambahkan kode JavaScript untuk menampilkan data dari API AniList di slider -->
    <script>
        // Fungsi untuk mengambil data dari API AniList
        async function getTopAnime() {
            const query = `
                query {
                    Page(page: 1, perPage: 10) {
                        media(sort: SCORE_DESC, type: ANIME) {
                            id
                            title {
                                romaji
                            }
                            coverImage {
                                large
                            }
                        }
                    }
                }
            `;

            // Buat kunci cache untuk data topAnime
            const cacheKey = 'topAnimeCache';

            try {
                // Coba ambil data dari cache
                const cachedData = await localforage.getItem(cacheKey);
                
                if (cachedData) {
                    // Jika data ada di cache, gunakan data tersebut
                    return cachedData;
                }

                // Jika tidak ada data di cache, ambil data dari API AniList
                const response = await fetch('https://graphql.anilist.co', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        query: query
                    })
                });

                const data = await response.json();

                // Simpan data ke cache untuk penggunaan berikutnya
                await localforage.setItem(cacheKey, data.data.Page.media);

                return data.data.Page.media;
            } catch (error) {
                console.error(error);
                throw error;
            }
        }

        // Fungsi untuk menampilkan data di slider Owl Carousel
        async function showTopAnime() {
            const topAnime = await getTopAnime();

            topAnime.forEach(anime => {
                const item = document.createElement('div');
                item.classList.add('item');

                const img = document.createElement('img');
                img.src = `https://img.anili.st/media/${anime.id}`;
                img.alt = anime.title.romaji;

                const title = document.createElement('p');
                title.textContent = anime.title.romaji.substring(0, 24) + (anime.title.romaji.length > 24 ? '...' : '');
                title.style.cursor = 'pointer';
                title.onclick = () => window.location.href = `https://ccgnimex.my.id/anime_detail.php?id=${anime.id}`;

                item.appendChild(img);
                item.appendChild(title);

                $('.owl-carousel').append(item);
            });

            $('.owl-carousel').owlCarousel({
                margin: 10,
                nav: true,
                loop: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                }
            });
        }

        // Memanggil fungsi showTopAnime saat halaman dimuat
        $(document).ready(function() {
            // Menghapus elemen <div> dengan class "item" yang sudah ada
            $('.owl-carousel .item').remove();

            // Memanggil fungsi showTopAnime untuk menampilkan data dari API AniList di slider
            showTopAnime();
        });
    </script>