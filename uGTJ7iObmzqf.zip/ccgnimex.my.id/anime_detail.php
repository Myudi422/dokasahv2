<?php
// Import database connection and class
require('db-config.php');


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};

// Start a new session or resume an existing session
session_start();

// Check if telegram_id value is set in $_SESSION array
if (isset($_SESSION['telegram_id'])) {
    // telegram_id value is set and can be used
    $telegramID = $_SESSION['telegram_id'];
} else {
    // telegram_id value is not set and cannot be used
}
?>
<?php

// menghubungkan ke database
$db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

require_once 'vendor/autoload.php';

use Stichoza\GoogleTranslate\GoogleTranslate;





$anime_id = $_GET['id'];
$query = '
query ($id: Int) {
  Media (id: $id, type: ANIME) {
    id
    title {
      romaji
      english
      native
    }
    description
    coverImage {
      large
    }
    bannerImage
    trailer {
      id
      site
      thumbnail
    }
    genres
    tags {
      name
    }
    format
    episodes
    duration
    status
    startDate {
      year
      month
      day
    }
    endDate {
      year
      month
      day
    }
    season
    studios {
      nodes {
        name
      }
    }
    relations {
        edges {
            relationType(version: 2)
            node {
                id
                title {
                    userPreferred
                }
            }
        }
    }
    recommendations(sort: RATING_DESC) {
      edges {
        node {
          mediaRecommendation {
            id
            title {
              romaji
              english
              native
            }
          }
        }
      }
    }
    characters {
      edges {
        node {
          name {
            full
          }
          image {
            large
          }
        }
        voiceActors {
          name {
            full
          }
          language: languageV2
          image {
            large
          }
        }
      }
    }    
  }
}
';

$variables = [
    'id' => (int) $anime_id
];

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
];

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://graphql.anilist.co');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query, 'variables' => $variables]));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

curl_close($ch);

$data = json_decode($result, true);




$anime_title = $data['data']['Media']['title']['romaji'];
$genres = $data['data']['Media']['genres'];
$tags = $data['data']['Media']['tags'];
$description = $data['data']['Media']['description'] ?? 'Deskripsi tidak tersedia';

// Set the target language to Indonesian
$targetLanguage = 'id';

try {
    $tr = new GoogleTranslate();
    $tr->setTarget($targetLanguage);
    
    // Pastikan hanya menerjemahkan jika $description bukan null atau kosong
    $translatedDescription = !empty($description) ? $tr->translate($description) : $description;
} catch (Exception $e) {
    $translatedDescription = $description; // Gunakan deskripsi asli jika terjadi error
}

// Set the target language
$tr->setTarget($targetLanguage);

// Translate the text
$translatedDescription = $tr->translate($description);
$bannerImage = isset($data['data']['Media']['bannerImage']) ? $data['data']['Media']['bannerImage'] : 'assets/img/avatars/foto_banner.jpg';
$trailer = $data['data']['Media']['trailer'];

if ($trailer['site'] == "youtube") {
  $trailer_url = "https://www.youtube.com/watch?v=" . $trailer['id'];
} else {
  $trailer_url = "";
}
$format = $data['data']['Media']['format'];
$episodes = $data['data']['Media']['episodes'];
$duration = $data['data']['Media']['duration'];
$status = $data['data']['Media']['status'];
$start_date = $data['data']['Media']['startDate'];
$end_date = $data['data']['Media']['endDate'];
$season = $data['data']['Media']['season'];
$studios = array_map(function($studio) {
    return $studio['name'];
}, $data['data']['Media']['studios']['nodes']);

$relations = array_map(function($relation) {
    return [
        'relationType' => $relation['relationType'],
        'id' => $relation['node']['id'],
        'title' => $relation['node']['title']['userPreferred']
    ];
}, $data['data']['Media']['relations']['edges']);
// ...

// memeriksa apakah ada baris yang cocok di tabel episode
$query = "SELECT * FROM episodes WHERE anime = '$anime_id'";
$result = mysqli_query($db, $query);

?>

<!-- ... -->


<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Download Batch & Nonton Anime <?php echo $anime_title; ?> Sub Indonesia</title>
<meta name="description" content="Tonton dan download anime <?php echo $anime_title; ?> sub Indonesia secara gratis di ccgnimex. Kami menyediakan berbagai macam anime terbaru dan terpopuler, termasuk <?php echo $anime_title; ?> dalam kualitas HD 360p, 480p, 720p, dan 1080p, dan dalam format batch.">
<meta name="keywords" content="streaming anime <?php echo $anime_title; ?>, download anime <?php echo $anime_title; ?>, anime <?php echo $anime_title; ?> lengkap indo, <?php echo $anime_title; ?> sub indo, <?php echo $anime_title; ?> batch indo">
<meta name="author" content="ccgnimex">
<link rel="apple-touch-icon" sizes="57x57" href="/icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icon1/favicon-16x16.png">
<link rel="manifest" href="/icon1/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/icon1/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
    <style>
    
@media (min-width: 768px) {
  .btn-group .btn-sm:first-child span {
    display: none;
  }
}
.anime-detail {
  position: relative;
  margin: 20px 0;
}

.anime-detail .banner-image {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-size: cover;
  background-position: center;
  filter: blur(30px);
}

.anime-detail .banner-image::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: white;
  opacity: 0.7;
}

.anime-detail .container {
  position: relative;
  padding: 20px;
}

.anime-detail h1 {
  font-size: 2rem;
}

.anime-detail .badge {
  margin-right: 5px;
  background-color: #007bff;
}
@media (max-width: 767px) {
  .card.mb-4 {
    display: none;
  }
}


@media (max-width: 768px) {
    .anime-detail img {
        max-width:100%;
        margin-bottom:20px;
        transition: transform .2s ease-in-out; 
    }
    .anime-detail img:hover {
        transform: scale(1.1);
    }
}
</style>

<style>

.dropdown-menu {
  background-color: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 0.25rem;
  padding: 0.5rem 0;
}

.dropdown-menu a {
  color: #212529;
  display: block;
  padding: 0.25rem 1.5rem;
  text-decoration: none;
}

.dropdown-menu a:hover {
  background-color: #e9ecef;
}

/* Style untuk grid anime */
.anime-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
  grid-gap: 10px;
  justify-items: center;
  margin: 10px;
}

/* Style untuk item anime */
.anime-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  padding: 10px;
}

/* Style untuk judul anime */
.anime-title {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 5; /* jumlah baris maksimum */
  overflow: hidden;
  text-overflow: ellipsis;
  border: 1px solid #4e73df;
  padding: 7px;
  border-radius: 7px;
  font-size: 11px;
  font-weight: bold;
  margin: 7px 0px;
  text-align: center;
}

.anime-title {
  border: 1px solid #4e73df;
  padding: 7px;
  border-radius: 7px;
}

/* Style untuk genre anime */
.anime-genres {
  font-size: 7px;
  margin-bottom: 5px;
  text-align: center;
}

/* Style untuk tombol "Load More" */
/* Style untuk tombol "Load More" */
.load-more {
  display: block;
  margin: 10px auto;
  padding: 0.75em 1.5em;
  font-size: 1.2em;
  font-weight: bold;
  background-color: #0077ff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  max-width: 270px;
  box-sizing: border-box;
}

/* Style untuk tombol "Load More" pada layar yang lebih besar */
@media only screen and (min-width: 768px) {
  .load-more {
    max-width: none;
    padding: 1em 2em;
  }
}


/* Style untuk gambar anime */
.anime-item img {
  width: 100%;
  height: auto;
  border-radius: 5px;
  object-fit: cover; /* tambahkan properti object-fit */
}

/* Style untuk tampilan mobile */
@media only screen and (max-width: 768px) {
  /* Style untuk grid anime */
  .anime-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    grid-gap: 5px;
  }

  /* Style untuk judul anime */
  .anime-title {
    font-size: 14px;
  }

  /* Style untuk genre anime */
  .anime-genres {
    font-size: 10px;
  }

  /* Style untuk tombol "Load More" */
  .load-more {
    font-size: 14px;
    padding: 8px 16px;
  }
}

.bg-opacity-40 {
    background-color: rgba(0, 0, 0, 0.0);
}

</style>
<style>
    .prequel-sequel-box {
        border-radius: 10px;
        padding: 10px;
        margin-bottom: 20px;
    }
    .prequel-sequel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    .prequel-sequel-header h2 {
        margin: 0;
    }
    .prequel-sequel-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        grid-gap: 10px;
    }
    .prequel-sequel-item {
        text-align: center;
    }
    .prequel-sequel-item img {
    width: 100%;
}

.prequel-sequel-item .anime-title {
    font-size: 0.8em;
}
</style>

<style>
    .anime-recommendations-box {
        border-radius: 10px;
        padding: 10px;
        margin-bottom: 20px;
    }
    .anime-recommendations-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    .anime-recommendations-header h2 {
        margin: 0;
    }
    .anime-recommendations-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        grid-gap: 10px;
    }
    .anime-recommendations-item {
        text-align: center;
    }
    .anime-recommendations-item img {
        width: 100%;
    }
</style>
<script>
    
    // Mencari semua elemen gambar di halaman
var images = document.getElementsByTagName('img');

// Loop melalui setiap elemen gambar
for (var i = 0; i < images.length; i++) {
  var imageUrl = images[i].src;

  // Cek apakah gambar masih berlaku di localStorage
  var cachedData = localStorage.getItem(imageUrl);
  if (cachedData) {
    var cachedImageData = JSON.parse(cachedData);
    var expirationDate = new Date(cachedImageData.expiration);

    // Periksa apakah gambar sudah kedaluwarsa
    if (expirationDate > new Date()) {
      displayImage(cachedImageData.data);
      continue;
    }
  }

  // Jika gambar tidak ada di localStorage atau sudah kedaluwarsa, muat gambar dari URL
  loadImage(imageUrl);
}

// Fungsi untuk memuat gambar dari URL
function loadImage(url) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.responseType = 'blob';

  xhr.onload = function() {
    if (xhr.status === 200) {
      // Konversi gambar menjadi objek Blob
      var blob = xhr.response;

      // Simpan gambar ke localStorage dengan tanggal kedaluwarsa
      var expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() + 10); // 10 hari kedaluwarsa

      var reader = new FileReader();
      reader.onloadend = function() {
        var imageData = reader.result;
        var cachedData = {
          data: imageData,
          expiration: expirationDate.toISOString()
        };
        localStorage.setItem(url, JSON.stringify(cachedData));
        displayImage(imageData);
      };
      reader.readAsDataURL(blob);
    }
  };

  xhr.send();
}

// Fungsi untuk menampilkan gambar
function displayImage(imageData) {
  var img = document.createElement('img');
  img.src = imageData;
  document.body.appendChild(img);
}

</script>
</head>

<body id="page-top" class>
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0 toggled">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="komik"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="kategori"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET" action="https://ccgnimex.my.id/">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET" action="https://ccgnimex.my.id/">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>

                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">3+</span><i class="fas fa-bell fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-primary icon-circle"><i class="fas fa-file-alt text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 12, 2019</span>
                                                <p>A new monthly report is ready to download!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-success icon-circle"><i class="fas fa-donate text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 7, 2019</span>
                                                <p>$290.29 has been deposited into your account!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-warning icon-circle"><i class="fas fa-exclamation-triangle text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 2, 2019</span>
                                                <p>Spending Alert: We've noticed unusually high spending for your account.</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                           <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid">
<div class="anime-detail">
  <div class="banner-image" style="background-image: url('<?php echo $bannerImage; ?>');"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <img src="<?php echo $data['data']['Media']['coverImage']['large']; ?>" alt="<?php echo $anime_title; ?>" class="img-fluid mb-3">
    <div class="kontlo" style="margin-bottom: 15px;">
    <button type="button" class="btn btn-primary btn-sm" style="width: 40%; margin-right: 10px;">
  <i class="fas fa-film"></i>
  <?php if ($trailer_url != ""): ?>
    <a class="popup-youtube" href="<?php echo $trailer_url; ?>" style="color: white;">
      <span style="font-size: 0.8rem;">Trailer</span>
    </a>
  <?php else: ?>
    <span style="font-size: 0.5rem;">Tidak ada</span>
  <?php endif; ?>
</button>
        <div class="btn-group" style="width: 43%;">
      <!-- Button trigger modal -->
<?php
// Database credentials
$host = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

// Connect to the database
$db = new mysqli($host, $username, $password, $database);

// Check for connection errors
if ($db->connect_error) {
  die('Connection failed: ' . $db->connect_error);
}

// Create the admins table if it doesn't exist
$db->query('CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  telegram_id TEXT NOT NULL
)');

// Get Telegram user id from session
$telegramId = $_SESSION['telegram_id'];

// Check if the current user is an admin
$stmt = $db->prepare('SELECT * FROM admins WHERE telegram_id = ?');
$stmt->bind_param('s', $telegramId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

// Display the button for all users
echo '<button type="button" class="btn btn-primary btn-sm"';
if ($admin) {
  // The current user is an admin, allow them to open the modal
  echo ' data-bs-toggle="modal" data-bs-target="#exampleModal"';
} else {
  // The current user is not an admin, display a message when they click the button
  echo ' onclick="alert(\'You are not an admin!\')"';
}
echo '>
  <i class="fas fa-save"></i> Save
</button>';
?>
      <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown">
        <span class="caret"></span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end" role="menu">
  <li><a href="#" onclick="showListPopup()">Tambah Batch</a></li>
  <li><a href="#" onclick="showNotifPopup()">Kirim Notifikasi</a></li>
</ul>

</div>
</div>

<!-- Popup Card -->
<div class="modal fade" id="listPopupCard" tabindex="-1" aria-labelledby="listPopupCardLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="listPopupCardLabel">Upload Batch</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <?php
if(isset($_POST["submitx"])){
    $servername = "localhost";
    $username = "ccgnimex";
    $password = "aaaaaaac";
    $dbname = "ccgnimex";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    // Ambil nilai dari form
    $anime_id = $_POST["id_anime"];
    $resolusi_360p = !empty($_POST["resolusi_360p"]) ? str_replace(" - ", "\n", $_POST["resolusi_360p"]) : NULL;
    $resolusi_480p = !empty($_POST["resolusi_480p"]) ? str_replace(" - ", "\n", $_POST["resolusi_480p"]) : NULL;
    $resolusi_720p = !empty($_POST["resolusi_720p"]) ? str_replace(" - ", "\n", $_POST["resolusi_720p"]) : NULL;
    $resolusi_1080p = !empty($_POST["resolusi_1080p"]) ? str_replace(" - ", "\n", $_POST["resolusi_1080p"]) : NULL;

    // Query untuk mengecek apakah anime_id sudah ada di dalam database
    $query_check = "SELECT * FROM batch WHERE anime_id = '$anime_id'";
    $result_check = mysqli_query($conn, $query_check);

    if (mysqli_num_rows($result_check) > 0) {
      // Jika anime_id sudah ada, tampilkan pesan peringatan
      echo "<div class='container mt-3'>";
      echo "<div class='alert alert-danger' role='alert'>";
      echo "Error: Anime dengan ID $anime_id sudah ada di dalam database.";
      echo "</div>";
      echo "</div>";
    } else {
      // Jika anime_id belum ada, lakukan insert data ke dalam tabel
      $sql = "INSERT INTO batch (anime_id, 360p, 480p, 720p, 1080p) VALUES ('$anime_id', '$resolusi_360p', '$resolusi_480p', '$resolusi_720p', '$resolusi_1080p')";

      if (mysqli_query($conn, $sql)) {
        echo "<div class='container mt-3'>";
        echo "<div class='alert alert-success' role='alert'>";
        echo "Data berhasil ditambahkan";
        echo "</div>";
        echo "</div>";
      } else {
        echo "<div class='container mt-3'>";
        echo "<div class='alert alert-danger' role='alert'>";
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        echo "</div>";
        echo "</div>";
      }
    }

    mysqli_close($conn);
}
?>
        <!-- Isi konten di sini -->
        <div class="container mt-3">
          <?php if ($admin) { ?>
            <h2 class="text-center mb-4">Tambah Batch File</h2>
            <form action="anime_detail.php?id=<?php echo $anime_id ?>" method="post">
              <div class="mb-3">
                <label for="id_anime" class="form-label">ID Anime:</label>
                <input type="text" class="form-control" id="id_anime" name="id_anime" value="<?php echo $anime_id ?>">
              </div>
              <div class="mb-3">
                <label for="resolusi_360p" class="form-label">360p:</label>
                <input type="text" class="form-control" id="resolusi_360p" name="resolusi_360p">
              </div>
              <div class="mb-3">
                <label for="resolusi_480p" class="form-label">480p:</label>
                <input type="text" class="form-control" id="resolusi_480p" name="resolusi_480p">
              </div>
              <div class="mb-3">
                <label for="resolusi_720p" class="form-label">720p:</label>
                <input type="text" class="form-control" id="resolusi_720p" name="resolusi_720p">
              </div>
              <div class="mb-3">
                <label for="resolusi_1080p" class="form-label">1080p:</label>
                <input type="text" class="form-control" id="resolusi_1080p" name="resolusi_1080p">
              </div>
              <div class="text-center">
                <button type="submitx" class="btn btn-primary" name="submitx">Submit</button>
              </div>
            </form>
          <?php } else { ?>
            <p class="text-center">Anda Bukan admin, jika ingin upload, silahkan pm admin digrup telegram!</p>
          <?php } ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
  function showListPopup() {
    $('#listPopupCard').modal('show'); // Menampilkan popup card saat diklik
  }

  function checkAdmin() {
    <?php if ($admin) { ?>
      showListPopup();
    <?php } else { ?>
      alert('Anda Bukan admin, jika ingin upload, silahkan pm admin digrup telegram!');
    <?php } ?>
  }
</script>

<!-- Popup Card -->
<div class="modal fade" id="notifPopupCard" tabindex="-1" aria-labelledby="notifPopupCardLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="notifPopupCardLabel">Notifikasi</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <?php
if (isset($_POST['submit'])) {
    $botToken = '1920905087:AAG_xCvsdjxVu8VUDt9s4JhD22ND-UIJttQ'; // Replace with your bot token
    $animeId = (int)$_POST['animeId'];
    $status = $_POST['status'];
    $episode = (int)$_POST['episode'];

    if ($status === 'ongoing') {
        $groupId = '-1001519273319'; // ID for ongoing anime group
        $replyMessage = 67737;
        $watchUrl = "https://ccgnimex.my.id/streaming.php?id={$animeId}&episode={$episode}";
        $caption = "Sudah Tersedia !!";
    } elseif ($status === 'completed') {
        $groupId = '-1001519273319'; // ID for completed anime group
        $replyMessage = 72750;
        $watchUrl = "https://ccgnimex.my.id/anime_detail.php?id={$animeId}#";
        $caption = "Batch {$title} Sudah tersedia untuk didownload !!";
    }

    // Mengambil data anime menggunakan GraphQL
    $apiUrl = 'https://graphql.anilist.co';
    $query = <<<'GRAPHQL'
        query ($animeId: Int) {
            Media (id: $animeId, type: ANIME) {
                title {
                    romaji
                }
                averageScore
                genres
                coverImage {
                    large
                }
            }
        }
GRAPHQL;

    $variables = json_encode(['animeId' => $animeId]);

    $response = file_get_contents($apiUrl, false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode([
                'query' => $query,
                'variables' => $variables,
            ]),
        ],
    ]));

    $data = json_decode($response, true);

    if (isset($data['data']['Media'])) {
        // Mendapatkan informasi yang diperlukan dari data anime
        $title = $data['data']['Media']['title']['romaji'];
        $score = $data['data']['Media']['averageScore'];
        $genres = implode(", ", $data['data']['Media']['genres']);
        if (isset($data['data']['Media']['coverImage']['large'])) {
            $imageUrl = "https://img.anili.st/media/{$animeId}";
        } else {
            $imageUrl = $data['data']['Media']['coverImage']['large'];
        }

        // Menghasilkan caption pesan dengan informasi anime dan episode
        if ($status === 'ongoing') {
            $caption = "Episode: {$episode} - {$title} {$caption}\n\nScore: {$score}\nGenre: {$genres}\n";
        } elseif ($status === 'completed') {
            $caption = "Batch {$title} Sudah tersedia untuk didownload !!\n\nScore: {$score}\nGenre: {$genres}\n";
        }

        // Membentuk data untuk merespon pesan di grup
        $telegramDataReply = array(
            'chat_id' => $groupId,
            'photo' => $imageUrl,
            'caption' => $caption,
            'reply_to_message_id' => $replyMessage,
            'reply_markup' => json_encode(array(
                'inline_keyboard' => array(
                    array(
                        array(
                            'text' => 'Tonton/Unduh Sekarang',
                            'url' => $watchUrl
                        )
                    )
                )
            ))
        );

        $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendPhoto";

        $optionsReply = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($telegramDataReply)
            )
        );

        // Merespon pesan di grup
        $contextReply = stream_context_create($optionsReply);
        $resultReply = file_get_contents($telegramApiUrl, false, $contextReply);

        if ($resultReply === false) {
            echo '<script>alert("Terjadi kesalahan dalam mengirim pesan.");</script>';
        } else {
            echo '<script>alert("Pesan berhasil dikirim sebagai respon ke pesan di grup.");</script>';
        }
    }
}
?>
        <!-- Isi konten di sini -->
        <div class="container mt-3">
          <?php if ($admin) { ?>
            <h1>Kirim Pesan Anime ke Grup</h1>
    <form method="post" action="">
        <div class="form-group">
            <label for="animeId">ID Anime:</label>
            <input type="text" class="form-control" id="animeId" name="animeId" value="<?php echo $anime_id ?>">
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select class="form-control" id="status" name="status" required>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
            </select>
        </div>
        <div class="form-group">
            <label for="episode">Episode:</label>
            <input type="number" class="form-control" id="episode" name="episode">
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
    </form>
          <?php } else { ?>
            <p class="text-center">Anda Bukan admin, jika ingin upload, silahkan pm admin digrup telegram!</p>
          <?php } ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<script>
  function showNotifPopup() {
    $('#notifPopupCard').modal('show'); // Menampilkan popup card saat diklik
  }

  function checkAdmin() {
    <?php if ($admin) { ?>
      showListPopup();
    <?php } else { ?>
      alert('Anda tidak diizinkan untuk mengirim pesan melalui bot - Bukan Admin!');
    <?php } ?>
  }
</script>

    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Panel</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
<?php
// Koneksi ke database
$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

// Cek apakah kolom resolusi sudah ada di dalam tabel nonton
$stmt = $db->prepare("SHOW COLUMNS FROM `nonton` LIKE 'resolusi'");
$stmt->execute();
if ($stmt->rowCount() == 0) {
    // Kolom resolusi belum ada di dalam tabel nonton, tambahkan kolom tersebut
    $stmt = $db->prepare("ALTER TABLE `nonton` ADD `resolusi` VARCHAR(255) NOT NULL AFTER `video_url`");
    $stmt->execute();
}

// Cek apakah form telah disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $anime_id = $_POST['anime_id'];
    $episode_links_en = $_POST['episode_links_en'];
    $episode_links_pt = $_POST['episode_links_pt'];
    $episode_links_softsub = $_POST['episode_links_softsub'];
    $link_count = $_POST['link_count'];
    $episode_number_start = $_POST['episode_number_start'];
    $episode_number_end = $_POST['episode_number_end'];
    $episode_number_manual = $_POST['episode_number_manual'];

    // Cek apakah anime_id kosong
    if (empty($anime_id)) {
        echo 'Silahkan masukkan ID Anime!';
    } else {
        // Pisahkan setiap link menjadi array
        $links_en = explode("\n", $episode_links_en);
        $links_pt = explode("\n", $episode_links_pt);
        $links_softsub = explode("\n", $episode_links_softsub);

        // Validasi setiap link
        $valid_links_en = [];
        foreach ($links_en as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_en[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_en[] = $next_link;
                }
            }
        }

        $valid_links_pt = [];
        foreach ($links_pt as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_pt[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_pt[] = $next_link;
                }
            }
        }

        $valid_links_softsub = [];
        foreach ($links_softsub as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_softsub[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_softsub[] = $next_link;
                }
            }
        }

        if (empty($valid_links_en) && empty($valid_links_pt) && empty($valid_links_softsub)) {
            echo 'Mohon masukkan link yang valid!';
        } else {
            // Tampilkan episode yang sudah ada di dalam database
            $stmt = $db->prepare('SELECT * FROM nonton WHERE anime_id = ? ORDER BY episode_number ASC');
            $stmt->execute([$anime_id]);
            $episodes = $stmt->fetchAll();


            echo '<ul>';
            foreach ($episodes as $episode) {
                echo '<li>';
                echo 'Episode ' . htmlspecialchars($episode['episode_number']) . ': ';
                echo ' <button onclick="deleteEpisode(' . htmlspecialchars($episode['id']) . ')">Delete</button>';
echo '</li>';
}
echo '</ul>';

            // Masukkan setiap link ke dalam database sebagai episode terpisah
        foreach ($valid_links_en as $index => $link) {
            $episode_number = $episode_number_start + $index;
            if ($episode_number <= $episode_number_end) {
                if (!empty($episode_number_manual)) {
                    // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                    $episode_number = intval($episode_number_manual);
                }

                // Cek apakah episode sudah ada di dalam database
                // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                $stmt->execute([$anime_id, $episode_number, 'en']);
                if ($stmt->fetchColumn() == 0) {
                    // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                    $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                    $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'en']);
                }
            }
        }

        foreach ($valid_links_pt as $index => $link) {
            $episode_number = $episode_number_start + $index;
            if ($episode_number <= $episode_number_end) {
                if (!empty($episode_number_manual)) {
                    // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                    $episode_number = intval($episode_number_manual);
                }

                // Cek apakah episode sudah ada di dalam database
                // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                $stmt->execute([$anime_id, $episode_number, 'pt']);
                if ($stmt->fetchColumn() == 0) {
                    // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                    $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                    $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'pt']);
                }
            }
        }

            // Masukkan setiap link ke dalam database sebagai episode terpisah
        foreach ($valid_links_softsub as $index => $link) {
            $episode_number = $episode_number_start + $index;
            if ($episode_number <= $episode_number_end) {
                if (!empty($episode_number_manual)) {
                    // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                    $episode_number = intval($episode_number_manual);
                }

                // Cek apakah episode sudah ada di dalam database
                // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                $stmt->execute([$anime_id, $episode_number, 'softsub']);
                if ($stmt->fetchColumn() == 0) {
                    // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                    $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                    $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'softsub']);
                }
            }
        }

        echo 'Episode berhasil ditambahkan!';
    }
}
}

// Cek apakah tombol delete ditekan
if (isset($_POST['delete'])) {
// Ambil ID episode yang akan dihapus
$episode_id = $_POST['episode_id'];
// Hapus episode dari database
$stmt = $db->prepare('DELETE FROM nonton WHERE id = ?');
$stmt->execute([$episode_id]);

echo 'Episode berhasil dihapus!';
}
?>

    <title>Tambah Episode</title>
<h1>Tambah Episode</h1>
<form method="post">
    <div class="mb-3">
        <label for="anime_id" class="form-label">ID Anime:</label>
        <input type="text" class="form-control" id="anime_id" name="anime_id" value="<?php echo $anime_id ?>">
    </div>
    <div class="mb-3">
        <label for="episode_links_en" class="form-label">Link Episode (En) 720p:</label>
        <textarea class="form-control" id="episode_links_en" name="episode_links_en"></textarea>
    </div>
    <div class="mb-3">
        <label for="episode_links_pt" class="form-label">Link Episode (Pt) 360p:</label>
        <textarea class="form-control" id="episode_links_pt" name="episode_links_pt"></textarea>
    </div>
    <div class="mb-3">
        <label for="episode_links_en" class="form-label">Link Episode Softsub:</label>
        <textarea class="form-control" id="episode_links_en" name="episode_links_softsub"></textarea>
    </div>
    <div class="mb-3">
        <label for="link_count" class="form-label">Jumlah Link:</label>
        <input type="number" class="form-control" id="link_count" name="link_count">
    </div>
    <div class="mb-3">
        <label for="episode_number_start" class="form-label">Nomor Episode Awal:</label>
        <input type="number" class="form-control" id="episode_number_start" name="episode_number_start">
    </div>
    <div class="mb-3">
        <label for="episode_number_end" class="form-label">Nomor Episode Akhir:</label>
        <input type="number" class="form-control" id="episode_number_end" name="episode_number_end">
    </div>
    <div class="mb-3">
        <label for="episode_number_manual" class="form-label">Nomor Episode (Opsional, gunakan jika ingin nomor episode manual):</label>
        <input type="number" class="form-control" id="episode_number_manual" name="episode_number_manual">
    </div>

    <input type="submit" class="btn btn-primary" name="submit" value="Submit">
</form>




    <script>
        function deleteEpisode(episodeId) {
            var form = document.createElement('form');
            form.method = 'post';

            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'delete';
            input.value = 'true';
            form.appendChild(input);

            var input2 = document.createElement('input');
            input2.type = 'hidden';
            input2.name = 'episode_id';
            input2.value = episodeId;
            form.appendChild(input2);

            document.body.appendChild(form);
            form.submit();
        }
    </script>
        <!-- You can add the content of submit.php here -->
      </div>
    </div>
  </div>
</div>
    <?php $hasPrequelOrSequel = false; ?>
<?php foreach ($relations as $relation): ?>
    <?php if (in_array($relation['relationType'], ['PREQUEL', 'SEQUEL'])): ?>
        <?php $hasPrequelOrSequel = true; ?>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; ?>

<?php if ($hasPrequelOrSequel): ?>
    <div class="prequel-sequel-box">
        <div class="prequel-sequel-header">
            <p><strong>Prequel & Sequel</strong></p>
            <i class="fas fa-info-circle" style="
    margin-bottom: 18px;
"></i>
        </div>
        <div class="prequel-sequel-grid">
    <?php foreach ($relations as $relation): ?>
        <?php if (in_array($relation['relationType'], ['PREQUEL', 'SEQUEL'])): ?>
            <div class="prequel-sequel-item">
                <img class="lazyload" data-src="https://img.anili.st/media/<?= $relation['id'] ?>" alt="<?= $relation['title'] ?>">
                <h3 class="anime-title">
                    <a href="anime_detail.php?id=<?= $relation['id'] ?>">
                        <?= substr($relation['title'], 0, 24) . (strlen($relation['title']) > 24 ? '...' : '') ?>
                    </a>
                </h3>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
    </div>
<?php else: ?>
    <div class="card mb-4" style="width: 87%; color: black;">
        <div class="card-header">
    <strong>Info Anime</strong>
    
  </div>
  <div class="card-body bg-opacity-40">
    <div class="additional-info mb-3" style="font-size: 0.7rem;">
      <p><strong>Format:</strong> <?php echo $format; ?> | <strong>Episodes:</strong> <?php echo $episodes; ?> | <strong>Duration:</strong> <?php echo $duration; ?>m</p>
      <hr>
      <p><strong>Status:</strong> <?php echo $status; ?> | <?php echo $start_date['year'] . '-' . $start_date['month'] . '-' . $start_date['day']; ?> - <?php echo $end_date['year'] . '-' . $end_date['month'] . '-' . $end_date['day']; ?></p>
      <hr>
      <p><strong>Season:</strong> <?php echo $season; ?></p>
      <hr>
      <p><strong>Studios:</strong> <?php echo implode(', ', $studios); ?></p>
    </div>
  </div>
</div>
<?php endif; ?>
<style>
.character-box {
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 20px;
}

.character-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.character-header p {
    margin: 0;
}

.character-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    grid-gap: 10px;
}

.character-item {
    text-align: center;
}

.character-img-wrap {
    position: relative;
}

.character-img-wrap img {
    width: 100%;
}

@media screen and (min-width: 600px) {
    .character-img-wrap img {
        width: 80%;
    }
}


.character-text-wrap {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 5px;
    background-color: rgba(0, 0, 0, 0.7);
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    color: #fff;
    font-size: 12px;
    line-height: 1.2;
}

.character-name {
    margin: 0;
    font-weight: bold;
    font-size: 14px;
    line-height: 1.2;
}

.voice-actor-name {
    margin: 0;
    font-size: 12px;
    line-height: 1.2;
}

@media screen and (max-width: 600px) {
    .character-grid {
        grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
    }
}

.voice-actor-img {
    position: absolute;
    top: -20px;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 40px;
    border-radius: 50%;
}

@media screen and (min-width: 600px) {
    .voice-actor-img {
        top: -30px;
        width: 60px;
        height: 60px;
    }
}
</style>
<div class="character-box">
    <div class="character-header">
        <p><strong>Characters</strong></p>
        <nav aria-label="Page navigation" class="ml-auto">
            <ul class="pagination mb-0">
                <li class="page-item"><a class="page-link character-prev-btn" href="#">Prev</a></li>
                <li class="page-item"><span class="page-link character-page-num"></span></li>
                <li class="page-item"><a class="page-link character-next-btn" href="#">Next</a></li>
            </ul>
        </nav>
    </div>
    <div class="character-grid">
        <?php foreach ($data['data']['Media']['characters']['edges'] as $character): ?>
            <?php $voiceActor = $character['voiceActors'][0]; ?>
            <div class="character-item">
                <div class="character-img-wrap">
                    <img class="lazyload" data-src="<?= $character['node']['image']['large'] ?>" alt="<?= $character['node']['name']['full'] ?>">
                    <div class="character-text-wrap">
                        <h3 class="character-name"><?= $character['node']['name']['full'] ?></h3>
                        <?php if ($voiceActor): ?>
                            <h4 class="voice-actor-name"><?= $voiceActor['name']['full'] ?> (<?= $voiceActor['language'] ?>)</h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>


<script>
// JavaScript code to add pagination feature without reloading the page

let characterCurrentPage = 1;
const characterItemsPerPage = 2;
const characterItems = document.querySelectorAll('.character-item');
const characterTotalPages = Math.ceil(characterItems.length / characterItemsPerPage);

function showCharacterPage(page) {
  // Hide all items
  characterItems.forEach(item => item.style.display = 'none');
  
  // Show only items that match the selected page
  const start = (page - 1) * characterItemsPerPage;
  const end = start + characterItemsPerPage;
  for (let i = start; i < end; i++) {
    if (characterItems[i]) {
      characterItems[i].style.display = 'block';
    }
  }
  
  // Update current page number
  document.querySelector('.character-page-num').textContent = `${page} / ${characterTotalPages}`;
  
  // Disable prev/next buttons if necessary
  document.querySelector('.character-prev-btn').parentElement.classList.toggle('disabled', page === 1);
  document.querySelector('.character-next-btn').parentElement.classList.toggle('disabled', page === characterTotalPages);
}

document.querySelector('.character-prev-btn').addEventListener('click', (event) => {
  event.preventDefault();
  if (characterCurrentPage > 1) {
    showCharacterPage(--characterCurrentPage);
  }
});

document.querySelector('.character-next-btn').addEventListener('click', (event) => {
  event.preventDefault();
  if (characterCurrentPage < characterTotalPages) {
    showCharacterPage(++characterCurrentPage);
  }
});

showCharacterPage(1);
</script>
      </div>
      <div class="col-md-8">
        <h1 style="color: black;"><?php echo $anime_title; ?></h1>
        <div class="genre mb-3">
          <?php foreach ($genres as $genre): ?>
            <span class="badge bg-secondary"><?php echo $genre; ?></span>
          <?php endforeach; ?>
        </div>
        <hr>
        <div class="card mb-5" style="color: black;">
             <div class="row">
      <div class="col-12">
        <div class="btn-group d-flex" role="group">
          <button class="btn btn-primary flex-fill btn-responsive">
            <i class="fas fa-heart"></i> Favorit
          </button>
          
          <?php
// Lakukan koneksi ke database
$connection = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");


$check_query_notif = "SELECT COUNT(*) as count FROM add_notif WHERE anime_id = '$anime_id' AND telegram_id = '$telegram_id'";
$result_notif = mysqli_query($connection, $check_query_notif);
$row_notif = mysqli_fetch_assoc($result_notif);
$is_anime_added = ($row_notif['count'] > 0);

// Tutup koneksi
mysqli_close($connection);
?>


<button id="notifButton" class="btn btn-<?php echo ($is_anime_added ? 'info' : 'success'); ?> flex-fill btn-responsive">
  <i class="fas fa-bell<?php echo ($is_anime_added ? '' : '-slash'); ?>"></i>
  <?php echo ($is_anime_added ? 'Hidup' : 'Mati'); ?>
</button>

<script>
document.addEventListener("DOMContentLoaded", function() {
  var notifButton = document.getElementById("notifButton");
  
  notifButton.addEventListener("click", function() {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "process_notification.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
        var response = xhr.responseText.trim();
        if (response === "success") {
          notifButton.innerHTML = '<i class="fas fa-bell"></i> Hidup';
          notifButton.classList.remove("btn-success");
          notifButton.classList.add("btn-info");
        } else if (response === "removed") {
          notifButton.innerHTML = '<i class="fas fa-bell-slash"></i> Mati';
          notifButton.classList.remove("btn-info");
          notifButton.classList.add("btn-success");
        }
      }
    };
    
    xhr.send("anime_id=<?php echo $anime_id; ?>&telegram_id=<?php echo $telegram_id; ?>");
  });
});
</script>
        </div>
        </div>
        </div>
  <div class="card-header">
    <strong>Sinopsis</strong>
    
  </div>
  <div class="card-body">
    <div class="info mb-3">
      <p style="color: black;"><?php
        if (strlen($translatedDescription) > 600) {
          echo substr($translatedDescription, 0, 600) . '...';
        } else {
          echo $translatedDescription;
        }
      ?></p>
    </div>
  </div>
</div>
<div class="card mb-3" style="color: black;">
  <div class="card-header bg-transparent">
    <div class="d-flex justify-content-between align-items-center">
      <span><strong>Info Anime</strong></span>
      <i class="fas fa-info-circle"></i>
    </div>
  </div>
  <div class="card-body bg-opacity-40">
    <div class="additional-info mb-3">
      <p><strong>Format:</strong> <?php echo $format; ?> | <strong>Episodes:</strong> <?php echo $episodes; ?> | <strong>Duration:</strong> <?php echo $duration; ?>m</p>
      <hr>
      <p><strong>Status:</strong> <?php echo $status; ?> | <?php echo $start_date['year'] . '-' . $start_date['month'] . '-' . $start_date['day']; ?> - <?php echo $end_date['year'] . '-' . $end_date['month'] . '-' . $end_date['day']; ?></p>
      <hr>
      <p><strong>Season:</strong> <?php echo $season; ?></p>
      <hr>
      <p><strong>Studios:</strong> <?php echo implode(', ', $studios); ?></p>
    </div>
  </div>
</div>
<?php
// Kode PHP untuk menampilkan rekomendasi dalam tampilan grid yang dibungkus dengan div card
?>
<div class="recommendation-box">
    <div class="recommendation-header">
        <p><strong>Rekomendasi</strong></p>
        <nav aria-label="Page navigation" class="ml-auto">
            <ul class="pagination mb-0">
                <li class="page-item"><a class="page-link prev-btn" href="#">Prev</a></li>
                <li class="page-item"><span class="page-link page-num"></span></li>
                <li class="page-item"><a class="page-link next-btn" href="#">Next</a></li>
            </ul>
        </nav>
    </div>
<div class="recommendation-grid">
    <?php foreach ($data['data']['Media']['recommendations']['edges'] as $recommendation): ?>
        <?php $anime = $recommendation['node']['mediaRecommendation']; ?>
        <div class="recommendation-item">
    <div class="image-container">
        <img class="lazyload" data-src="https://img.anili.st/media/<?= $anime['id'] ?>" alt="<?= $anime['title']['romaji'] ?>">
        <i class="bell fas fa-bell-slash" data-anime-id="<?= $anime['id'] ?>"></i>
        <?php
            // Koneksi ke database MySQL
            $db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

            // Query untuk mengambil data dari tabel episodes
            $query = "SELECT * FROM episodes WHERE anime = '" . $anime['id'] . "'";
            $query_result = mysqli_query($db, $query);

            // membuat query SQL baru untuk memeriksa apakah id anime ada di tabel nonton
            $sql2 = "SELECT anime_id FROM nonton WHERE anime_id = '" . $anime['id'] . "'";

            // menjalankan query dan memeriksa hasilnya
            $result2 = mysqli_query($db, $sql2);

            if (mysqli_num_rows($result2) > 0 && mysqli_num_rows($query_result) > 0) {
                // menampilkan ceklis Bot | Web jika id anime ada di kedua tabel
                echo '<span class="availability"><i class="fas fa-check"></i> Bot | Web</span>';
            } elseif (mysqli_num_rows($result2) > 0) {
                // menampilkan ceklis Web jika id anime hanya ada di tabel nonton
                echo '<span class="availability"><i class="fas fa-check"></i> Web</span>';
            } elseif (mysqli_num_rows($query_result) > 0) {
                // menampilkan ceklis Bot jika id anime hanya ada di tabel episodes
                echo '<span class="availability"><i class="fas fa-check"></i> Bot</span>';
            }
        ?>
    </div>
    <h3 class="anime-title"><a href="anime_detail?id=<?= $anime['id'] ?>"><?= substr($anime['title']['romaji'], 0, 24) . (strlen($anime['title']['romaji']) > 24 ? '...' : '') ?></a></h3>
</div>
<?php endforeach; ?>
</div>




<script>
    $(document).ready(function() {
    let clickCount = 0;

    // Get all bell icon elements
    const $bells = $('.bell');

    // Loop through all bell icon elements
    $bells.each(function() {
        // Get current bell icon element
        const $bell = $(this);

        // Get anime id from data attribute
        const animeId = $bell.data('anime-id');

        // Get Telegram user id from session
        const telegramId = '<?= $telegramID ?>';

        // Send AJAX request to check if data exists in database
        $.ajax({
            url: 'check_data.php',
            type: 'POST',
            data: { animeId: animeId, telegramId: telegramId },
            success: function(response) {
                if (response === 'exists') {
                    // Change bell icon from "silent" to "ringing"
                    $bell.removeClass('fa-bell-slash').addClass('fa-bell');
                } else {
                    // Change bell icon from "ringing" to "silent"
                    $bell.removeClass('fa-bell').addClass('fa-bell-slash');
                }
            }
        });
    });

    // Add click event listener to bell icon
    $bells.on('click', function() {
        // Get current bell icon element
        const $bell = $(this);

        // Get anime id from data attribute
        const animeId = $bell.data('anime-id');

        // Get Telegram user id from session
        const telegramId = '<?= $telegramID ?>';

        // Check if bell icon is in "silent" state
        if ($bell.hasClass('fa-bell-slash')) {
            // Change bell icon from "silent" to "ringing"
            $bell.removeClass('fa-bell-slash').addClass('fa-bell');

            // Increment click count
            clickCount++;

            // Send AJAX request to insert data into database
            $.ajax({
                url: 'insert_data.php',
                type: 'POST',
                data: { id: clickCount, recipient: telegramId, item: animeId },
                success: function(response) {
                    console.log(response);
                    alert('Data berhasil disimpan');
                }
            });
        } else {
            // Change bell icon from "ringing" to "silent"
            $bell.removeClass('fa-bell').addClass('fa-bell-slash');

            // Send AJAX request to delete data from database
            $.ajax({
                url: 'delete_data.php',
                type: 'POST',
                data: { id: clickCount, recipient: telegramId, item: animeId },
                success: function(response) {
                    console.log(response);
                    alert('Data berhasil dihapus');
                }
            });
        }
    });
});
</script>
<script>
// Kode JavaScript untuk menambahkan fitur paginasi tanpa memuat ulang halaman

let currentPage = 1;
const itemsPerPage = 4;
const items = document.querySelectorAll('.recommendation-item');
const totalPages = Math.ceil(items.length / itemsPerPage);

function showPage(page) {
  // Sembunyikan semua item
  items.forEach(item => item.style.display = 'none');
  
  // Tampilkan hanya item yang sesuai dengan halaman yang dipilih
  const start = (page - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  for (let i = start; i < end; i++) {
    if (items[i]) {
      items[i].style.display = 'block';
    }
  }
  
  // Perbarui nomor halaman saat ini
  currentPage = page;
  
  // Perbarui tampilan jumlah halaman
  document.querySelector('.page-num').textContent = `${currentPage} / ${totalPages}`;
}

// Tampilkan halaman pertama saat memuat halaman
showPage(currentPage);

// Tambahkan event listener untuk tombol prev/next
document.querySelector('.prev-btn').addEventListener('click', (event) => {
  event.preventDefault();
  if (currentPage > 1) {
    showPage(currentPage - 1);
  }
});

document.querySelector('.next-btn').addEventListener('click', (event) => {
  event.preventDefault();
  if (currentPage < totalPages) {
    showPage(currentPage + 1);
  }
});
</script>

<style>
@media (min-width: 992px) { /* adjust the min-width value to target the desired screen size */
  .card.mb-3 {
    display: none;
  }
}

.image-container {
  position: relative;
}
.bell {
    position: absolute;
    top: 10px;
    right: 10px;
    color: yellow;
    background-color: black;
    border-radius: 5px;
    padding: 5px;
}

@media only screen and (max-width: 768px) {
    .bell {
        font-size: 12px;
    }
}

.image-container {
    position: relative;
}

.availability {
    position: absolute;
    bottom: 10px;
    right: 10px;
    background-color: black;
    color: white;
    padding: 5px;
    border-radius: 5px;
    border: 1px solid white;
    font-size: 9px;
}
@media only screen and (max-width: 768px) {
  .availability {
    font-size: 6px;
    margin-bottom: 20px;
  }
}

/* CSS untuk menyesuaikan tata letak elemen di dalam recommendation-header */
.recommendation-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.recommendation-header p {
    margin-bottom: 0;
}

/* CSS untuk mengurangi ukuran tombol paginasi */
.pagination .page-link {
    padding: .25rem .5rem;
}

/* CSS untuk menyesuaikan tata letak elemen di dalam recommendation-box */
.recommendation-box {
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 20px;
}

/* CSS untuk menyesuaikan tata letak elemen di dalam recommendation-header */
.recommendation-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.recommendation-header h2 {
    margin: 0;
}

/* CSS untuk menyesuaikan tata letak elemen di dalam recommendation-grid */
.recommendation-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    grid-gap: 10px;
}

.recommendation-item {
    text-align:center
}

.recommendation-item img {
    width:100%
}

.recommendation-item .anime-title {
   font-size:.8em
}

@media only screen and (max-width :768px) {
   .recommendation-grid{
      grid-template-columns : repeat(auto-fit,minmax(120px,1fr))
   }
   .recommendation-item .anime-title{
      font-size:.7em
   }
}

</style>
          <!-- Anda dapat menambahkan kode untuk menampilkan trailer di sini -->
        </div>
        <?php
$display_anime_id = strlen($anime_title) > 24 ? substr($anime_title, 0, 24) . '...' : $anime_title;
?>
        <?php
// mengatur variabel untuk koneksi database
$dbhost = 'localhost';
$dbuser = 'ccgnimex';
$dbpass = 'aaaaaaac';
$dbname = 'ccgnimex';

// membuat koneksi ke database
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// memeriksa koneksi
if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}

// membuat query SQL
$sql = "SELECT DISTINCT added_by FROM episodes WHERE anime = '$anime_id'";

// menjalankan query dan memeriksa hasilnya
$result = $conn->query($sql);

echo '<div class="col-12 col-md-auto mb-2">';
if (mysqli_num_rows($result) > 0) {
    // menampilkan tombol Download & Streaming
    echo '</div>';
echo '<div class="batas-downx">
<div class="dalam-downx" style="
    padding-bottom: 30px;
">
<div class="bungkus-info">
<div class="file-info" style="
    margin-bottom: 5px;
">';
echo $display_anime_id; // Echo the value of $anime_title
echo '</div>';

// membuat query SQL baru untuk memeriksa apakah id anime ada di tabel nonton
$sql2 = "SELECT anime_id FROM nonton WHERE anime_id = '$anime_id'";

// menjalankan query dan memeriksa hasilnya
$result2 = $conn->query($sql2);

if (mysqli_num_rows($result2) > 0) {
    // membuat query SQL baru untuk memilih resolusi dari tabel nonton
    $sql3 = "SELECT resolusi FROM nonton WHERE anime_id = '$anime_id'";

    // menjalankan query dan memeriksa hasilnya
    $result3 = $conn->query($sql3);

    $resolusi = 'pt'; // nilai default untuk resolusi
    if (mysqli_num_rows($result3) > 0) {
        while ($row = $result3->fetch_assoc()) {
            if ($row['resolusi'] == 'en') {
                $resolusi = 'en';
                break;
            }
        }
    }

    // menampilkan tombol Web jika id anime ada di tabel nonton
    echo '<button onclick="generateWebStream()" id="btnx-web" style="margin-left: 10px;"><i class="fa fa-cloud-download" aria-hidden="true"></i> Stream Web</button>';
    echo '<a id="downloadx-web" href="https://ccgnimex.my.id/streaming.php?id=' . $anime_id . '&episode=1&resolusi=' . $resolusi . '" class="btnx-web" target="_blank" style="display:none">
        <i class="fa fa-cloud-download" aria-hidden="true"></i> Stream Web
    </a>';
}

echo '<button onclick="generate()" id="btnx"><i class="fa fa-cloud-download" aria-hidden="true"></i> Stream Bot</button>
<a id="downloadx" href="https://t.me/ccgnimeX_bot?start=anime_' . $anime_id . '" style="display:none"><i class="fa fa-cloud-download" aria-hidden="true"></i> Reload Again</a>
</div>
<div class="file-deskripsi">
<span class="uploader"><i class="fa fa-user-circle" aria-hidden="true"></i> ';
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo $row['added_by'] . ', ';
    }
    echo '</span>';
} else {
    echo 'Tidak ada hasil</span>';
}
echo '
</div>
</div>
<div class="catatan-downx">
Jika tidak dapat menuju ke telegram secara otomatis, silakan klik lagi. Dan jika terdapat file/link rusak, harap laporkan melalui tombol report.
<div id="spoiler" style="display: block; padding-top: 10px;">
  <div class="tags mb-3">';
    foreach ($tags as $tag) {
      echo '<span class="badge bg-secondary">' . $tag['name'] . '</span>';
    }
echo '</div>';

// Set up the database connection information
$host = 'localhost';
$dbname = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';
$charset = 'utf8mb4';

// Set up the DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

// Set up options for the PDO connection
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

// Connect to the database using PDO
try {
    $db = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Query the database for the download links
$query = "SELECT `360p`, `480p`, `720p`, `1080p` FROM batch WHERE anime_id = :anime_id";
$stmt = $db->prepare($query);
$stmt->execute(['anime_id' => $anime_id]);
$row = $stmt->fetch();

// Check if the query was successful
if ($row) {
    // Display the download table
    echo '<div class="container">';
    echo ' <h4>Batch Tersedia</h4>';
    echo ' <table class="table">';
    echo ' <thead>';
    echo ' <tr>';
    echo ' <th>Resolution</th>';
    echo ' <th>Link</th>';
    echo ' </tr>';
    echo ' </thead>';
    echo ' <tbody>';

if (!empty($row['720p'])) {
    echo ' <tr>';
    echo ' <td>720P</td>';
    $download_links = explode("\n", $row['720p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['480p'])) {
    echo ' <tr>';
    echo ' <td>480P</td>';
    $download_links = explode("\n", $row['480p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['360p'])) {
    echo ' <tr>';
    echo ' <td>360P</td>';
    $download_links = explode("\n", $row['360p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['1080p'])) {
    echo ' <tr>';
    echo ' <td>1080P</td>';
    // Tambahkan kelas download-link dan simpan tautan unduhan sebagai atribut data
    $download_links = '';
    $links = explode("\n", $row['1080p']);
    $num_links = count($links);
    for ($i = 0; $i < $num_links; $i++) {
        $download_links .= 'Part ' . ($i+1) . ' <a href="#" class="download-link" data-download-link="' . trim($links[$i]) . '">Download</a>';
        if ($i < $num_links - 1) {
            $download_links .= ' | ';
        }
    }
    echo ' <td>' . $download_links . '</td>';
    echo ' </tr>';
}
echo ' </tbody>';
echo ' </table>';
    echo '</div>';
}
echo '

</div>
</div>
</div>';
}else {
    // menampilkan tombol Request
    echo '<div class="batas-downx">
<div class="dalam-downx" style="
    margin-bottom: 0px;
    padding-bottom: 30px;
">
<div class="bungkus-info">
<div class="file-info">';
echo $display_anime_id;
// Echo the value of $anime_title
echo '</div>
<a href="https://t.me/ccgnimeX_bot?start=menu_' . $anime_id . '" id="btnx" style="margin-right: 10px;"><i class="fa fa-cloud-download" aria-hidden="true"></i> Request</a>';

// membuat query SQL baru untuk memeriksa apakah id anime ada di tabel nonton
$sql2 = "SELECT anime_id FROM nonton WHERE anime_id = '$anime_id'";

// menjalankan query dan memeriksa hasilnya
$result2 = $conn->query($sql2);

if (mysqli_num_rows($result2) > 0) {
    // membuat query SQL baru untuk memilih resolusi dari tabel nonton
    $sql3 = "SELECT resolusi FROM nonton WHERE anime_id = '$anime_id'";

    // menjalankan query dan memeriksa hasilnya
    $result3 = $conn->query($sql3);

    $resolusi = 'pt'; // nilai default untuk resolusi
    if (mysqli_num_rows($result3) > 0) {
        while ($row = $result3->fetch_assoc()) {
            if ($row['resolusi'] == 'en') {
                $resolusi = 'en';
                break;
            }
        }
    }

    // menampilkan tombol Web jika id anime ada di tabel nonton
    echo '<button onclick="generateWebStream()" id="btnx-web" style="margin-left: 10px; margin-right: 10px;"><i class="fa fa-cloud-download" aria-hidden="true"></i> Stream Web</button>';
    echo '<a id="downloadx-web" href="https://ccgnimex.my.id/streaming.php?id=' . $anime_id . '&episode=1&resolusi=' . $resolusi . '" class="btnx-web" target="_blank" style="display:none">
        <i class="fa fa-cloud-download" aria-hidden="true"></i> Stream Web
    </a>';
}

echo '</div>
<div class="file-deskripsi">
<span class="uploader"><i class="fa fa-user-circle" aria-hidden="true"></i> ';
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo $row['added_by'] . ', ';
    }
    echo '</span> <span class="file-size">';
} else {
    echo 'Tidak Ada</span>';
}
echo '
</div>

</div>
<div class="catatan-downx">
Jika tidak dapat menuju ke telegram secara otomatis, silakan klik lagi. Dan jika terdapat file/link rusak, harap laporkan melalui tombol report.
<div id="spoiler" style="display: block; padding-top: 10px;">
  <div class="tags mb-3">';
    foreach ($tags as $tag) {
      echo '<span class="badge bg-secondary">' . $tag['name'] . '</span>';
    }
echo '</div>';

// Set up the database connection information
$host = 'localhost';
$dbname = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';
$charset = 'utf8mb4';

// Set up the DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

// Set up options for the PDO connection
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

// Connect to the database using PDO
try {
    $db = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Query the database for the download links
$query = "SELECT `360p`, `480p`, `720p`, `1080p` FROM batch WHERE anime_id = :anime_id";
$stmt = $db->prepare($query);
$stmt->execute(['anime_id' => $anime_id]);
$row = $stmt->fetch();

// Check if the query was successful
if ($row) {
    // Display the download table
    echo '<div class="container">';
    echo ' <h4>Batch Tersedia</h4>';
    echo ' <table class="table">';
    echo ' <thead>';
    echo ' <tr>';
    echo ' <th>Resolution</th>';
    echo ' <th>Link</th>';
    echo ' </tr>';
    echo ' </thead>';
    echo ' <tbody>';

if (!empty($row['720p'])) {
    echo ' <tr>';
    echo ' <td>720P</td>';
    $download_links = explode("\n", $row['720p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['480p'])) {
    echo ' <tr>';
    echo ' <td>480P</td>';
    $download_links = explode("\n", $row['480p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['360p'])) {
    echo ' <tr>';
    echo ' <td>360P</td>';
    $download_links = explode("\n", $row['360p']);
    echo ' <td>';
    for ($i = 0; $i < count($download_links); $i++) {
        echo '<a href="#" class="download-link" data-download-link="' . $download_links[$i] . '">Download</a> ';
    }
    echo ' </td>';
    echo ' </tr>';
}

if (!empty($row['1080p'])) {
    echo ' <tr>';
    echo ' <td>1080P</td>';
    // Tambahkan kelas download-link dan simpan tautan unduhan sebagai atribut data
    $download_links = '';
    $links = explode("\n", $row['1080p']);
    $num_links = count($links);
    for ($i = 0; $i < $num_links; $i++) {
        $download_links .= 'Part ' . ($i+1) . ' <a href="#" class="download-link" data-download-link="' . trim($links[$i]) . '">Download</a>';
        if ($i < $num_links - 1) {
            $download_links .= ' | ';
        }
    }
    echo ' <td>' . $download_links . '</td>';
    echo ' </tr>';
}
echo ' </tbody>';
echo ' </table>';
    echo '</div>';
}
echo '</div>';    
echo '

</div>
</div>
</div>';
}
$conn->close();
?>

<!-- Tambahkan elemen modal untuk menampilkan iklan -->
<div class="modal fade" id="adModal" tabindex="-1" role="dialog" aria-labelledby="adModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <!-- Tambahkan elemen video untuk menampilkan iklan -->
        <video id="adVideo" class="video-js vjs-default-skin vjs-big-play-centered" controls preload="auto" data-setup='{}'>
          <!-- Ganti dengan URL video iklan Anda -->
          <source src="https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4" type="video/mp4">
          Your browser does not support the video tag.
        </video>
        <!-- Tambahkan tombol untuk melewati iklan -->
        <button id="skipButton" class="btn btn-primary btn-block mt-3" disabled>Skip Ad in 10s</button>
      </div>
    </div>
  </div>
</div>

<!-- Tambahkan file CSS dan JavaScript Video.js -->
<link href="https://vjs.zencdn.net/7.17.0/video-js.css" rel="stylesheet">
<script src="https://vjs.zencdn.net/7.17.0/video.min.js"></script>

<script>
// Dapatkan elemen modal, video, dan tombol skip
const adModal = document.getElementById('adModal');
const adVideo = document.getElementById('adVideo');
const skipButton = document.getElementById('skipButton');

// Inisialisasi pemutar Video.js
const player = videojs(adVideo);

// Variabel untuk menyimpan timer
let timer;

// Fungsi untuk mengatur ulang timer
const resetTimer = () => {
  // Hentikan timer sebelumnya (jika ada)
  if (timer) {
    clearInterval(timer);
  }
  // Atur ulang teks dan status tombol skip
  skipButton.textContent = 'Skip Ad in 10s';
  skipButton.disabled = true;
  // Atur timer baru untuk mengaktifkan tombol skip setelah 10 detik
  let timeLeft = 10;
  timer = setInterval(() => {
    timeLeft--;
    skipButton.textContent = `Skip Ad in ${timeLeft}s`;
    if (timeLeft === 0) {
      clearInterval(timer);
      skipButton.disabled = false;
      skipButton.textContent = 'Skip Ad';
    }
  }, 1000);
};

// Tambahkan event listener untuk tautan unduhan
document.querySelectorAll('.download-link').forEach(link => {
  link.addEventListener('click', event => {
    // Cegah perilaku default tautan
    event.preventDefault();
    // Simpan tautan unduhan asli
    const downloadLink = link.getAttribute('data-download-link');
    // Tampilkan modal iklan
    $(adModal).modal('show');
    // Atur ulang timer
    resetTimer();
    // Tambahkan event listener untuk tombol skip
    skipButton.addEventListener('click', () => {
      // Hentikan video dan tutup modal
      player.pause();
      $(adModal).modal('hide');
      // Arahkan pengguna ke tautan unduhan asli
      window.location.href = downloadLink;
    });
  });
});

// Tambahkan event listener untuk modal ketika ditutup
$(adModal).on('hidden.bs.modal', () => {
  // Hentikan video dan atur ulang timer
  player.pause();
  resetTimer();
});
</script>

<style>@import url(https://fonts.googleapis.com/css?family=Roboto:400,400i,700,700i);
a,a:link,a:visited {color:#333;text-decoration:none;transition:all .3s}
a:hover,a:hover:visited {color:#1e7ce5}
*,*:before,*:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}


/* Download Counter Box */
#btnx{cursor:pointer;padding:10px 20px;border:0;border-radius:3px;background:#fff;color:#5480fb;float:right;text-transform:capitalize;font-weight:500;transition:all 0.5s}#btnx:hover,#downloadx:hover{background:#1f51db;color:#fff;outline:none}.batas-downx{display:block;margin:0 auto;border-radius:4px}.dalam-downx{background:#5480fb;color:#fff;padding:20px;display:block;border-top-right-radius:3px;border-top-left-radius:3px}.file-info{color:#fff;display:inline-block;font-size:1.2em;line-height:38px;text-align:left}.catatan-downx{padding:20px;background:#f7f7f7;border-bottom-right-radius:3px;border-bottom-left-radius:3px;color:#555;font-size:14px}#downloadx{float:right}#downloadx{padding:10px 20px;border-radius:3px;background:#fff;color:#5480fb;float:right;text-align:center;font-size:14px;text-transform:capitalize}.bungkus-info span{display:inline-block;line-height:38px;float:right}.file-deskripsi{display:block}.file-deskripsi span{margin-right:3px}
@media screen and (max-width:640px){.batas-downx{float:none;width:100%}}
@media screen and (max-width:320px){.file-info{display:block;text-align:center}#btnx, #downloadx{width:100%;margin-bottom:10px}.bungkus-info span{float:none;width:100%;text-align:center}.file-deskripsi{text-align:center}}</style>
<style>@import url(https://fonts.googleapis.com/css?family=Roboto:400,400i,700,700i);
a,a:link,a:visited {color:#333;text-decoration:none;transition:all .3s}
a:hover,a:hover:visited {color:#1e7ce5}
*,*:before,*:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}


/* Download Counter Box */
#btnx-web{cursor:pointer;padding:10px 20px;border:0;border-radius:3px;background:#fff;color:#5480fb;float:right;text-transform:capitalize;font-weight:500;transition:all 0.5s}#btnx-web:hover,#downloadx-web:hover{background:#1f51db;color:#fff;outline:none}.batas-downx{display:block;margin:0 auto;border-radius:4px}.dalam-downx{background:#5480fb;color:#fff;padding:20px;display:block;border-top-right-radius:3px;border-top-left-radius:3px}.file-info{color:#fff;display:inline-block;font-size:1.2em;line-height:38px;text-align:left}.catatan-downx{padding:20px;background:#f7f7f7;border-bottom-right-radius:3px;border-bottom-left-radius:3px;color:#555;font-size:14px}#downloadx-web{float:right}#downloadx-web{padding:10px 20px;border-radius:3px;background:#fff;color:#5480fb;float:right;text-align:center;font-size:14px;text-transform:capitalize}.bungkus-info span{display:inline-block;line-height:38px;float:right}.file-deskripsi{display:block}.file-deskripsi span{margin-right:3px}
@media screen and (max-width:640px){.batas-downx{float:none;width:100%}}
@media screen and (max-width:320px){.file-info{display:block;text-align:center}#btnx, #downloadx-web{width:100%;margin-bottom:10px}.bungkus-info span{float:none;width:100%;text-align:center}.file-deskripsi{text-align:center}}</style>
<style>@media screen and (max-width: 640px) {
    #btnx,
    #btnx-web {
        display: block;
        width: 100%;
        margin-bottom: 10px;
    }
    #btnx,
#btnx-web {
    float: right;
    clear: both;
}
#btnx,
#btnx-web,
#downloadx,
#downloadx-web {
    min-width: 150px;
}
}
#btnx,
#btnx-web {
    display: flex;
    justify-content: center;
    align-items: center;
}</style>
<script>
    function generate() {
        var e,
            n = document.getElementById("downloadx"),
            t = document.getElementById("btnx"),
            a = document.getElementById("downloadx").href,
            l = 4,
            d = document.createElement("span");
        n.parentNode.replaceChild(d, n),
            (e = setInterval(function () {
                --l < 0
                    ? (d.parentNode.replaceChild(n, d),
                      clearInterval(e),
                      window.open(a, '_blank'),
                      (n.style.display = "inline"))
                    : ((d.innerHTML =
                          "<i class='fa fa-clock-o' aria-hidden='true'/> Sebentar lagi akan mengarah ke bot dalam " +
                          l.toString() +
                          " Detik...."),
                      (t.style.display = "none"));
            }, 1e3));
    }
</script>
<script>
    function generateWebStream() {
    var e,
        n = document.getElementById("downloadx-web"),
        t = document.getElementById("btnx-web"),
        a = document.getElementById("downloadx-web").href,
        l = 4,
        d = document.createElement("span");
    n.parentNode.replaceChild(d, n),
        (e = setInterval(function () {
            --l < 0
                ? (d.parentNode.replaceChild(n, d),
                  clearInterval(e),
                  window.open(a, '_blank'),
                  (n.style.display = "inline"))
                : ((d.innerHTML =
                      "<i class='fa fa-clock-o' aria-hidden='true'/> Sebentar lagi akan mengarah ke streaming dalam " +
                      l.toString() +
                      " Detik...."),
                  (t.style.display = "none"));
        }, 1e3));
}
</script>
       <!-- Remove the button element -->
<!-- <button class="btn btn-primary" onclick="toggleSpoiler()">Spoiler Tags!</button> -->

<!-- Change the display style of the spoiler div to block -->

<!-- Remove the script to toggle the visibility of the spoiler -->
<!-- <script>
  function toggleSpoiler() {
    var spoiler = document.getElementById('spoiler');
    if (spoiler.style.display === 'none') {
      spoiler.style.display = 'block';
    } else {
      spoiler.style.display = 'none';
    }
  }
</script> -->
    <button type="button" class="btn btn-primary w-100 mb-3" id="toggle-comments"style="margin-top: 5px;">Show Comments</button>
<div id="disqus_thread">
<script async src="https://comments.app/js/widget.js?3" data-comments-app-website="Aip8L2b2" data-limit="5"></script>
</div>

<script>
document.getElementById('disqus_thread').style.display = 'none';

var commentsVisible = false; // flag untuk menandai apakah komentar sedang tampil atau tidak
var toggleButton = document.getElementById('toggle-comments'); // mengambil tombol toggle dari DOM

// function untuk menampilkan atau menyembunyikan komentar
function toggleComments() {
  var commentsDiv = document.getElementById('disqus_thread');
  if (commentsVisible) {
    commentsDiv.style.display = 'none';
    toggleButton.innerHTML = 'Show Comments';
  } else {
    commentsDiv.style.display = 'block';
    toggleButton.innerHTML = 'Hide Comments';
  }
  commentsVisible = !commentsVisible; // toggle flag
}

// event listener untuk memanggil function toggleComments() ketika tombol di klik
toggleButton.addEventListener('click', toggleComments);
</script>
  </div>
</div>
</div>
            </div>
            <div class="position-fixed bottom-0 start-0 p-3" style="z-index: 5">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#telegramModal">
        <i class="fas fa-comment"></i>
    </button>
</div>

<div class="modal fade" id="telegramModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body"></div>
        </div>
    </div>
</div>

<script>
    var telegramModal = document.getElementById('telegramModal')
    var modalBody = telegramModal.querySelector('.modal-body')

    telegramModal.addEventListener('hidden.bs.modal', function (event) {
        modalBody.innerHTML = ''
    })

    telegramModal.addEventListener('show.bs.modal', function (event) {
        var script = document.createElement('script')
        script.async = true
        script.src = 'https://telegram.org/js/telegram-widget.js?21'
        script.setAttribute('data-telegram-discussion', 'otakuindonew/1')
        script.setAttribute('data-comments-limit', '3')
        script.setAttribute('data-height', '400')
        script.setAttribute('data-colorful', '1')
        modalBody.appendChild(script)
    })
</script>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Brand 2023</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script>
$(function() {
    $('.popup-youtube, .popup-vimeo').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
});
</script>
<!-- Tambahkan library lazysizes ke halaman Anda -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.32/moment-timezone-with-data-10-year-range.min.js"></script>

<script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', 'update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', 'retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>


<script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>

</html>