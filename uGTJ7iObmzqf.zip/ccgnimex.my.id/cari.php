<style>

/* Style untuk ikon notifikasi */
.notification-icon {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 10px;
  color: white;
}

/* Style untuk ikon notifikasi ketika diklik */
.notification-icon.clicked {
  color: red;
}

.image-container {
  position: relative;
}

.availability {
  position: absolute;
  bottom: 10px;
  right: 10px;
  background-color: black;
  color: white;
  padding: 5px;
  border-radius: 5px;
  border: 1px solid white; /* tambahkan properti border */
  font-size: 9px; /* tambahkan properti font-size */
}

@media only screen and (max-width: 768px) {
  .availability {
    font-size: 7px;
  }
}


.anime-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  grid-gap: 10px;
}

@media screen and (max-width: 800px) {
  .anime-grid {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  }
}

@media screen and (max-width: 600px) {
  .anime-grid {
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  }
}

.anime-item {
  position: relative;
}

.anime-item img {
  width: 100%;
}

.popup-vimeo {
    position:absolute;
    top:5px;
    right:5px;
    color:white;
    background-color: rgba(0, 0, 0, 0.7);
    padding:5px;
    border-radius:5px;
}



/* Style untuk tampilan mobile */
@media only screen and (max-width: 768px) {
  /* Style untuk grid anime */
  .anime-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    grid-gap: 5px;
  }

  /* Style untuk judul anime */
  .anime-title {
    font-size: 14px;
  }

  /* Style untuk genre anime */
  .anime-genres {
    font-size: 10px;
  }

}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
<script>
$(function() {
    $('.popup-youtube, .popup-vimeo').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
});
</script>

<?php
// Check if a search query was submitted
// Check if a search query was submitted
if (isset($_GET['search'])) {
    // Set up your AniList API query
    $query = '
    query ($search: String, $page: Int) {
      Page(page: $page, perPage: 8) {
        pageInfo {
          total
          currentPage
          lastPage
          hasNextPage
        }
        media(search: $search, type: ANIME) {
          id
          title {
            romaji
            english
            native
          }
          coverImage {
            large
          }
          genres
          trailer {
            id
          }
        }
      }
    }
    ';

    // Set up your query variables
    $variables = [
        'search' => $_GET['search'],
        'page' => isset($_GET['page']) ? (int)$_GET['page'] : 1,
    ];

    // Set up your API endpoint and headers
    $apiUrl = 'https://graphql.anilist.co';
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
    ];

    // Set up your cURL request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query, 'variables' => $variables]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute your cURL request and retrieve the response
    $response = curl_exec($ch);
    curl_close($ch);

    // Decode the JSON response
    $data = json_decode($response, true);

// Menampilkan data dalam tampilan grid
echo '<div class="anime-grid">';
foreach ($data['data']['Page']['media'] as $anime) {
    echo '<div class="anime-item">';
    echo '<a href="https://ccgnimex.my.id/anime_detail.php?id=' . $anime['id'] . '">';
    echo '<div class="image-container">';
    echo '<img class="lazyload" data-src="https://img.anili.st/media/' . $anime['id'] . '" alt="' . $anime['title']['romaji'] . '">';
    
    // Koneksi ke database MySQL
    $db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

    // Check if anime ID exists in the episodes table
    $query_episodes = "SELECT * FROM episodes WHERE anime = '" . $anime['id'] . "'";
    $query_result_episodes = mysqli_query($db, $query_episodes);
    $has_episodes = mysqli_num_rows($query_result_episodes) > 0;

    // Check if anime ID exists in the nonton table
    $query_nonton = "SELECT * FROM nonton WHERE anime_id = '" . $anime['id'] . "'";
    $query_result_nonton = mysqli_query($db, $query_nonton);
    $has_nonton = mysqli_num_rows($query_result_nonton) > 0;

    // Display appropriate checkmark(s)
    if ($has_episodes && $has_nonton) {
        echo '<span class="availability"><i class="fas fa-check"></i> Bot | Web</span>';
    } elseif ($has_episodes) {
        echo '<span class="availability"><i class="fas fa-check"></i> Bot</span>';
    } elseif ($has_nonton) {
        echo '<span class="availability"><i class="fas fa-check"></i> Web</span>';
    }

    echo '</div>';

    // Tampilkan link video trailer jika tersedia, atau tidak menampilkan apa-apa jika tidak tersedia
    if (isset($anime['trailer']['id'])) {
        echo '<a class="popup-vimeo" href="https://www.youtube.com/watch?v=' . $anime['trailer']['id'] . '" target="_blank">
            <span class="sr-only">Trailer</span>
            <i class="fas fa-film"></i>
        </a>';
    }

    echo '</a>';
    echo '</div>';
}
echo '</div>';
echo '<br>';



    // Display "Previous" and "Next" buttons if there are multiple pages of results available
if ($data['data']['Page']['pageInfo']['lastPage'] > 1) {
    echo '<nav aria-label="Page navigation">';
    echo '<ul class="pagination justify-content-center">';
    if ($variables['page'] > 1) {
        echo '<li class="page-item"><a class="page-link" href="?search=' . urlencode($_GET['search']) . '&page=' . ($variables['page'] - 1) . '">Previous</a></li>';
    } else {
        echo '<li class="page-item disabled"><span class="page-link">Previous</span></li>';
    }
    if ($data['data']['Page']['pageInfo']['hasNextPage']) {
        echo '<li class="page-item"><a class="page-link" href="?search=' . urlencode($_GET['search']) . '&page=' . ($variables['page'] + 1) . '">Next</a></li>';
    } else {
        echo '<li class="page-item disabled"><span class="page-link">Next</span></li>';
    }
    echo '</ul>';
    echo '</nav>';
}
}
?>
<!-- Tambahkan library lazysizes ke halaman Anda -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js"></script>