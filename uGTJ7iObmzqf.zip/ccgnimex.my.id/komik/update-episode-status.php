<?php
// Menggunakan parameter episodeId dan isChecked yang dikirim dari AJAX
$episodeId = $_POST['episodeId'];
$isChecked = $_POST['isChecked'];

// Melakukan koneksi ke database
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "database_name";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Melakukan operasi UPDATE pada tabel episode_saved berdasarkan episodeId
$sql = "UPDATE episode_saved SET is_saved = '$isChecked' WHERE episode_id = '$episodeId'";

if ($conn->query($sql) === TRUE) {
    echo "Episode status updated successfully";
} else {
    echo "Error updating episode status: " . $conn->error;
}

// Menutup koneksi
$conn->close();
?>