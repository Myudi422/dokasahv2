<?php
// Start the session
session_start();



// Import database connection and class
require('../db-config.php');

include '../jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>💞 ccgnimex | Mari Mengvvibu</title>
    <meta name="description" content="ccgnimex adalah sebuah website yang menyediakan layanan download dan streaming anime. Di website ini, kalian bisa menemukan berbagai macam jenis anime, mulai dari ongoing, completed, batch, hingga anime yang bisa ditonton melalui bot Telegram. Selain itu, ccgnimex juga menyediakan berbagai fitur dan tampilan yang membuat penggunaan website ini semakin mudah dan menyenangkan. Dengan menggunakan layanan dari ccgnimex, Anda bisa menemukan anime favorit Anda dan menontonnya dengan cara yang lebih mudah dan praktis.">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="../assets/fonts/fontawesome-all.min.css">
    <style>@media (max-width: 576px) {
  .row {
    display: none;
  }
}</style>
<meta name="google-site-verification" content="A1HYpSm2bOSTfTIoEl8SWJDrh9GWw_22ad73OvrsBWI" />
<style>
.popup-cardx {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.popup-contentx {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 80%;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  position: relative;
}

.closex {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 20px;
  font-weight: bold;
  color: #333;
  cursor: pointer;
}
</style>

<script>
function closePopup() {
  var popup = document.querySelector('.popup-cardx');
  popup.style.display = 'none';
}
</script>

<?php
// When the user is not logged in, show popup card with login button
if (!isset($_SESSION['logged-in'])) {
    echo '<div class="popup-cardx">';
    echo '<div class="popup-contentx">';
    echo '<span class="closex" onclick="closePopup()">&times;</span>';
    echo '<h3>Akses Diperlukan!</h3>';
    echo '<p><center>Silahkan login menggunakan akun telegram kalian, agar fitur dari website bisa digunakan sepenuhnya.</center></p>';
    echo '<a class="btn btn-primary" href="../login.php">Login</a>';
    echo '</div>';
    echo '</div>';
}
?>

<link rel="apple-touch-icon" sizes="57x57" href="../icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="../icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../icon1/favicon-16x16.png">
<link rel="manifest" href="../icon1/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../icon1/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">



</head>

<body id="page-top" class>
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="../icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="../"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link active" href="#"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="../kategori.php"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">3+</span><i class="fas fa-bell fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-primary icon-circle"><i class="fas fa-file-alt text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 12, 2019</span>
                                                <p>A new monthly report is ready to download!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-success icon-circle"><i class="fas fa-donate text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 7, 2019</span>
                                                <p>$290.29 has been deposited into your account!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-warning icon-circle"><i class="fas fa-exclamation-triangle text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 2, 2019</span>
                                                <p>Spending Alert: We've noticed unusually high spending for your account.</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid">
                    <?php
// Mengambil telegram_id dari sesi
$telegramID = $_SESSION['telegram_id'];

// Menghubungkan ke database
$host = 'localhost';
$db   = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Mengambil link episode berdasarkan ID Telegram pengguna, diurutkan berdasarkan urutan terbalik
$query = $pdo->prepare("SELECT episode_url FROM episode_saved WHERE telegram_id = :telegramID ORDER BY id DESC");
$query->execute(['telegramID' => $telegramID]);
$links = $query->fetchAll(PDO::FETCH_COLUMN);

// Membuat array untuk menyimpan link episode terbaru dengan judul yang sama
$filteredLinks = [];

// Memfilter dan menyimpan link episode terbaru dengan judul yang sama
foreach ($links as $link) {
    $url = $link;

    $titleStartPos = strpos($url, 'https://mangakyo.org/') + strlen('https://mangakyo.org/');
    $titleEndPos = strpos($url, '-chapter-');
    $title = substr($url, $titleStartPos, $titleEndPos - $titleStartPos);

    $chapterStartPos = $titleEndPos + strlen('-chapter-');
    $chapterEndPos = strpos($url, '/', $chapterStartPos);
    $chapter = substr($url, $chapterStartPos, $chapterEndPos - $chapterStartPos);

    $filteredLink = 'https://ccgnimex.my.id/komik/episode.php?url=' . urlencode($url);

    if (!isset($filteredLinks[$title]) || $chapter > $filteredLinks[$title]['chapter']) {
        $filteredLinks[$title] = [
            'chapter' => $chapter,
            'link' => $filteredLink
        ];
    }
}

?>

<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Riwayat Baca</strong>
    </div>
  </div>

  <div id="riwayatContainer" class="card-body" style="max-height: 300px; overflow-y: auto;">
    <ul class="list-group">
      <?php
      foreach ($filteredLinks as $title => $data):
          $formattedTitle = str_replace('-', ' ', $title);
          $trimmedTitle = strlen($formattedTitle) > 50 ? substr($formattedTitle, 0, 50) . '...' : $formattedTitle;
          $detailPageUrl = 'https://ccgnimex.my.id/komik/komik-detail.php?url=%2Fkomik%2F' . urlencode($title);
      ?>
          <li class="list-group-item">
            <div class="d-flex justify-content-between align-items-center">
              <a href="<?php echo $data['link']; ?>"><?php echo $trimmedTitle; ?></a>
              <a href="<?php echo $detailPageUrl; ?>" class="btn btn-primary" target="_blank">
                <i class="fas fa-info-circle"></i>
              </a>
            </div>
          </li>
      <?php
      endforeach;
      ?>
    </ul>
  </div>
</div>




<style>

  .form-group label {
    font-weight: bold;
  }

  .form-control {
    border-radius: 5px;
  }

  .btn {
    border-radius: 5px;
  }

  .genre-grid {
    display: none;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    grid-gap: 10px;
    margin-top: 10px;
  }

  @media (max-width: 576px) {
    .genre-grid {
      grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    }
  }
</style>

<div class="card">
  <div class="card-body">
    <div class="form-group">
      <label for="statusDropdown">Status</label>
      <select class="form-select" id="statusDropdown">
        <option value="">Semua</option>
        <option value="Ongoing">Ongoing</option>
        <option value="Completed">Completed</option>
        <option value="Hiatus">Hiatus</option>
      </select>
    </div>
    <div class="form-group">
      <label for="orderDropdown">Order by</label>
      <select class="form-select" id="orderDropdown">
        <option value="update">Update</option>
        <option value="popular">Popular</option>
        <option value="">Default</option>
        <option value="title">Title</option>
        <option value="titlereverse">Title Reverse</option>
        <option value="latest">Latest</option>
      </select>
    </div>
    <div class="form-group">
      <label>Genre:</label>
      <button class="btn btn-link" id="showGenreButton" onclick="toggleGenre()">Show Genre</button>
      <div class="genre-grid" id="genreCheckboxes">
        <!-- Daftar genre-checkboxes -->
      </div>
    </div>
    <button class="btn btn-primary w-100" onclick="submitStatus()">Submit</button>
  </div>
</div>

<script>
  function toggleGenre() {
    var genreCheckboxes = document.getElementById("genreCheckboxes");
    var showGenreButton = document.getElementById("showGenreButton");

    if (genreCheckboxes.style.display === "none") {
      genreCheckboxes.style.display = "grid";
      showGenreButton.textContent = "Hide Genre";
    } else {
      genreCheckboxes.style.display = "none";
      showGenreButton.textContent = "Show Genre";
    }
  }
</script>
<script>
  // Daftar genre
  var genres = [
  { id: "4-koma", name: "4-Koma", value: "3233" },
  { id: "action", name: "Action", value: "2" },
  { id: "romance", name: "Romance", value: "5" },
  { id: "adult", name: "Adult", value: "405" },
  { id: "adaptation", name: "Adaptation", value: "2796" },
  { id: "adventure", name: "Adventure", value: "3" },
  { id: "bully", name: "Bully", value: "2669" },
  { id: "comedy", name: "Comedy", value: "4" },
  { id: "cooking", name: "Cooking", value: "2766" },
  { id: "crime", name: "Crime", value: "2270" },
  { id: "dark-fantasy", name: "Dark Fantasy", value: "2190" },
  { id: "delinquent", name: "Delinquent", value: "2670" },
  { id: "demon", name: "Demon", value: "2549" },
  { id: "demons", name: "Demons", value: "38" },
  { id: "doujinshi", name: "Doujinshi", value: "631" },
  { id: "drama", name: "Drama", value: "14" },
  { id: "ecchi", name: "Ecchi", value: "21" },
  { id: "fantasy", name: "Fantasy", value: "5" },
  { id: "game", name: "Game", value: "203" },
  { id: "gender-bender", name: "Gender Bender", value: "165" },
  { id: "genderswap", name: "Genderswap", value: "2797" },
  { id: "girls-love", name: "Girls Love", value: "2447" },
  { id: "gore", name: "Gore", value: "2061" },
  { id: "gyaru", name: "Gyaru", value: "399" },
  { id: "harem", name: "Harem", value: "90" },
  { id: "historical", name: "Historical", value: "127" },
  { id: "horor", name: "Horor", value: "15" },
  { id: "incest", name: "Incest", value: "2079" },
  { id: "isekai", name: "Isekai", value: "393" },
  { id: "josei", name: "Josei", value: "2036" },
  { id: "magic", name: "Magic", value: "22" },
  { id: "manhwa", name: "Manhwa", value: "2244" },
  { id: "martial-art", name: "Martial Art", value: "24" },
  { id: "mature", name: "Mature", value: "148" },
  { id: "mecha", name: "Mecha", value: "128" },
  { id: "medical", name: "Medical", value: "2286" },
  { id: "military", name: "Military", value: "139" },
  { id: "mistery", name: "Mistery", value: "435" },
  { id: "murim", name: "Murim", value: "2208" },
  { id: "music", name: "Music", value: "57" },
  { id: "mystery", name: "Mystery", value: "13" },
  { id: "one-shot", name: "One-Shot", value: "2511" },
  { id: "parody", name: "Parody", value: "8" },
  { id: "police", name: "Police", value: "180" },
  { id: "project", name: "Project", value: "2373" },
  { id: "pysychological", name: "Pysychological", value: "91" },
  { id: "regression", name: "Regression", value: "2658" },
  { id: "samurai", name: "Samurai", value: "27" },
  { id: "school", name: "School", value: "23" },
  { id: "school-life", name: "School Life", value: "334" },
  { id: "sci-fi", name: "Sci-Fi", value: "9" },
  { id: "seinen", name: "Seinen", value: "56" },
  { id: "shotacon", name: "Shotacon", value: "2027" },
  { id: "shoujo-ai", name: "Shoujo AI", value: "1789" },
  { id: "shounen", name: "Shounen", value: "6" },
  { id: "shounen-ai", name: "Shounen-AI", value: "2459" },
  { id: "slice-of-life", name: "Slice Of Life", value: "118" },
  { id: "space", name: "Space", value: "129" },
  { id: "sports", name: "Sports", value: "25" },
  { id: "super-power", name: "Super Power", value: "7" },
  { id: "superhero", name: "Superhero", value: "2624" },
  { id: "system", name: "System", value: "865" },
  { id: "thriller", name: "Thriller", value: "2349" },
  { id: "time-travel", name: "Time Travel", value: "2671" },
  { id: "tragedy", name: "Tragedy", value: "169" },
  { id: "vampires", name: "Vampires", value: "2798" },
  { id: "video-games", name: "Video Games", value: "2799" },
  { id: "virtual-reality", name: "Virtual Reality", value: "2800" },
  { id: "webtoons", name: "Webtoons", value: "2491" },
  { id: "wuxia", name: "Wuxia", value: "2282" },
  { id: "yuri", name: "Yuri", value: "829" }
];

// Tambahkan genre-genre lainnya di sini



  // Membangun checkbox genre
  var genreCheckboxesContainer = document.getElementById("genreCheckboxes");
  genres.forEach(function(genre) {
    var checkboxDiv = document.createElement("div");
    checkboxDiv.classList.add("form-check");

    var checkboxInput = document.createElement("input");
    checkboxInput.classList.add("form-check-input");
    checkboxInput.setAttribute("type", "checkbox");
    checkboxInput.setAttribute("name", "genre");
    checkboxInput.setAttribute("id", genre.id);
    checkboxInput.setAttribute("value", genre.value);

    var checkboxLabel = document.createElement("label");
    checkboxLabel.classList.add("form-check-label");
    checkboxLabel.setAttribute("for", genre.id);
    checkboxLabel.textContent = genre.name;

    checkboxDiv.appendChild(checkboxInput);
    checkboxDiv.appendChild(checkboxLabel);
    genreCheckboxesContainer.appendChild(checkboxDiv);
  });
</script>


<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Komik Terbaru</strong>
    </div>
  </div>


<div id="komikContainer" class="card-body">
  <?php
  // URL target
  $baseUrl = 'https://komik-mama.com/komik/';
  $page = isset($_GET['page']) ? $_GET['page'] : 1;
  $order = isset($_GET['order']) ? $_GET['order'] : 'update';
  $status = isset($_GET['status']) ? $_GET['status'] : '';
  $genres = isset($_GET['genre']) ? $_GET['genre'] : array();

  // Membuat URL dengan parameter status dan genre
  $url = $baseUrl . '?page=' . $page . '&order=' . $order . '&status=' . $status;
  foreach ($genres as $genre) {
    $url .= '&genre%5B%5D=' . $genre;
  }

  // Membuat objek DOMDocument
  $dom = new DOMDocument();

  // Mematikan error dan warning ketika parsing HTML
  libxml_use_internal_errors(true);

  // Memuat konten HTML dari URL
  $dom->loadHTMLFile($url);

  // Mengaktifkan XPath untuk pencarian elemen
  $xpath = new DOMXPath($dom);

  // Mencari semua div dengan class 'listupd'
  $listUpdDivs = $xpath->query("//div[contains(@class, 'listupd')]");

  // Memulai output list menggunakan grid Bootstrap
  echo '<div class="card-columns">';

  // Array untuk menyimpan URL komik yang sudah diambil
  $visitedUrls = array();

  // Iterasi melalui setiap div 'listupd'
  foreach ($listUpdDivs as $listUpdDiv) {
    // Mencari semua elemen div dengan class 'bs' di dalam div 'listupd'
    $bsDivs = $xpath->query(".//div[contains(@class, 'bs')]", $listUpdDiv);

    // Iterasi melalui setiap elemen div 'bs'
    foreach ($bsDivs as $bsDiv) {
      // Mengambil URL komik dari atribut href
      $url = $xpath->evaluate("string(.//a/@href)", $bsDiv);

      // Memeriksa apakah URL komik sudah diambil sebelumnya
      if (in_array($url, $visitedUrls)) {
        continue; // Lewati jika sudah diambil sebelumnya
      }

      // Menambahkan URL komik ke array visitedUrls
      $visitedUrls[] = $url;

      // Mengambil informasi komik
      $title = $xpath->evaluate("string(.//div[contains(@class, 'tt')])", $bsDiv);
      $chapter = $xpath->evaluate("string(.//div[contains(@class, 'epxs')])", $bsDiv);
      $image = $xpath->evaluate("string(.//img/@src)", $bsDiv);

      // Mengambil informasi kategori warna jika ada
      $colorCategory = $xpath->evaluate("string(.//span[contains(@class, 'colored')])", $bsDiv);

      // Menampilkan komik dalam format card Bootstrap
      echo '
      <div class="card">
        ' . ($colorCategory ? '<div class="card-category">' . $colorCategory . '</div>' : '') . '
        <img src="' . $image . '" class="card-img-top" alt="' . $title . '" onclick="toggleTitle(event)" loading="lazy">
        <div class="card-body">
          <h5 class="card-title" title="' . $title . '" onclick="toggleTitle(event)">' . $title . '</h5>
          ' . ($chapter ? '<div class="card-chapter">' . $chapter . '</div>' : '') . '
          <a href="komik-detail.php?url=' . urlencode('/komik/' . basename($url)) . '" class="btn btn-primary">Baca Komik</a>
        </div>
      </div>';
    }
  }
// Display the previous and next buttons
echo '<div class="hpage d-flex justify-content-center mt-4">';
if ($page > 1) {
  $prevPage = $page - 1;
  echo '<a href="?page=' . $prevPage . '&order=' . $order . '&status=' . $status;
  if (!empty($genres)) {
    foreach ($genres as $genre) {
      echo '&genre[]=' . $genre;
    }
  }
  echo '" class="btn btn-primary mr-2" style="margin-right: 5px;">Sebelumnya</a>';
}
echo '<a href="?page=' . ($page + 1) . '&order=' . $order . '&status=' . $status;
if (!empty($genres)) {
  foreach ($genres as $genre) {
    echo '&genre[]=' . $genre;
  }
}
echo '" class="btn btn-primary" style="margin-left: 5px;">Selanjutnya</a>';
echo '</div>';


  // Mengakhiri output list dan grid
  echo '</div>
  </div>';
  ?>
</div>

<script>
  function toggleTitle(event) {
    var titleElement = event.target.parentNode.querySelector(".card-title");
    if (titleElement.style.whiteSpace === "normal") {
      titleElement.style.whiteSpace = "nowrap";
    } else {
      titleElement.style.whiteSpace = "normal";
    }
  }

  function updateDropdown(dropdownType, value) {
    if (dropdownType === 'status') {
      document.getElementById("statusDropdown").innerText = value;
    } else if (dropdownType === 'order') {
      document.getElementById("orderDropdown").innerText = value;
    }
  }

  function submitStatus() {
  var selectedStatus = document.getElementById("statusDropdown").value;
  var selectedOrder = document.getElementById("orderDropdown").value;
  var selectedGenres = Array.from(document.querySelectorAll('input[name="genre"]:checked')).map(function(element) {
    return element.value;
  });

  var url = window.location.href.split("?")[0]; // Get the current URL without parameters
  url += "?page=1&status=" + encodeURIComponent(selectedStatus.toLowerCase()) + "&order=" + encodeURIComponent(selectedOrder.toLowerCase()); // Add the selected status and order as parameters
  selectedGenres.forEach(function(genre) {
    url += "&genre[]=" + encodeURIComponent(genre);
  });

  window.location.href = url; // Redirect to the URL with the new status, order, and genre parameters
}


  // Update dropdowns and genres to reflect the current status, order, and genres on page load
  window.onload = function() {
    var currentStatus = '<?php echo $status; ?>';
    var currentOrder = '<?php echo $order; ?>';
    var currentGenres = <?php echo json_encode($genres); ?>;

    updateDropdown('status', currentStatus);
    updateDropdown('order', currentOrder);

    currentGenres.forEach(function(genre) {
      var genreCheckbox = document.getElementById(genre);
      if (genreCheckbox) {
        genreCheckbox.checked = true;
      }
    });
  };
</script>


<style>
        .card-columns {
            column-count: 1;
        }

        @media (min-width: 576px) {
            .card-columns {
                column-count: 2;
            }
        }

        @media (min-width: 768px) {
            .card-columns {
                column-count: 3;
            }
        }

        @media (min-width: 992px) {
            .card-columns {
                column-count: 4;
            }
        }

        @media (min-width: 1200px) {
            .card-columns {
                column-count: 5;
            }
        }

        .card {
            margin-bottom: 1rem;
            overflow: hidden;
            position: relative;
        }

        .card-img-top {
            height: 200px;
            object-fit: cover;
        }

        .card-title {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .card-text {
            font-size: 14px;
            margin-bottom: 0.5rem;
        }

        .card-footer {
            font-size: 12px;
            color: #6c757d;
            background-color: #f8f9fa;
            border-top: 1px solid #dee2e6;
        }

        .card-category {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 5px;
            font-size: 12px;
            font-weight: bold;
            color: black;
            border-radius: 5px;
        }

        .card-chapter {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 5px;
            font-size: 12px;
            font-weight: bold;
            color: black;
            border-radius: 5px;
        }
    </style>
<!-- File JavaScript Bootstrap -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>





<style>.card-body {
    max-width: 100%;
    overflow: hidden;
}
.owl-carousel {
            max-width: 100%;
            margin: 0 auto;
        }
@media (max-width: 600px) {
    .owl-carousel {
        max-width: 90%;
    }
}
        </style>
                  
            </div>
            <div class="position-fixed bottom-0 start-0 p-3" style="z-index: 5">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#telegramModal">
        <i class="fas fa-comment"></i>
    </button>
</div>

<div class="modal fade" id="telegramModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body"></div>
        </div>
    </div>
</div>

<script>
    var telegramModal = document.getElementById('telegramModal')
    var modalBody = telegramModal.querySelector('.modal-body')

    telegramModal.addEventListener('hidden.bs.modal', function (event) {
        modalBody.innerHTML = ''
    })

    telegramModal.addEventListener('show.bs.modal', function (event) {
        var script = document.createElement('script')
        script.async = true
        script.src = 'https://telegram.org/js/telegram-widget.js?21'
        script.setAttribute('data-telegram-discussion', 'otakuindonew/1')
        script.setAttribute('data-comments-limit', '3')
        script.setAttribute('data-height', '400')
        script.setAttribute('data-colorful', '1')
        modalBody.appendChild(script)
    })
</script>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © ccgnimex</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/js/chart.min.js"></script>
    <script src="../assets/js/bs-init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script>$(document).ready(function() {
    // Collapse the sidebar upon page load
    $("#sidebarToggle").trigger("click");
});</script>

<script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', '../update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', '../retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>

<script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>
