<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from POST request
    $title = $_POST["title"];
    $url = $_POST["url"];

    // Perform database deletion here

    // Echo a success response
    http_response_code(200);
    echo "Manga link deleted successfully.";
} else {
    // Send an error response
    http_response_code(400);
    echo "Bad Request";
}
?>
