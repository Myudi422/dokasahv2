    <style>
    body {
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }

    .container {
        margin-top: 50px;
        padding: 0;
    }

    .title {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
    }

    .image-list {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 20px;
        padding: 0;
    }

    .image-list img {
        max-width: 100%;
        height: auto;
        margin: 0 auto;
        display: block;
    }

    .notification {
        font-size: 18px;
        text-align: center;
        background-color: #fff;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    /* Perubahan CSS untuk tampilan mobile */
    @media (max-width: 576px) {
        .container {
            padding-left: 15px;
            padding-right: 15px;
        }
    }
</style>
<?php
// Start the session
session_start();



// Import database connection and class
require('../db-config.php');

include '../jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};



?>
<?php
// URL target
$url = $_GET['url'];

// Membuat objek DOMDocument
$dom = new DOMDocument();

// Mematikan error dan warning ketika parsing HTML
libxml_use_internal_errors(true);

// Memuat konten HTML dari URL
$dom->loadHTMLFile($url);

// Mengaktifkan XPath untuk pencarian elemen
$xpath = new DOMXPath($dom);

// Judul episode
$title = $xpath->evaluate("string(//div[contains(@class, 'headpost')]/h1[contains(@class, 'entry-title')])");

// Cari script dengan kode JavaScript
$scripts = $xpath->evaluate("//script[contains(text(), 'ts_reader.run')]/text()");

// Variabel untuk menyimpan URL gambar
$imageUrls = [];

// Loop melalui setiap script
foreach ($scripts as $script) {
    $scriptContent = $script->nodeValue;

    // Mencari potongan kode JavaScript yang mengandung URL gambar
    preg_match('/ts_reader.run\((.*?)\)/', $scriptContent, $matches);

    // Mendapatkan string JSON dari hasil pencocokan regex
    $jsonString = $matches[1];

    // Decode string JSON menjadi array
    $jsonData = json_decode($jsonString, true);

    // Mendapatkan URL prev dan next
    $prevUrl = $jsonData['prevUrl'];
    $nextUrl = $jsonData['nextUrl'];

    // Mendapatkan URL gambar dari array data JSON
    $imageUrls = $jsonData['sources'][0]['images'];

    // Hentikan pencarian setelah ditemukan
    break;
}

// Mendapatkan URL prev dan next
$prevUrl = $jsonData['prevUrl'];
$nextUrl = $jsonData['nextUrl'];

// Mengubah URL prev dan next dengan URL episode.php yang sesuai
$prevUrl = !empty($prevUrl) ? 'episode.php?url=' . urlencode($prevUrl) : '';
$nextUrl = !empty($nextUrl) ? 'episode.php?url=' . urlencode($nextUrl) : '';
// Mengekstrak ID episode dari URL
$episodeId = urlencode($url);

// Menyimpan episode yang disimpan oleh pengguna ke dalam database
$host = 'localhost';
$db = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_EMULATE_PREPARES => false,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Koneksi ke database gagal: " . $e->getMessage());
}

// Periksa apakah pengguna memiliki sesi login Telegram yang valid
if (isset($_SESSION['telegram_id'])) {
    $telegramID = $_SESSION['telegram_id']; // Menggunakan session untuk mendapatkan ID Telegram pengguna

    // Periksa apakah URL sudah ada dalam database untuk ID Telegram yang sama
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM episode_saved WHERE telegram_id = :telegram_id AND episode_url = :episode_url");
    $stmt->bindParam(':telegram_id', $telegramID);
    $stmt->bindParam(':episode_url', $url);
    $stmt->execute();
    $count = $stmt->fetchColumn();

    if ($count == 0) {
        // URL belum ada dalam database, lakukan operasi penyimpanan
        $stmt = $pdo->prepare("INSERT INTO episode_saved (telegram_id, episode_url) VALUES (:telegram_id, :episode_url)");
        $stmt->bindParam(':telegram_id', $telegramID);
        $stmt->bindParam(':episode_url', $url);
        $stmt->execute();
    }
}

// Menandai episode yang dikunjungi dengan cookie
setcookie($episodeId, 'checked', time() + (86400 * 30), "/"); // Cookie berlaku selama 30 hari
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome-all.min.css">
    

</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title">
                    <center><?php echo $title; ?></center>
                </div>

                <div class="notification">
                    Kamu sedang membaca komik "<?php echo $title; ?>".<br>
                    Link baca manga "<?php echo $title; ?>" lainnya tersedia di <a href="https://ccgnime.my.id/komik"
                        target="_blank">ccgnimex.my.id</a>.
                </div>

                <div class="image-list">
        <?php
        // Menampilkan semua gambar yang ditemukan
        foreach ($imageUrls as $index => $imageUrl) {
            echo "<img data-src=\"$imageUrl\" alt=\"\" data-index=\"$index\">";
        }
        ?>
    </div>
            </div>
        </div>
    </div>

<div class="navbar-floating rounded">
    <div class="navbar-item">
  <a href="https://ccgnimex.my.id/komik" target="_blank" rel="noopener noreferrer">
    <i class="fas fa-home"></i>
  </a>
</div>
  <div class="navbar-item">
    <a href="#" class="play-button">
      <i class="fas fa-play"></i>
    </a>
  </div>

    <div class="navbar-slider">
      <?php if (!empty($prevUrl) && !empty(parse_url($prevUrl, PHP_URL_QUERY)) && strpos($prevUrl, 'url=') !== false) : ?>
        <a href="<?php echo $prevUrl; ?>" class="navbar-slider-prev" id="prev-btn">Prev</a>
      <?php else : ?>
        <button type="button" class="navbar-slider-prev" id="prev-btn" disabled>Prev</button>
      <?php endif; ?>

      <?php if (!empty($nextUrl) && !empty(parse_url($nextUrl, PHP_URL_QUERY)) && strpos($nextUrl, 'url=') !== false) : ?>
        <a href="<?php echo $nextUrl; ?>" class="navbar-slider-next" id="next-btn">Next</a>
      <?php else : ?>
        <button type="button" class="navbar-slider-next" id="next-btn" disabled>Next</button>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
  var playButton = document.querySelector(".play-button");
  var isPlaying = false;
  var scrollInterval;

  playButton.addEventListener("click", function(e) {
    e.preventDefault();

    if (isPlaying) {
      // Menghentikan auto scroll
      clearInterval(scrollInterval);
      playButton.innerHTML = '<i class="fas fa-play"></i>';
      isPlaying = false;
    } else {
      // Memulai auto scroll
      playButton.innerHTML = '<i class="fas fa-stop"></i>';
      isPlaying = true;

      // Mengatur kecepatan scroll (ms)
      var scrollSpeed = 18;

      scrollInterval = setInterval(function() {
        // Jarak scroll per langkah
        var scrollStep = 1;

        // Scroll ke bawah
        window.scrollBy(0, scrollStep);

        // Menghentikan auto scroll saat mencapai bagian bawah halaman
        if (window.pageYOffset >= document.body.scrollHeight - window.innerHeight) {
          clearInterval(scrollInterval);
          playButton.innerHTML = '<i class="fas fa-play"></i>';
          isPlaying = false;
        }
      }, scrollSpeed);
    }
  });
});
</script>


<style>
#content-wrapper {
  position: relative;
  min-height: 100vh;
}

#content {
  margin-bottom: 60px; /* Tinggi navbar + margin */
}

.navbar-floating {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(255, 255, 255, 0.5); /* Ubah alpha (0.5) sesuai kebutuhan */
  backdrop-filter: blur(10px); /* Ubah nilai blur sesuai kebutuhan */
  padding: 10px;
  border-radius: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Tambahkan properti box-shadow */
  transition: bottom 0.3s;
  scroll-behavior: smooth; /* Tambahkan properti scroll-behavior */
}

.navbar-floating.hide {
  bottom: -60px;
}

.navbar-item {
  border-radius: 50%;
  padding: 10px;
  margin-right: 10px;
}

.navbar-item i {
  color: #333333;
}

.navbar-slider {
  display: flex;
  align-items: center;
  margin-left: 10px;
}

.navbar-slider-prev,
.navbar-slider-next {
  border: none;
  background-color: transparent;
  cursor: pointer;
  margin: 0 5px;
}

.navbar-slider-prev:hover,
.navbar-slider-next:hover {
  color: #999999;
}

/* Responsive adjustments */
@media (max-width: 767px) {
  .navbar-floating {
    padding: 5px;
    border-radius: 20px;
    left: 47%;
    bottom: 17px;
  }
  
  .navbar-item {
    padding: 5px;
    margin-right: 5px;
  }
  
  .navbar-slider-prev,
  .navbar-slider-next {
    margin: 0 2px;
  }
}

/* Additional adjustment for 320px width */
@media (max-width: 320px) {
  .navbar-floating {
    padding: 3px;
    border-radius: 12px;
    left: 47%;
  }
  
  .navbar-item {
    padding: 3px;
    margin-right: 3px;
  }
  
  .navbar-slider-prev,
  .navbar-slider-next {
    margin: 0 1px;
  }
}

.navbar-floating {
  /* Properti lain */
  transition: bottom 0.3s, opacity 0.3s;
  opacity: 1;
}

.navbar-floating.hide {
  bottom: -60px;
  opacity: 0;
}
</style>    

<script>
var prevScrollPos = window.pageYOffset;
var isPlaying = false;
var scrollInterval;

window.addEventListener('scroll', function() {
  var currentScrollPos = window.pageYOffset;
  var navbar = document.querySelector('.navbar-floating');
  
  if (isPlaying) {
    navbar.classList.remove('hide');
  } else {
    if (currentScrollPos > prevScrollPos) {
      navbar.classList.add('hide');
    } else {
      navbar.classList.remove('hide');
    }
  }
  
  prevScrollPos = currentScrollPos;
});

document.addEventListener("DOMContentLoaded", function() {
  var playButton = document.querySelector(".play-button");

  playButton.addEventListener("click", function(e) {
    e.preventDefault();

    if (isPlaying) {
      // Menghentikan auto scroll
      clearInterval(scrollInterval);
      playButton.innerHTML = '<i class="fas fa-play"></i>';
      isPlaying = false;
    } else {
      // Memulai auto scroll
      playButton.innerHTML = '<i class="fas fa-stop"></i>';
      isPlaying = true;

      // Mengatur kecepatan scroll (ms)
      var scrollSpeed = 50;

      scrollInterval = setInterval(function() {
        // Jarak scroll per langkah
        var scrollStep = 1;

        // Scroll ke bawah
        window.scrollBy(0, scrollStep);

        // Menghentikan auto scroll saat mencapai bagian bawah halaman
        if (window.pageYOffset >= document.body.scrollHeight - window.innerHeight) {
          clearInterval(scrollInterval);
          playButton.innerHTML = '<i class="fas fa-play"></i>';
          isPlaying = false;
        }
      }, scrollSpeed);
    }
  });
});

</script>
      
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const images = document.querySelectorAll("img[data-src]");
            const windowHeight = window.innerHeight;

            const observer = new IntersectionObserver(function (entries, observer) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        const image = entry.target;
                        const imageUrl = image.getAttribute("data-src");

                        // Load the image
                        image.src = imageUrl;

                        // Remove the data-src attribute to prevent loading it again
                        image.removeAttribute("data-src");

                        // Stop observing the image
                        observer.unobserve(image);
                    }
                });
            });

            images.forEach(function (image) {
                observer.observe(image);
            });

            const scrollAmount = windowHeight;

            function scrollToNextImage() {
                const currentPosition = window.scrollY;
                const newIndex = Math.floor((currentPosition + scrollAmount) / scrollAmount);
                const targetPosition = newIndex * scrollAmount;

                window.scrollTo({
                    top: targetPosition,
                    behavior: "smooth"
                });
            }

            images.forEach(function (image) {
                image.addEventListener("click", scrollToNextImage);
            });
        });

    </script>
    <style>
.popup-cardx {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.popup-contentx {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 80%;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  position: relative;
}

.closex {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 20px;
  font-weight: bold;
  color: #333;
  cursor: pointer;
}
</style>

<script>
function closePopup() {
  var popup = document.querySelector('.popup-cardx');
  popup.style.display = 'none';
}
</script>

<?php
// When the user is not logged in, show popup card with login button
if (!isset($_SESSION['logged-in'])) {
    echo '<div class="popup-cardx">';
    echo '<div class="popup-contentx">';
    echo '<span class="closex" onclick="closePopup()">&times;</span>';
    echo '<h3>Akses Diperlukan!</h3>';
    echo '<p><center>Silahkan login menggunakan akun telegram kalian, agar fitur dari website bisa digunakan sepenuhnya.</center></p>';
    echo '<a class="btn btn-primary" href="../login.php">Login</a>';
    echo '</div>';
    echo '</div>';
}
?>
</body>

</html>
