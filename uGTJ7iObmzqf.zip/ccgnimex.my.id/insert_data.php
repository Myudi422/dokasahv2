<?php
// Koneksi ke database MySQL
$db = mysqli_connect("127.0.0.1", "ccgnimex", "aaaaaaac", "ccgnimex");

// Get data from POST data
$recipient = $_POST['recipient'];
$item = $_POST['item'];

// Query untuk menyimpan data ke tabel new_table
$query = "INSERT INTO notify (recipient, recipient_type, item, type, language) VALUES (?, 'user', ?, 'anime', 'en')";

// Buat prepared statement
$stmt = mysqli_prepare($db, $query);

// Bind parameter ke prepared statement
mysqli_stmt_bind_param($stmt, 'ss', $recipient, $item);

// Eksekusi prepared statement
$query_result = mysqli_stmt_execute($stmt);

// Cek apakah query berhasil dijalankan
if ($query_result) {
    echo 'Data berhasil disimpan';
} else {
   echo 'Terjadi kesalahan saat menyimpan data: ' . mysqli_error($db);
}
?>