<?php

$token = "1920905087:AAG_xCvsdjxVu8VUDt9s4JhD22ND-UIJttQ";
$file_id = "BAACAgUAAx0EXPFFiwACHEdikdYK7BfATFiGvmbyu9NvwpoLVgACSgQAAnugkVQrpjnEln-uwh4E";

$url = "https://api.telegram.org/bot" . $token . "/getFile?file_id=" . $file_id;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$response = json_decode($response, true);
$file_path = $response["result"]["file_path"];
$file_url = "https://api.telegram.org/file/bot" . $token . "/" . $file_path;

?>

<iframe src="<?php echo $file_url; ?>"></iframe>