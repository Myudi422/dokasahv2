<?php
// Check if anime exists in the database table
// Replace with your own database connection code
$host = 'localhost';
$dbname = 'ccgnimex';
$username = 'ccgnimex';
$password = 'aaaaaaac';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get the anime_id from the AJAX request
$animeId = $_POST['anime_id'];

// Prepare and execute the SQL query
$sql = "SELECT COUNT(*) FROM nonton WHERE anime_id = :animeId";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':animeId', $animeId);
$stmt->execute();

// Fetch the result
$result = $stmt->fetchColumn();

// Return the response as JSON
$response = [
    'exists' => ($result > 0)
];
header('Content-Type: application/json');
echo json_encode($response);