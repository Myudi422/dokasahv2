<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Admin Page - Kirim Notifikasi</h2>
        <form action="process_notification.php" method="POST">
            <div class="form-group">
                <label for="animeId">ID Anime di AniList:</label>
                <input type="text" class="form-control" id="animeId" name="anilist_id" required>
            </div>
            <div class="form-group">
                <label for="episode">Nomor Episode:</label>
                <input type="number" class="form-control" id="episode" name="episode" required>
            </div>
            <button type="submit" class="btn btn-primary">Kirim Notifikasi</button>
        </form>
    </div>
</body>
</html>
