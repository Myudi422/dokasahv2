<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menerima Notifikasi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.5.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Daftar Notifikasi</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Judul</th>
                    <th>Episode</th>
                    <th>Jam Notifikasi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $db_host = "localhost";
                $db_name = "ccgnimex";
                $db_user = "ccgnimex";
                $db_password = "aaaaaaac";

                $conn = new mysqli($db_host, $db_user, $db_password, $db_name);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT * FROM notif_web WHERE is_read = 0";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $animeId = $row['anime_id'];

                        // Make a call to Anilist API to get anime information
                        $url = "https://graphql.anilist.co";
                        $query = <<<EOL
                        {
                            Media(id: $animeId) {
                                title {
                                    romaji
                                }
                                coverImage {
                                    medium
                                }
                            }
                        }
EOL;

                        $data = array(
                            'query' => $query
                        );

                        $options = array(
                            'http' => array(
                                'method' => 'POST',
                                'header' => 'Content-Type: application/json',
                                'content' => json_encode($data)
                            )
                        );

                        $context = stream_context_create($options);
                        $response = file_get_contents($url, false, $context);
                        $resultData = json_decode($response, true);

                        $judul = $resultData['data']['Media']['title']['romaji'];
                        $gambar = $resultData['data']['Media']['coverImage']['medium'];
                        $episode = "Episode 1"; // Retrieve episode from API or database
                        $jamNotifikasi = $row['created_at'];

                        echo "<tr>
                                <td><img src='$gambar' alt='Gambar Anime' width='100'></td>
                                <td>$judul</td>
                                <td>$episode</td>
                                <td>$jamNotifikasi</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Tidak ada notifikasi baru.</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
