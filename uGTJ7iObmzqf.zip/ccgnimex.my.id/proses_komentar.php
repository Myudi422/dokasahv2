<?php
// Mendapatkan nilai komentar, idAnime, dan telegramid dari form
$komentar = $_POST['komentar'];
$idAnime = $_POST['idAnime'];

// Membuat URL komentar berdasarkan ID anime dari AniList dan nilai telegramid
$urlKomentar = 'https://ccgnimex.my.id/thread/' . $idAnime;

// Menyimpan komentar ke dalam database atau melakukan aksi lain sesuai kebutuhan Anda
// ...

// Redirect ke URL komentar
header('Location: ' . $urlKomentar);
exit;
?>