<?php
// Set the URL of the page to scrape
$url = 'https://dafunda.com/otaku/anime-manga/';

// Retrieve the HTML content of the page
$html = file_get_contents($url);

// Create a new DOMDocument object
$dom = new DOMDocument();

// Load the HTML into the DOMDocument object
@$dom->loadHTML($html);

// Use DOMXPath to navigate and query the DOM
$xpath = new DOMXPath($dom);

// Define the XPath query to find the element you want
$query = '//div[@class="ak-content"]';

// Execute the XPath query
$elements = $xpath->query($query);

// Loop through the elements and extract the data you need
foreach ($elements as $element) {
    // Extract the data from the element
    // ...
}