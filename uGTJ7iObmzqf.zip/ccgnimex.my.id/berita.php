<?php
// Start the session
session_start();



// Import database connection and class
require('db-config.php');

include 'jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>💞 ccgnimex | Mari Mengvvibu</title>
    <meta name="description" content="ccgnimex adalah sebuah website yang menyediakan layanan download dan streaming anime. Di website ini, kalian bisa menemukan berbagai macam jenis anime, mulai dari ongoing, completed, batch, hingga anime yang bisa ditonton melalui bot Telegram. Selain itu, ccgnimex juga menyediakan berbagai fitur dan tampilan yang membuat penggunaan website ini semakin mudah dan menyenangkan. Dengan menggunakan layanan dari ccgnimex, Anda bisa menemukan anime favorit Anda dan menontonnya dengan cara yang lebih mudah dan praktis.">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <style>@media (max-width: 576px) {
  .row {
    display: none;
  }
}</style>
<meta name="google-site-verification" content="A1HYpSm2bOSTfTIoEl8SWJDrh9GWw_22ad73OvrsBWI" />
<style>
.popup-cardx {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.popup-contentx {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 80%;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  position: relative;
}

.closex {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 20px;
  font-weight: bold;
  color: #333;
  cursor: pointer;
}
</style>

<script>
function closePopup() {
  var popup = document.querySelector('.popup-cardx');
  popup.style.display = 'none';
}
</script>

<?php
// When the user is not logged in, show popup card with login button
if (!isset($_SESSION['logged-in'])) {
    echo '<div class="popup-cardx">';
    echo '<div class="popup-contentx">';
    echo '<span class="closex" onclick="closePopup()">&times;</span>';
    echo '<h3>Akses Diperlukan!</h3>';
    echo '<p><center>Silahkan login menggunakan akun telegram kalian, agar fitur dari website bisa digunakan sepenuhnya.</center></p>';
    echo '<a class="btn btn-primary" href="login.php">Login</a>';
    echo '</div>';
    echo '</div>';
}
?>

<link rel="apple-touch-icon" sizes="57x57" href="/icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icon1/favicon-16x16.png">
<link rel="manifest" href="/icon1/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/icon1/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


</head>

<body id="page-top" class>
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0 toggled">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="komik"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="kategori"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">3+</span><i class="fas fa-bell fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-primary icon-circle"><i class="fas fa-file-alt text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 12, 2019</span>
                                                <p>A new monthly report is ready to download!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-success icon-circle"><i class="fas fa-donate text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 7, 2019</span>
                                                <p>$290.29 has been deposited into your account!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-warning icon-circle"><i class="fas fa-exclamation-triangle text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 2, 2019</span>
                                                <p>Spending Alert: We've noticed unusually high spending for your account.</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid">
<?php
if (isset($_GET['url']) && isset($_GET['title'])) {
  $articleUrl = $_GET['url'];
  $articleTitle = $_GET['title'];

  // Set the URL of the website article you want to scrape
  $articleUrl = urldecode($articleUrl);

  // Use cURL to get the HTML content of the article
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $articleUrl);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $html = curl_exec($ch);
  curl_close($ch);

  // Create a new DOMDocument and load the HTML content
  $dom = new DOMDocument();
  @$dom->loadHTML($html);

  // Use DOMXPath to query the DOM and get the article content
  $xpath = new DOMXPath($dom);
  
  // Get the article title
  $titleNode = $xpath->query('//div[contains(@class, "tdb-block-inner")]/h1[contains(@class, "tdb-title-text")]')->item(0);
  $articleTitle = $titleNode->nodeValue;

  // Get the article content
  $articleContentNode = $xpath->query('//div[contains(@class, "tdb_single_content")]')->item(0);
  $articleContent = $articleContentNode->nodeValue;

  // Sanitize the article content
  $articleContent = htmlspecialchars($articleContent);
  $articleContent = preg_replace('/\/\* custom css \*\/.*AnimeNewsPlus.Net/s', '', $articleContent);
  $articleContent = str_replace('(adsbygoogle=window.adsbygoogle||[]).push({})', '', $articleContent);
  $articleContent = 'ccgnimex.my.id ' . $articleContent;

  // Remove unwanted texts
  $unwantedTexts = [
    'Trailer-',
    'Iklan,',
    'Terakhir Komentar Dibawah -'
  ];

  foreach ($unwantedTexts as $text) {
    $articleContent = str_replace($text, '', $articleContent);
  }

  // Double spaces
  $articleContent = str_replace(' ', '  ', $articleContent);

  // Double new lines when there is a period followed by a capital letter or space
  $articleContent = preg_replace('/(\.\s+|\.\s*)([A-Z\s])/s', "$1\n\n$2", $articleContent);
?>

<h1 class="h3 mb-4 text-gray-800"><?php echo $articleTitle; ?></h1>
<div class="card shadow mb-4">
  <div class="card-body">
    <p><?php echo nl2br($articleContent); ?></p>
  </div>
</div>

<?php
}
?>


</div>
<style>.card-body {
    max-width: 100%;
    overflow: hidden;
}
.owl-carousel {
            max-width: 100%;
            margin: 0 auto;
        }
@media (max-width: 600px) {
    .owl-carousel {
        max-width: 90%;
    }
}
        </style>
                  
            </div>
            <div class="position-fixed bottom-0 start-0 p-3" style="z-index: 5">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#telegramModal">
        <i class="fas fa-comment"></i>
    </button>
</div>

<div class="modal fade" id="telegramModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body"></div>
        </div>
    </div>
</div>

<script>
    var telegramModal = document.getElementById('telegramModal')
    var modalBody = telegramModal.querySelector('.modal-body')

    telegramModal.addEventListener('hidden.bs.modal', function (event) {
        modalBody.innerHTML = ''
    })

    telegramModal.addEventListener('show.bs.modal', function (event) {
        var script = document.createElement('script')
        script.async = true
        script.src = 'https://telegram.org/js/telegram-widget.js?21'
        script.setAttribute('data-telegram-discussion', 'otakuindonew/1')
        script.setAttribute('data-comments-limit', '3')
        script.setAttribute('data-height', '400')
        script.setAttribute('data-colorful', '1')
        modalBody.appendChild(script)
    })
</script>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © ccgnimex</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script>$(document).ready(function() {
    // Collapse the sidebar upon page load
    $("#sidebarToggle").trigger("click");
});</script>

<script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', 'update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', 'retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>
</body>
