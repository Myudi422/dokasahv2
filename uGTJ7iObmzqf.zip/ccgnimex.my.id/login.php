<?php
// Start the session
session_start();


// Di auth.php
// Ketika pengguna sudah masuk, pergi ke halaman yang ditentukan oleh $_SESSION['redirect_index'] atau $_SESSION['redirect_streaming']
if (isset($_SESSION['logged-in']) && $_SESSION['logged-in'] == TRUE) {
    if (isset($_SESSION['redirect_index'])) {
        $redirect_page = $_SESSION['redirect_index'];
    } elseif (isset($_SESSION['redirect_streaming'])) {
        $redirect_page = $_SESSION['redirect_streaming'];
    } else {
        $redirect_page = 'index.php';
    }
    die(header('Location: ' . $redirect_page));
}

// Place username of your bot here
define('BOT_USERNAME', 'ccgnimeX_bot');

include 'jumlah-user.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
  <style>
    body {
      /* Add a background image */
      background-image: url('https://lionfish-app-glezi.ondigitalocean.app/11412/1318300.webp');
      /* Center the background image and make it cover the entire page */
      background-position: center;
      background-size: cover;
      /* Ensure the background image covers the whole viewport */
      height: 100vh;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* Additional custom styles can be added here */
    /* Example: */
    /* .logo {
         width: 100px;
         height: 100px;
         object-fit: contain;
       } */

    .login-form {
      background-color: #ffffff;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
      border-radius: 12px;
      padding: 2rem;
      width: 100%;
      max-width: 400px;
    }

    .login-title {
      font-size: 1.5rem;
      font-weight: bold;
      text-align: center;
      margin-bottom: 1rem;
    }

    .form-input {
      width: 100%;
      border: 1px solid #cbd5e0;
      border-radius: 0.375rem;
      padding: 0.75rem 1rem;
      margin-bottom: 1rem;
      transition: border-color 0.3s ease;
    }

    .form-input:focus {
      outline: none;
      border-color: #6366f1;
    }

    .form-btn {
      width: 100%;
      background-color: #6366f1;
      color: #ffffff;
      font-weight: bold;
      padding: 0.75rem 1rem;
      border-radius: 0.375rem;
      transition: background-color 0.3s ease;
    }

    .form-btn:hover {
      background-color: #4338ca;
    }

    .form-checkbox-label {
      display: inline-block;
      margin-right: 0.5rem;
    }

    .form-checkbox {
      margin-bottom: 1rem;
    }

    .form-links {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 1rem;
      border-top: 1px solid #cbd5e0;
      padding-top: 1rem;
    }

    .form-links a {
      text-decoration: none;
      color: #6366f1;
      transition: color 0.3s ease;
    }

    .form-links a:hover {
      color: #4338ca;
    }

    .form-links .or-login {
      color: #9ca3af;
      font-size: 0.875rem;
    }

    .form-links .line {
      flex: 1;
      height: 1px;
      background-color: #cbd5e0;
      margin: 0 0.5rem;
    }
  </style>
</head>
<body>
  <div class="login-form">
    <h2 class="login-title">Sign In</h2>
    <form action="process_login.php" method="POST">
      <div>
        <label for="email" class="block text-gray-700 font-bold mb-2">Email</label>
        <input type="email" class="form-input" id="email" name="email" required>
      </div>
      <div>
        <label for="password" class="block text-gray-700 font-bold mb-2">Password</label>
        <input type="password" class="form-input" id="password" name="password" required>
      </div>
      <div class="form-checkbox">
        <input type="checkbox" name="remember_me" id="remember_me" class="mr-2 leading-tight">
        <label for="remember_me" class="form-checkbox-label text-gray-700">Remember Me</label>
      </div>
      <div>
        <button type="submit" class="form-btn">Sign In</button>
      </div>
    </form>
    <div class="form-links">
      <a href="#" class="forgot-password">Forgot Password</a>
      <a href="/create" class="create-user">Create User</a>
    </div>
        <div class="form-links">
      <div class="line"></div>
      <div class="or-login">Or Login</div>
      <div class="line"></div>
    </div>
    <!-- Optional Telegram Login Widget -->
    <div class="mt-4">
      <form class="user">
        <script async src="https://telegram.org/js/telegram-widget.js" data-telegram-login="<?= BOT_USERNAME ?>" data-size="large" data-radius="10" data-auth-url="auth.php"></script>
      </form>
    </div>
    <!-- End of Optional Telegram Login Widget -->
  </div>
  
  <script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>
</html>
