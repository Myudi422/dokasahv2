<?php
require_once 'vendor/autoload.php';
use Stichoza\GoogleTranslate\GoogleTranslate;

// Set the target language to Indonesian
$targetLanguage = 'id';

// Get the text to be translated from the request
$text = $_GET['text'];

// Create a new GoogleTranslate object
$tr = new GoogleTranslate();

// Set the target language
$tr->setTarget($targetLanguage);

// Translate the text
$translatedText = $tr->translate($text);

// Return the translated text as JSON
header('Content-Type: application/json');
echo json_encode(['translatedText' => $translatedText]);