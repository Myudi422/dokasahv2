<?php
// Start the session
session_start();


// When the user is not logged in, go to the login page
if (!isset($_SESSION['logged-in'])) {
    die(header('Location: login.php'));
}


// Import database connection and class
require('db-config.php');

include 'jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Profile - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    
    <style>
/* Magnific Popup CSS */
.mfp-bg {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 502;
  overflow: hidden;
  position: fixed;
  background: #0b0b0b;
  opacity: 0.8;
  filter: alpha(opacity=80); }

.mfp-wrap {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 503;
  position: fixed;
  outline: none !important;
  -webkit-backface-visibility: hidden; }

.mfp-container {
  height: 100%;
  text-align: center;
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  padding: 0 8px;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box; }

.mfp-container:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle; }

.mfp-align-top .mfp-container:before {
  display: none; }

.mfp-content {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin: 0 auto;
  text-align: left;
  z-index: 505; }

.mfp-inline-holder .mfp-content,
.mfp-ajax-holder .mfp-content {
  width: 100%;
  cursor: auto; }

.mfp-ajax-cur {
  cursor: progress; }

.mfp-zoom-out-cur,
.mfp-zoom-out-cur .mfp-image-holder .mfp-close {
  cursor: -moz-zoom-out;
  cursor: -webkit-zoom-out;
  cursor: zoom-out; }

.mfp-zoom {
  cursor: pointer;
  cursor: -webkit-zoom-in;
  cursor: -moz-zoom-in;
  cursor: zoom-in; }

.mfp-auto-cursor .mfp-content {
  cursor: auto; }

.mfp-close,
.mfp-arrow,
.mfp-preloader,
.mfp-counter {
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none; }

.mfp-loading.mfp-figure {
  display: none; }

.mfp-hide {
  display: none !important; }

.mfp-preloader {
  color: #cccccc;
  position: absolute;
  top: 50%;
  width: auto;
  text-align: center;
  margin-top: -0.8em;
  left: 8px;
  right: 8px;
  z-index: 504; }

.mfp-preloader a {
  color: #cccccc; }

.mfp-preloader a:hover {
  color: white; }

.mfp-s-ready .mfp-preloader {
  display: none; }

.mfp-s-error .mfp-content {
  display: none; }

button.mfp-close,
button.mfp-arrow {
  overflow: visible;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
  display: block;
  padding: 0;
  z-index: 506; }

button::-moz-focus-inner {
  padding: 0;
  border: 0; }

.mfp-close {
  width: 44px;
  height: 44px;
  line-height: 44px;
  position: absolute;
  right: 0;
  top: 0;
  text-decoration: none;
  text-align: center;
  opacity: 0.65;
  padding: 0 0 18px 10px;
  color: white;
  font-style: normal;
  font-size: 28px;
  font-family: Arial, Baskerville, monospace; }
  .mfp-close:hover, .mfp-close:focus {
    opacity: 1; }
  .mfp-close:active {
    top: 1px; }

.mfp-close-btn-in .mfp-close {
  color: #333333; }

.mfp-image-holder .mfp-close,
.mfp-iframe-holder .mfp-close {
  color: white;
  right: -6px;
  text-align: right;
  padding-right: 6px;
  width: 100%; }

.mfp-counter {
  position: absolute;
  top: 0;
  right: 0;
  color: #cccccc;
  font-size: 12px;
  line-height: 18px; }

.mfp-arrow {
  position: absolute;
  top: 0;
  opacity: 0.65;
  margin: 0;
  top: 50%;
  margin-top: -55px;
  padding: 0;
  width: 90px;
  height: 110px;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

.mfp-arrow:active {
  margin-top: -54px; }

.mfp-arrow:hover,
.mfp-arrow:focus {
  opacity: 1; }

.mfp-arrow:before, .mfp-arrow:after,
.mfp-arrow .mfp-b,
.mfp-arrow .mfp-a {
  content: '';
  display: block;
  width: 0;
  height: 0;
  position: absolute;
  left: 0;
  top: 0;
  margin-top: 35px;
  margin-left: 35px;
  border: solid transparent; }
.mfp-arrow:after,
.mfp-arrow .mfp-a {
  opacity: 0.8;
  border-top-width: 12px;
  border-bottom-width: 12px;
  top: 8px; }
.mfp-arrow:before,
.mfp-arrow .mfp-b {
  border-top-width: 20px;
  border-bottom-width: 20px; }

.mfp-arrow-left {
  left: 0; }
  .mfp-arrow-left:after,
  .mfp-arrow-left .mfp-a {
    border-right: 12px solid black;
    left: 5px; }
  .mfp-arrow-left:before,
  .mfp-arrow-left .mfp-b {
    border-right: 20px solid white; }

.mfp-arrow-right {
  right: 0; }
  .mfp-arrow-right:after,
  .mfp-arrow-right .mfp-a {
    border-left: 12px solid black;
    left: 3px; }
  .mfp-arrow-right:before,
  .mfp-arrow-right .mfp-b {
    border-left: 20px solid white; }

.mfp-iframe-holder {
  padding-top: 40px;
  padding-bottom: 40px; }

.mfp-iframe-holder .mfp-content {
  line-height: 0;
  width: 100%;
  max-width: 900px; }

.mfp-iframe-scaler {
  width: 100%;
  height: 0;
  overflow: hidden;
  padding-top: 56.25%; }

.mfp-iframe-scaler iframe {
  position: absolute;
  top: -3px;
  left: 0;
  width: 100%;
  height: 100%;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.6);
  background: black; }

.mfp-iframe-holder .mfp-close {
  top: -43px; }

/* Main image in popup */
img.mfp-img {
  width: auto;
  max-width: 100%;
  height: auto;
  display: block;
  line-height: 0;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  padding: 40px 0 40px;
  margin: 0 auto; }

/* The shadow behind the image */
.mfp-figure:after {
  content: '';
  position: absolute;
  left: 0;
  top: 40px;
  bottom: 40px;
  display: block;
  right: 0;
  width: auto;
  height: auto;
  z-index: -1;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.6); }

.mfp-figure {
  line-height: 0; }

.mfp-bottom-bar {
  margin-top: -36px;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  cursor: auto; }

.mfp-title {
  text-align: left;
  line-height: 18px;
  color: #f3f3f3;
  word-break: break-word;
  padding-right: 36px; }

.mfp-figure small {
  color: #bdbdbd;
  display: block;
  font-size: 12px;
  line-height: 14px; }

.mfp-image-holder .mfp-content {
  max-width: 100%; }

.mfp-gallery .mfp-image-holder .mfp-figure {
  cursor: pointer; }

@media screen and (max-width: 800px) and (orientation: landscape), screen and (max-height: 300px) {
  /**
   * Remove all paddings around the image on small screen
   */
  .mfp-img-mobile .mfp-image-holder {
    padding-left: 0;
    padding-right: 0; }

  .mfp-img-mobile img.mfp-img {
    padding: 0; }

  /* The shadow behind the image */
  .mfp-img-mobile .mfp-figure:after {
    top: 0;
    bottom: 0; }

  .mfp-img-mobile .mfp-bottom-bar {
    background: rgba(0, 0, 0, 0.6);
    bottom: 0;
    margin: 0;
    top: auto;
    padding: 3px 5px;
    position: fixed;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box; }

  .mfp-img-mobile .mfp-bottom-bar:empty {
    padding: 0; }

  .mfp-img-mobile .mfp-counter {
    right: 5px;
    top: 3px; }

  .mfp-img-mobile .mfp-close {
    top: 0;
    right: 0;
    width: 35px;
    height: 35px;
    line-height: 35px;
    background: rgba(0, 0, 0, 0.6);
    position: fixed;
    text-align: center;
    padding: 0; }

  .mfp-img-mobile .mfp-figure small {
    display: inline;
    margin-left: 5px; } }
@media all and (max-width: 800px) {
  .mfp-arrow {
    -webkit-transform: scale(0.75);
    transform: scale(0.75); }

  .mfp-arrow-left {
    -webkit-transform-origin: 0;
    transform-origin: 0; }

  .mfp-arrow-right {
    -webkit-transform-origin: 100%;
    transform-origin: 100%; }

  .mfp-container {
    padding-left: 6px;
    padding-right: 6px; } }
.mfp-ie7 .mfp-img {
  padding: 0; }
.mfp-ie7 .mfp-bottom-bar {
  width: 600px;
  left: 50%;
  margin-left: -300px;
  margin-top: 5px;
  padding-bottom: 5px; }
.mfp-ie7 .mfp-container {
  padding: 0; }
.mfp-ie7 .mfp-content {
  padding-top: 44px; }
.mfp-ie7 .mfp-close {
  top: 0;
  right: 0;
  padding-top: 0; }
</style>
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"><i class="fas fa-laugh-wink"></i></div>
                    <div class="sidebar-brand-text mx-3"><span>Brand</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item"><a class="nav-link active" href="profile.html"><i class="fas fa-user"></i><span>Profile</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="table.html"><i class="fas fa-table"></i><span>Table</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="login.html"><i class="far fa-user-circle"></i><span>Login</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="register.html"><i class="fas fa-user-circle"></i><span>Register</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search">
                            <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ..."><button class="btn btn-primary py-0" type="button"><i class="fas fa-search"></i></button></div>
                        </form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100">
                                        <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ...">
                                            <div class="input-group-append"><button class="btn btn-primary py-0" type="button"><i class="fas fa-search"></i></button></div>
                                        </div>
                                    </form>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">3+</span><i class="fas fa-bell fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-primary icon-circle"><i class="fas fa-file-alt text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 12, 2019</span>
                                                <p>A new monthly report is ready to download!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-success icon-circle"><i class="fas fa-donate text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 7, 2019</span>
                                                <p>$290.29 has been deposited into your account!</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="me-3">
                                                <div class="bg-warning icon-circle"><i class="fas fa-exclamation-triangle text-white"></i></div>
                                            </div>
                                            <div><span class="small text-gray-500">December 2, 2019</span>
                                                <p>Spending Alert: We've noticed unusually high spending for your account.</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                
                
  <?php
  // Start the session
  session_start();

  // When the user is not logged in, go to the login page
  if (!isset($_SESSION['logged-in'])) {
    die(header('Location: login.php'));
  }

  // Database connection details
  $db_host = 'localhost';
  $db_name = 'ccgnimex';
  $db_user = 'ccgnimex';
  $db_pass = 'aaaaaaac';

  // Connect to the database
  try {
    $db = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
  } catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
  }

  // Pagination settings
  $limit = 20; // Number of users to display per page
  $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
  $offset = ($page - 1) * $limit; // Offset for SQL query

  // Get total number of users
  $query = $db->prepare("SELECT COUNT(*) AS total FROM `users_web`");
  $query->execute();
  $total_users = $query->fetch(PDO::FETCH_ASSOC)['total'];

  // Calculate total number of pages
  $total_pages = ceil($total_users / $limit);

  // Get user data from the database with limit and offset
  $query = $db->prepare(
    "SELECT `profile_picture`, `telegram_username`, `auth_date`, `telegram_id`
        FROM `users_web`
        LIMIT :limit OFFSET :offset"
  );
  $query->bindParam(':limit', $limit, PDO::PARAM_INT);
  $query->bindParam(':offset', $offset, PDO::PARAM_INT);
  $query->execute();
  $user_data = $query->fetchAll(PDO::FETCH_ASSOC);

  // Get watched data from the database
  $query = $db->prepare(
    "SELECT `telegram_id`, COUNT(*) as `watched`
        FROM `ditonton`
        GROUP BY `telegram_id`"
  );
  $query->execute();
  $watched_data = $query->fetchAll(PDO::FETCH_ASSOC);

  // Create an associative array with telegram_id as key and watched as value
  $watched_array = array();
  foreach ($watched_data as $data) {
    $watched_array[$data['telegram_id']] = $data['watched'];
  }

  // Add watched data to the user data array
  foreach ($user_data as $index => $user) {
    if (array_key_exists($user['telegram_id'], $watched_array)) {
      $user_data[$index]['watched'] = $watched_array[$user['telegram_id']];
    } else {
      $user_data[$index]['watched'] = 0;
    }
  }

  // Sort the user data array by watched value in descending order
  usort($user_data, function ($a, $b) {
    return $b['watched'] - $a['watched'];
  });

  // Generate table rows with sorted user data
  $table_rows = '';
  foreach ($user_data as $index => $user) {
    $last_login = calculateTimeAgo($user['auth_date']);

    $table_rows .= '<tr>';
    $table_rows .= '<td><img src="' . $user['profile_picture'] . '" class="rounded-circle" style="width: 50px; height: 50px;"></td>';
    $table_rows .= '<td><a href="https://t.me/' . $user['telegram_username'] . '">' . $user['telegram_username'] . '</a></td>';
    $table_rows .= '<td>' . $last_login . '</td>';
    // Add watched data to the table row
    if (array_key_exists($user['telegram_id'], $watched_array)) {
      $table_rows .= '<td>' . $watched_array[$user['telegram_id']] . '</td>';
    } else {
      $table_rows .= '<td>0</td>';
    }
    $table_rows .= '</tr>';
  }

function calculateTimeAgo($datetime)
{
  $datetime_jakarta = new DateTime($datetime, new DateTimeZone('Asia/Jakarta'));
  $current_time = new DateTime('now', new DateTimeZone('Asia/Jakarta'));

  $time_difference = $current_time->getTimestamp() - $datetime_jakarta->getTimestamp();

  if ($time_difference >= 60 * 60 * 24 * 365) {
    $years = floor($time_difference / (60 * 60 * 24 * 365));
    return $years . ' tahun lalu';
  } elseif ($time_difference >= 60 * 60 * 24 * 30) {
    $months = floor($time_difference / (60 * 60 * 24 * 30));
    return $months . ' bulan lalu';
  } elseif ($time_difference >= 60 * 60 * 24) {
    $days = floor($time_difference / (60 * 60 * 24));
    return $days . ' hari lalu';
  } elseif ($time_difference >= 60 * 60) {
    $hours = floor($time_difference / (60 * 60));
    return $hours . ' jam lalu';
  } elseif ($time_difference >= 60) {
    $minutes = floor($time_difference / 60);
    return $minutes . ' menit lalu';
  } elseif ($time_difference > 0) {
    return $time_difference . ' detik lalu';
  } else {
    return 'baru saja';
  }
}

  ?>

  <div class="container">
    <h2>Leaderboard</h2>
    <div class="input-group mb-3">
      <input id="search-input" type="text" class="form-control" placeholder="Search by username">
      <div class="input-group-append">
        <button id="search-button" class="btn btn-outline-secondary" type="button">Search</button>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Profile Photo</th>
            <th>Username</th>
            <th>Last Login</th>
            <th>Watched</th>
          </tr>
        </thead>
        <tbody>
          <?php echo $table_rows; ?>
        </tbody>
      </table>
    </div>

    <nav aria-label="Page navigation">
      <ul class="pagination justify-content-center">
        <?php if ($page > 1) : ?>
          <li class="page-item">
            <a class="page-link" href="?page=<?php echo ($page - 1); ?>">Previous</a>
          </li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
          <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
          </li>
        <?php endfor; ?>

        <?php if ($page < $total_pages) : ?>
          <li class="page-item">
            <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>

  <script>
    document.getElementById('search-button').addEventListener('click', function() {
      var input = document.getElementById('search-input').value.toLowerCase();
      var rows = document.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
      for (var i = 0; i < rows.length; i++) {
        var username = rows[i].getElementsByTagName('td')[1].getElementsByTagName('a')[0].innerHTML.toLowerCase();
        if (username.includes(input)) {
          rows[i].style.display = '';
        } else {
          rows[i].style.display = 'none';
        }
      }
    });
  </script>
<?php
// Set the URL of the website you want to scrape
$url = 'https://anievo.id/category/a/';

// Use cURL to get the HTML content of the website
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3');
$html = curl_exec($ch);
curl_close($ch);

// Create a new DOMDocument and load the HTML content
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();

// Use DOMXPath to query the DOM and get the elements you want
$xpath = new DOMXPath($dom);
$articleDivs = $xpath->query('//div[@class="jeg_posts jeg_load_more_flag"]/article[@class="jeg_post jeg_pl_md_1 format-standard"]');

// Initialize an array to store the scraped data
$articles = array();

foreach ($articleDivs as $articleDiv) {
    $imageElement = $xpath->query('.//div[@class="jeg_thumb"]/a/div/img', $articleDiv)->item(0);
    $image = ($imageElement !== null) ? $imageElement->getAttribute('data-src') : '';

    $titleElement = $xpath->query('.//div[@class="jeg_postblock_content"]/h3[@class="jeg_post_title"]/a', $articleDiv)->item(0);
    $title = ($titleElement !== null) ? $titleElement->textContent : '';

    $categoryElement = $xpath->query('.//div[@class="jeg_post_category"]/span/a', $articleDiv)->item(0);
    $category = ($categoryElement !== null) ? $categoryElement->textContent : '';

    $timeElement = $xpath->query('.//div[@class="jeg_post_meta"]/div[@class="jeg_meta_date"]/a', $articleDiv)->item(0);
    $time = ($timeElement !== null) ? $timeElement->textContent : '';

    $linkElement = $xpath->query('.//div[@class="jeg_postblock_content"]/h3[@class="jeg_post_title"]/a', $articleDiv)->item(0);
    $link = ($linkElement !== null) ? 'https://anievo.id' . $linkElement->getAttribute('href') : '';

    $article = array(
        'image' => $image,
        'title' => $title,
        'category' => $category,
        'time' => $time,
        'link' => $link
    );

    $articles[] = $article;
}

// Display the scraped data
$numColumns = 3; // Ubah nilai ini sesuai dengan jumlah kolom yang diinginkan

echo '
<style>
.card-columns {
    column-count: 1;
}

@media (min-width: 576px) {
    .card-columns {
        column-count: 2;
    }
}

@media (min-width: 768px) {
    .card-columns {
        column-count: 3;
    }
}

@media (min-width: 992px) {
    .card-columns {
        column-count: 4;
    }
}

@media (min-width: 1200px) {
    .card-columns {
        column-count: 5;
    }
}

.card {
    margin-bottom: 1rem;
    overflow: hidden;
}

.card-img-top {
    height: 200px;
    object-fit: cover;
}

.card-title {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 0.5rem;
    cursor: pointer;
}

.card-text {
    font-size: 14px;
    margin-bottom: 0.5rem;
}

.card-footer {
    font-size: 12px;
    color: #6c757d;
    background-color: #f8f9fa;
    border-top: 1px solid #dee2e6;
}
</style>
<script>
function toggleTitle(event) {
    var titleElement = event.target.parentNode.querySelector(".card-title");
    if (titleElement.style.whiteSpace === "normal") {
        titleElement.style.whiteSpace = "nowrap";
    } else {
        titleElement.style.whiteSpace = "normal";
    }
}
</script>
<div class="container">
    <div class="row">
';

$columnSize = 12 / $numColumns;
foreach ($articles as $article) {
    echo '
    <div class="col-md-' . $columnSize . ' col-sm-6 col-12 mb-4">
        <div class="card">
            <img src="' . $article['image'] . '" class="card-img-top" alt="Article Image" onclick="toggleTitle(event)">
            <div class="card-body">
                <h5 class="card-title" onclick="toggleTitle(event)">' . $article['title'] . '</h5>
                <p class="card-text">Category: ' . $article['category'] . '</p>
                <p class="card-text">Time: ' . $article['time'] . '</p>
                <a href="' . $article['link'] . '" class="btn btn-primary" target="_blank">Baca Artikel</a>

            </div>
        </div>
    </div>
    ';
}

echo '
    </div>
</div>
';


?>





                
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Brand 2023</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>