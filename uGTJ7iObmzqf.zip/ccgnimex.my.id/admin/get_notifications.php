<?php

header('Access-Control-Allow-Origin: *');

// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Query untuk mengambil notifikasi terbaru
$query = "SELECT message FROM notifications_plugin ORDER BY created_at DESC LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result) {
    $notifications = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }
    echo json_encode($notifications);
} else {
    // Handling kesalahan jika query gagal
    echo json_encode(array("error" => "Gagal mengambil notifikasi."));
}

// Tutup koneksi ke database
$conn->close();
?>
