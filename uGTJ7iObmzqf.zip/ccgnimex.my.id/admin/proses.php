<?php
// Establish database connection
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve video details based on Anime ID
$animeId = $_POST['animeId'];
$sql = "SELECT video_url, title, resolusi FROM nonton WHERE anime_id = '$animeId'";
$result = $conn->query($sql);

$videoDetails = array(); // Array to store video details

// Loop through the retrieved video details
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $videoDetails[] = array(
            'title' => $row['title'],
            'resolution' => $row['resolusi'],
            'video_url' => $row['video_url']
        );
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download and Create RAR - Result</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Download and Create RAR - Result</h1>
        <?php if (!empty($videoDetails)) { ?>
            <form action="download.php" method="POST">
                <div class="form-group">
                    <label>Select videos to download:</label>
                    <?php foreach ($videoDetails as $video) { ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="selectedVideos[]" value="<?php echo $video['video_url']; ?>">
                            <label class="form-check-label"><?php echo $video['title']; ?> - <?php echo $video['resolution']; ?> - <?php echo $video['video_url']; ?></label>
                        </div>
                    <?php } ?>
                </div>
                <input type="hidden" name="zipFileName" value="<?php echo uniqid() . '.zip'; ?>">
                <button type="submit" class="btn btn-primary">Download and Create RAR</button>
            </form>
        <?php } else { ?>
            <p class="mt-4">No videos found for Anime ID: <?php echo $animeId; ?></p>
        <?php } ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
