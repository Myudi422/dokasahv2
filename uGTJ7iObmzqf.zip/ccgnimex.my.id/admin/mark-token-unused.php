<?php
// Database connection
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voucher = $_POST['voucher'];

    // Update the database to mark the token as unused
    $sql = "UPDATE devices SET is_used = 0 WHERE device_token = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $voucher);

    if ($stmt->execute()) {
        // Token marked as unused successfully
        echo json_encode(array('status' => 'success'));
    } else {
        // Error marking the token as unused
        echo json_encode(array('status' => 'error', 'message' => 'Failed to mark the token as unused.'));
    }
} else {
    // Invalid request method
    echo json_encode(array('status' => 'error', 'message' => 'Invalid request method.'));
}

// Close the database connection
$conn->close();
?>
