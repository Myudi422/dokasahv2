<?php
date_default_timezone_set('Asia/Jakarta');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');


// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";  // Harap ganti dengan password asli Anda
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle error report
    if (isset($_POST['report']) && $_POST['report'] === 'true' && isset($_POST['platform'])) {
        $platform = $_POST['platform'];
        $sql = "UPDATE cookies SET validasi = 0 WHERE platform = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $platform);
        $stmt->execute();

        echo json_encode(['status' => 'success', 'message' => 'Report has been processed']);
        exit;
    }

    // Fetch cookies based on voucher and token
    $voucher = $_POST['voucher'];
    $token = $_POST['token'];
    
    $sql = "SELECT kupon, expiry_date, token, server FROM devices WHERE kupon = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $voucher);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $deviceData = $result->fetch_assoc();
        $currentTimestamp = time();

        if ($currentTimestamp <= strtotime($deviceData['expiry_date'])) {
            if ($deviceData['token'] === null) {
                $updateTokenSQL = "UPDATE devices SET token = ? WHERE kupon = ?";
                $updateTokenStmt = $conn->prepare($updateTokenSQL);
                $updateTokenStmt->bind_param("ss", $token, $voucher);
                $updateTokenStmt->execute();
            }
            if ($deviceData['token'] === $token || $deviceData['token'] === null) {
                $expiryTimestamp = strtotime($deviceData['expiry_date']);
                $remainingTime = $expiryTimestamp - $currentTimestamp;

                $sql = "SELECT website, cookie_data, platform, kode, server, timestamp, validasi FROM cookies WHERE server = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $deviceData['server']);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $cookies = array();
                    while ($row = $result->fetch_assoc()) {
                        $cookies[] = array(
                            'website' => $row['website'],
                            'cookie_data' => json_decode($row['cookie_data']),
                            'remaining_time' => $remainingTime,
                            'platform' => $row['platform'],
                            'timestamp' => $row['timestamp'],
                            'kode' => $row['kode'],
                            'validasi' => $row['validasi']
                        );
                    }
                    echo json_encode(['status' => 'success', 'data' => $cookies, 'server' => $deviceData['server']]);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'No cookies found for the server']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid device or token']);
                exit;
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Voucher has expired']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid voucher']);
    }

    if (isset($_POST['logout']) && $_POST['logout'] === 'true') {
        $voucher = $_POST['voucher'];
        $sql = "UPDATE devices SET token = NULL WHERE kupon = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $voucher);
        $stmt->execute();

        echo json_encode(['status' => 'success', 'message' => 'Logged out successfully']);
    }
}

$conn->close();
?>
