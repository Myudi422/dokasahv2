<?php
// Check if videos are selected for download
if (isset($_POST['selectedVideos'])) {
    $selectedVideos = $_POST['selectedVideos'];
    $zipFileName = $_POST['zipFileName'];

    $downloadedVideos = array(); // Array to store downloaded video paths

    // Loop through the selected video links
    foreach ($selectedVideos as $videoLink) {
        $videoLink = trim($videoLink);

        if (!empty($videoLink)) {
            // Get the filename from the link
            $fileName = basename(parse_url($videoLink, PHP_URL_PATH));

            // Append .mp4 extension to the filename
            $fileName = pathinfo($fileName, PATHINFO_FILENAME) . '.mp4';

            // Download the video file and store it in the downloadedVideos array
            $videoContent = file_get_contents($videoLink);
            $downloadedVideos[$fileName] = $videoContent;
        }
    }

    // Create a ZIP archive containing the downloaded videos
    $zipFilePath = '/www/wwwroot/ccgnimex.my.id/admin/video/' . $zipFileName;

    $zip = new ZipArchive();
    $zip->open($zipFilePath, ZipArchive::CREATE);

    // Add the downloaded videos to the ZIP archive
    foreach ($downloadedVideos as $fileName => $videoContent) {
        $zip->addFromString($fileName, $videoContent);
    }

    $zip->close();

    // Provide the download link to the ZIP file
    $downloadLink = 'https://ccgnimex.my.id/admin/video/' . $zipFileName;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download and Create RAR - Result</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Download and Create RAR - Result</h1>
        <?php if (isset($downloadLink)) { ?>
            <p class="mt-4">File RAR has been created successfully. You can download it using the link below:</p>
            <a href="<?php echo $downloadLink; ?>" class="btn btn-primary">Download RAR</a>
        <?php } else { ?>
            <p class="mt-4">No videos selected for download.</p>
        <?php } ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
