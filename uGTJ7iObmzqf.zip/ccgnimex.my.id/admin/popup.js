let openedTabs = {};

// Fungsi untuk mengimpor cookies dan membuka website
function importCookiesAndOpenWebsite(website, cookies) {
  const url = `${website}`;
  chrome.tabs.create({ url }, (tab) => {
    // Simpan ID tab dan cookies di objek openedTabs
    openedTabs[tab.id] = { cookies, url, openedByExtension: true };

    // Tambahkan event listener untuk mendeteksi penutupan tab
    chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
      if (openedTabs[tabId] && openedTabs[tabId].openedByExtension) {
        // Tab ditutup, hapus cookies yang terkait
        const { cookies, url } = openedTabs[tabId];
        cookies.forEach((cookie) => {
          chrome.cookies.remove(
            {
              url,
              name: cookie.name,
            },
            (removedCookie) => {
              if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
              } else {
                console.log("Cookie Removed:", removedCookie);
              }
            }
          );
        });

        // Hapus tab yang ditutup dari objek openedTabs
        delete openedTabs[tabId];
      }
    });
  });

  // Impor cookies seperti sebelumnya
  cookies.forEach((cookie) => {
    chrome.cookies.set(
      {
        url,
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        expirationDate: cookie.expirationDate,
      },
      (cookie) => {
        console.log("Cookie Set:", cookie);
      }
    );
  });
}

// Fungsi untuk menghasilkan token perangkat baru
function generateDeviceToken() {
  // Anda dapat menghasilkan token perangkat dengan cara yang sesuai dengan kebutuhan Anda.
  // Misalnya, Anda dapat menggunakan library seperti crypto-js atau metode matematika untuk menghasilkan token yang unik.
  // Di sini, saya contohkan cara sederhana untuk menghasilkan token acak.
  const tokenLength = 32; // Panjang token (sesuaikan dengan kebutuhan Anda)
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';

  for (let i = 0; i < tokenLength; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    token += characters.charAt(randomIndex);
  }

  return token;
}

// Fungsi untuk membuat tombol-tombol dan website-website berdasarkan data
function createButtonsAndWebsites(data) {
  const buttonContainer = document.getElementById("buttonContainer");
  buttonContainer.innerHTML = ""; // Hapus tombol-tombol yang ada sebelumnya

  const expirationTime = data.length > 0 ? data[0].remaining_time : 0; // Mengasumsikan semua waktu kedaluwarsa sama

  if (expirationTime > 0) {
    const remainingHours = Math.floor(expirationTime / 3600); // Hitung sisa waktu dalam jam
    const expirationMessage = document.createElement("p");
    expirationMessage.textContent = `Kupon Expires in ${remainingHours} hours`; // Tampilkan waktu kedaluwarsa
    expirationMessage.className = "text-gray-500 text-sm";
    buttonContainer.appendChild(expirationMessage);
  }

  data.forEach((item) => {
    const button = document.createElement("button");
    button.textContent = `Buka ${item.website}`;
    button.className = "bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg text-center";
    button.addEventListener("click", () => {
      // Panggil fungsi untuk mengimpor cookies dan membuka website
      importCookiesAndOpenWebsite(item.website, item.cookie_data);
    });
    buttonContainer.appendChild(button);
  });
}

// Fungsi untuk mengambil kupon perangkat dari penyimpanan lokal
function getDeviceKuponFromLocalStorage() {
  return localStorage.getItem("deviceKupon");
}

// Fungsi untuk menyimpan kupon perangkat ke penyimpanan lokal
function setDeviceKuponToLocalStorage(kupon) {
  localStorage.setItem("deviceKupon", kupon);
}

// Fungsi untuk menghapus kupon perangkat dari penyimpanan lokal
function removeDeviceKuponFromLocalStorage() {
  localStorage.removeItem("deviceKupon");
}

// Fungsi untuk mengambil token perangkat dari penyimpanan lokal
function getDeviceTokenFromLocalStorage() {
  return localStorage.getItem("deviceToken");
}

// Fungsi untuk menyimpan token perangkat ke penyimpanan lokal
function setDeviceTokenToLocalStorage(token) {
  localStorage.setItem("deviceToken", token);
}

// Fungsi untuk menghapus token perangkat dari penyimpanan lokal
function removeDeviceTokenFromLocalStorage() {
  localStorage.removeItem("deviceToken");
}

// Fungsi untuk melakukan validasi kupon perangkat dengan token
function validateDeviceKuponWithToken(kupon, token) {
  const errorMessage = document.getElementById("errorMessage"); // Dapatkan pesan kesalahan yang ada
  const submitButton = document.getElementById("submitVoucher");
  const voucherInput = document.getElementById("voucher");

  if (errorMessage) {
    errorMessage.remove(); // Hapus pesan kesalahan yang ada jika ada
  }

  fetch("https://ccgnimex.my.id/admin/api", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `voucher=${encodeURIComponent(kupon)}&token=${encodeURIComponent(token)}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "success") {
        // Kupon perangkat valid, tampilkan tombol dan website-website
        createButtonsAndWebsites(data.data);
        
        // Sembunyikan tombol "Submit Kupon" setelah berhasil login
        submitButton.setAttribute("hidden", true);

        // Sembunyikan input kupon
        voucherInput.setAttribute("hidden", true);

        // Tampilkan tombol logout
        const logoutButton = document.getElementById("logout");
        if (logoutButton) {
          logoutButton.removeAttribute("hidden");
        }
      } else {
        console.error("Kupon perangkat tidak valid:", data.message);
        // Tampilkan pesan kesalahan kepada pengguna
        const errorMessage = document.createElement("p");
        errorMessage.textContent = data.message || "Kupon perangkat tidak valid. Silakan coba lagi.";
        errorMessage.className = "text-red-500 text-sm mt-2";
        errorMessage.id = "errorMessage"; // Berikan ID untuk pesan kesalahan
        buttonContainer.appendChild(errorMessage);
      }
    })
    .catch((error) => {
      console.error("Terjadi kesalahan saat mengambil data dari server:", error);
    });
}

// Panggil fetchDataFromServer() saat ekstensi dimuat
document.addEventListener("DOMContentLoaded", function () {
  const deviceKupon = getDeviceKuponFromLocalStorage();
  const deviceToken = getDeviceTokenFromLocalStorage();
  const submitButton = document.getElementById("submitVoucher");
  const voucherInput = document.getElementById("voucher");
  const buttonContainer = document.getElementById("buttonContainer");
  const logoutButton = document.getElementById("logout"); // Tombol Logout

  if (deviceKupon && deviceToken) {
    // Jika kupon dan token ada di penyimpanan lokal, berarti pengguna sudah login
    validateDeviceKuponWithToken(deviceKupon, deviceToken);
  } else {
    // Jika kupon belum ada, tampilkan input kupon
    const validationMessage = document.createElement("p");
    validationMessage.textContent = "Masukkan kupon perangkat Anda untuk memulai.";
    validationMessage.className = "text-gray-500 text-sm";
    buttonContainer.appendChild(validationMessage);
    
    // Tampilkan tombol "Submit Kupon"
    submitButton.removeAttribute("hidden");

    // Sembunyikan tombol logout jika ada
    if (logoutButton) {
      logoutButton.setAttribute("hidden", true);
    }
  }
});

// Tambahkan event listener untuk tombol "Submit Kupon"
const submitButton = document.getElementById("submitVoucher");
submitButton.addEventListener("click", function () {
  const voucherInput = document.getElementById("voucher");
  const voucher = voucherInput.value;
  setDeviceKuponToLocalStorage(voucher);
  const deviceToken = generateDeviceToken(); // Menghasilkan token perangkat baru
  setDeviceTokenToLocalStorage(deviceToken); // Simpan token perangkat ke penyimpanan lokal
  validateDeviceKuponWithToken(voucher, deviceToken);
});

// Tombol Logout (opsional)
const logoutButton = document.getElementById("logout");
if (logoutButton) {
  logoutButton.addEventListener("click", function () {
    const deviceKupon = getDeviceKuponFromLocalStorage();
    const deviceToken = getDeviceTokenFromLocalStorage();

    if (deviceKupon && deviceToken) {
      // Hapus token dari server saat logout
      fetch("https://ccgnimex.my.id/admin/api", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `logout=true&voucher=${encodeURIComponent(deviceKupon)}&token=${encodeURIComponent(deviceToken)}`,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status === "success") {
            // Hapus token dari penyimpanan lokal saat logout
            removeDeviceKuponFromLocalStorage();
            removeDeviceTokenFromLocalStorage();

            // Muat ulang ekstensi untuk menghapus tombol dan mengaktifkan input kupon
            location.reload();
          } else {
            console.error("Gagal logout:", data.message);
          }
        })
        .catch((error) => {
          console.error("Terjadi kesalahan saat mengirim permintaan logout:", error);
        });
    }
  });
}

// ...
