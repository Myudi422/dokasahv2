<?php
$host = '127.0.0.1';
$user = 'ccgnimex';
$password = 'aaaaaaac';
$dbname = 'ccgnimex';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$sql = 'SELECT anime_id FROM batch';
$result = $conn->query($sql);

$animeIds = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $animeIds[] = $row['anime_id'];
    }
}




$conn->close();
?>

<div id="anime-list"></div>
<br>
<div class="button-container">
  <button id="prev-button">Prev</button>
  <button id="next-button">Next</button>
</div>

<style>
.button-container {
  text-align: center;
}

.button-container button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.button-container button:hover {
  background-color: #0069d9;
}

#anime-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  grid-gap: 10px;
}

@media screen and (max-width: 600px) {
  #anime-list {
    grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
  }
}
.animex-item {
  position: relative;
}

.animex-item img {
  width: 100%;
}

.animex-title {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.8);
  color: white;
  padding:10px;
text-align:center;
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
}

.animex-rating {
  position: absolute;
  top: 5px;
  right: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
}

.animex-star {
    margin-right:0px;
    color:yellow;
    vertical-align: middle;
}

.animex-rating span + span {
    vertical-align: middle;
}

@media screen and (max-width: 600px) {
    .animex-rating {
        font-size: 12px;
        padding: 3px;
        border-radius: 3px;
    }
}

.animex-info {
  position: absolute;
  top: 5px;
  left: 35px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
}

.animex-info:hover {
  background-color: #007bff;
}

.animex-info i {
  font-size: 16px;
}
.animex-info-no-trailer {
  left: 5px;
}
</style>

<script>
const query = `
query ($id_in: [Int], $page: Int, $perPage: Int) {
  Page (page: $page, perPage: $perPage) {
    pageInfo {
      total
      currentPage
      lastPage
      hasNextPage
      perPage
    }
    media (id_in: $id_in, type: ANIME, status: FINISHED, sort: POPULARITY_DESC) {
      id
      title {
        romaji
        english
        native
      }
      coverImage {
        large
      }
      trailer {
        id
        site
        thumbnail
      }
      averageScore
      description(asHtml:false)
      genres
      format
      episodes
      season
      status
      studios(isMain:true){
          nodes{
              name
          }
      }
      relations{
          edges{
              relationType(version:2)
              node{
                  title{
                      romaji
                  }
                  type
              }
          }
      }
    }
  }
}
`;

const variables = {
    page:1,
    perPage :6,
    id_in:<?php echo json_encode($animeIds); ?>
};


const url = 'https://graphql.anilist.co';

async function fetchData() {
    const response = await fetch(url,{
        method:'POST',
        headers:{
            'Content-Type':'application/json',
            'Accept':'application/json',
        },
        body : JSON.stringify({
            query,
            variables,
        }),
    });
    const data = await response.json();
    return data;
}

async function renderData() {
    const data = await fetchData();
    const animeList = data.data.Page.media;
    const container = document.querySelector('#anime-list');
    container.innerHTML = '';
    animeList.forEach(anime => {
        const animeElement = document.createElement('div');
        animeElement.classList.add('animex-item');
        let title = anime.title.romaji;
        if (title.length > 24) {
            title = title.substring(0, 24) + '...';
        }

// Tambahkan ikon trailer jika anime memiliki trailer
let trailerIcon = '';
if (anime.trailer) {
    trailerIcon = `
        <a class="popup-youtube" href="https://www.youtube.com/watch?v=${anime.trailer.id}" target="_blank">
            <div class="animex-trailer">
                <i class="fas fa-film"></i>
            </div>
        </a>
    `;
}

// Tambahkan ikon info
let infoIcon = '';
if (anime.trailer) {
    infoIcon = `
        <div class="animex-info">
            <i class="fas fa-info-circle"></i>
        </div>
    `;
} else {
    infoIcon = `
        <div class="animex-info animex-info-no-trailer">
            <i class="fas fa-info-circle"></i>
        </div>
    `;
}

animeElement.innerHTML = `
    <img src="${anime.coverImage.large}" alt="${anime.title.romaji}">
    ${trailerIcon}
    ${infoIcon}
    <div class="animex-title">${title}</div>
    <div class="animex-rating">
        <span class="animex-star">★</span>
        ${anime.averageScore}
    </div>
`;
async function translateText(text) {
    const response = await fetch(`translate.php?text=${encodeURIComponent(text)}`);
    const data = await response.json();
    return data.translatedText;
}

// Tambahkan event listener ke ikon info
const infoElement = animeElement.querySelector('.animex-info');
infoElement.onclick = async event => {
    event.stopPropagation();
    // Tampilkan modal Bootstrap 5 dengan informasi anime
    const modalElement = document.createElement('div');
    modalElement.classList.add('modal', 'fade');
    modalElement.tabIndex = -1;
    let prequel = '';
    let sequel = '';
    anime.relations.edges.forEach(edge => {
        if (edge.relationType === 'PREQUEL') {
            prequel += edge.node.title.romaji + ' ';
        } else if (edge.relationType === 'SEQUEL') {
            sequel += edge.node.title.romaji + ' ';
        }
    });
    let studio = '';
    anime.studios.nodes.forEach(node => {
        studio += node.name + ' ';
    });
    let translatedDescription = await translateText(anime.description);
    if (translatedDescription.length > 100) {
        translatedDescription = translatedDescription.substring(0, 100) + '...';
    }
    modalElement.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${anime.title.romaji}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table">
                        <tr>
                            <th>Sinopsis</th>
                            <td>${translatedDescription}</td>
                        </tr>
                        <tr>
                            <th>Genre</th>
                            <td>${anime.genres.join(', ')}</td>
                        </tr>
                        <tr>
                            <th>Format</th>
                            <td>${anime.format}</td>
                        </tr>
                        <tr>
                            <th>Episode</th>
                            <td>${anime.episodes}</td>
                        </tr>
                        <tr>
                            <th>Season</th>
                            <td>${anime.season}</td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>${anime.status}</td>
                        </tr>
                        <tr>
                            <th>Studio</th>
                            <td>${studio}</td>
                        </tr>                        
                        <tr>
                            <th>Prequel</th>
                            <td>${prequel}</td>
                        </tr>                        
                        <tr>
                            <th>Sequel</th>
                            <td>${sequel}</td>
                        </tr>                        
                    </table>                
                </div>
            </div>
        </div>`;
    document.body.appendChild(modalElement);
    const modal = new bootstrap.Modal(modalElement);
    modal.show();
};

        // Tambahkan event listener untuk mencegah event bubbling saat ikon trailer diklik
        if (anime.trailer) {
            const trailerElement = animeElement.querySelector('.popup-youtube');
            trailerElement.onclick = event => {
                event.stopPropagation();
            };
        }

        animeElement.onclick = () => {
            window.location.href = `https://ccgnimex.my.id/anime_detail.php?id=${anime.id}`;
        };

        container.appendChild(animeElement);
    });

    
    // Perbarui tampilan tombol prev dan next
    const pageInfo = data.data.Page.pageInfo;
    const prevButton = document.querySelector('#prev-button');
    const nextButton = document.querySelector('#next-button');
    if (pageInfo.currentPage === 1) {
        prevButton.classList.add('disabled');
    } else {
        prevButton.classList.remove('disabled');
    }
    if (pageInfo.currentPage === pageInfo.lastPage) {
        nextButton.classList.add('disabled');
    } else {
        nextButton.classList.remove('disabled');
    }
    
    // Perbarui tampilan jumlah halaman saat ini dan total halaman
    pageIndicator.textContent = `| Page ${pageInfo.currentPage}`;
    
    // Inisialisasi Magnific Popup untuk menampilkan trailer dalam popup
    $('.popup-youtube').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
}
// Tambahkan elemen baru untuk menampilkan jumlah halaman saat ini dan total halaman
const pageIndicator = document.createElement('span');
pageIndicator.id = 'page-indicator';
document.querySelector('.button-container').appendChild(pageIndicator);

document.querySelector('#prev-button').addEventListener('click',()=>{
   if(variables.page>1 && !event.currentTarget.classList.contains('disabled')){
       variables.page-=1;
       renderData();
   } 
});

document.querySelector('#next-button').addEventListener('click',async()=>{
   if(!event.currentTarget.classList.contains('disabled')){
       const data=await fetchData();
       if(data.data.Page.pageInfo.hasNextPage){
           variables.page+=1;
           renderData();
       } 
   }
});

// Tambahkan kelas CSS untuk mengubah tampilan tombol yang dinonaktifkan dan ikon trailer
const style = document.createElement('style');
style.textContent += `
.button-container button.disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.animex-trailer {
  position: absolute;
  top: 5px;
  left: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
}

.animex-trailer:hover {
  background-color: #007bff;
}

.animex-trailer i {
  font-size: 16px;
}
`;
document.head.appendChild(style);

renderData();
</script>