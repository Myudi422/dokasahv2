<!DOCTYPE html>
<html>
<head>
    <title>Kirim Pesan Anime ke Grup</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h1>Kirim Pesan Anime ke Grup</h1>
    <form method="post" action="bot.php">
        <div class="form-group">
            <label for="animeId">ID Anime:</label>
            <input type="text" class="form-control" id="animeId" name="animeId" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select class="form-control" id="status" name="status" required>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
            </select>
        </div>
        <div class="form-group">
            <label for="episode">Episode:</label>
            <input type="number" class="form-control" id="episode" name="episode">
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<?php
if (isset($_POST['submit'])) {
    $botToken = '1920905087:AAG_xCvsdjxVu8VUDt9s4JhD22ND-UIJttQ'; // Replace with your bot token
    $animeId = (int)$_POST['animeId'];
    $status = $_POST['status'];
    $episode = (int)$_POST['episode'];

    if ($status === 'ongoing') {
        $groupId = '-1001519273319'; // ID for ongoing anime group
        $replyMessage = 67737;
        $watchUrl = "https://ccgnimex.my.id/streaming?id={$animeId}&episode={$episode}";
        $caption = "Episode: {$episode} - {$title} Sudah Tersedia !!";
    } elseif ($status === 'completed') {
        $groupId = '-1001519273319'; // ID for completed anime group
        $replyMessage = 72750;
        $watchUrl = "https://ccgnimex.my.id/anime_detail?id={$animeId}#";
        $caption = "Batch {$title} Sudah tersedia untuk didownload !!";
    }

    // Mengambil data anime menggunakan GraphQL
    $apiUrl = 'https://graphql.anilist.co';
    $query = <<<'GRAPHQL'
        query ($animeId: Int) {
            Media (id: $animeId, type: ANIME) {
                title {
                    romaji
                }
                averageScore
                genres
                coverImage {
                    large
                }
            }
        }
GRAPHQL;

    $variables = json_encode(['animeId' => $animeId]);

    $response = file_get_contents($apiUrl, false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode([
                'query' => $query,
                'variables' => $variables,
            ]),
        ],
    ]));

    $data = json_decode($response, true);

    if (isset($data['data']['Media'])) {
        // Mendapatkan informasi yang diperlukan dari data anime
        $title = $data['data']['Media']['title']['romaji'];
        $score = $data['data']['Media']['averageScore'];
        $genres = implode(", ", $data['data']['Media']['genres']);
        if (isset($data['data']['Media']['coverImage']['large'])) {
            $imageUrl = "https://img.anili.st/media/{$animeId}";
        } else {
            $imageUrl = $data['data']['Media']['coverImage']['large'];
        }

        // Menghasilkan caption pesan dengan informasi anime dan episode
        $caption .= "\n\nScore: {$score}\nGenre: {$genres}\n";

        // Membentuk data untuk merespon pesan di grup
        $telegramDataReply = array(
            'chat_id' => $groupId,
            'photo' => $imageUrl,
            'caption' => $caption,
            'reply_to_message_id' => $replyMessage,
            'reply_markup' => json_encode(array(
                'inline_keyboard' => array(
                    array(
                        array(
                            'text' => 'Tonton Sekarang',
                            'url' => $watchUrl
                        )
                    )
                )
            ))
        );

        $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendPhoto";

        $optionsReply = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($telegramDataReply)
            )
        );

        // Merespon pesan di grup
        $contextReply = stream_context_create($optionsReply);
        $resultReply = file_get_contents($telegramApiUrl, false, $contextReply);

        if ($resultReply === false) {
            echo '<script>alert("Terjadi kesalahan dalam mengirim pesan.");</script>';
        } else {
            echo '<script>alert("Pesan berhasil dikirim sebagai respon ke pesan di grup.");</script>';
        }
    }
}
?>

</body>
</html>
