<?php
// Redirect to the specified URL
header("Location: https://ccgnimex.my.id/v2");
exit(); // Ensure that no other content is sent
?>

<?php
// Start the session
session_start();



// Import database connection and class
require('db-config.php');

include 'jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};



?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <title>ccgnimex - Streaming dan Download Anime Subtitle Indo</title>
  <meta name="description" content="ccgnimex adalah website streaming dan download anime lengkap dan mudah digunakan.">
  <meta name="keywords" content="streaming anime, download anime, anime lengkap indo, anime sub indo, anime batch indo">
  <meta name="author" content="ccgnimex">
<meta name="google-site-verification" content="A1HYpSm2bOSTfTIoEl8SWJDrh9GWw_22ad73OvrsBWI" />
<link rel="apple-touch-icon" sizes="57x57" href="/icon1/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/icon1/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/icon1/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/icon1/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/icon1/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/icon1/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icon1/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icon1/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/icon1/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/icon1/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/icon1/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/icon1/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icon1/favicon-16x16.png">
<link rel="manifest" href="/icon1/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/icon1/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <style>@media (max-width: 576px) {
  .row {
    display: none;
  }
}</style>
<style>
.popup-cardx {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.popup-contentx {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 80%;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  position: relative;
}

.closex {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 20px;
  font-weight: bold;
  color: #333;
  cursor: pointer;
}
</style>

<script>
function closePopup() {
  var popup = document.querySelector('.popup-cardx');
  popup.style.display = 'none';
}
</script>

<script>
    
    // Mencari semua elemen gambar di halaman
var images = document.getElementsByTagName('img');

// Loop melalui setiap elemen gambar
for (var i = 0; i < images.length; i++) {
  var imageUrl = images[i].src;

  // Cek apakah gambar masih berlaku di localStorage
  var cachedData = localStorage.getItem(imageUrl);
  if (cachedData) {
    var cachedImageData = JSON.parse(cachedData);
    var expirationDate = new Date(cachedImageData.expiration);

    // Periksa apakah gambar sudah kedaluwarsa
    if (expirationDate > new Date()) {
      displayImage(cachedImageData.data);
      continue;
    }
  }

  // Jika gambar tidak ada di localStorage atau sudah kedaluwarsa, muat gambar dari URL
  loadImage(imageUrl);
}

// Fungsi untuk memuat gambar dari URL
function loadImage(url) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.responseType = 'blob';

  xhr.onload = function() {
    if (xhr.status === 200) {
      // Konversi gambar menjadi objek Blob
      var blob = xhr.response;

      // Simpan gambar ke localStorage dengan tanggal kedaluwarsa
      var expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() + 10); // 10 hari kedaluwarsa

      var reader = new FileReader();
      reader.onloadend = function() {
        var imageData = reader.result;
        var cachedData = {
          data: imageData,
          expiration: expirationDate.toISOString()
        };
        localStorage.setItem(url, JSON.stringify(cachedData));
        displayImage(imageData);
      };
      reader.readAsDataURL(blob);
    }
  };

  xhr.send();
}

// Fungsi untuk menampilkan gambar
function displayImage(imageData) {
  var img = document.createElement('img');
  img.src = imageData;
  document.body.appendChild(img);
}

</script>

<?php
// When the user is not logged in, show popup card with login button
if (!isset($_SESSION['logged-in'])) {
    echo '<div class="popup-cardx">';
    echo '<div class="popup-contentx">';
    echo '<span class="closex" onclick="closePopup()">&times;</span>';
    echo '<h3>Akses Diperlukan!</h3>';
    echo '<p><center>Silahkan Login/Buat Akun terlebih dahulu, agar fitur dari website bisa digunakan sepenuhnya.</center></p>';
    echo '<a class="btn btn-primary" href="login.php">Login</a>';
    echo '</div>';
    echo '</div>';
}
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/localforage/1.9.0/localforage.min.js"></script>
<script src="https://alwingulla.com/88/tag.min.js" data-zone="21924" async data-cfasync="false"></script>
</head>

<body id="page-top" class>
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link active" href="#"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="komik"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="kategori.php"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
                                </div>
                            </li>
     <?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

function getAccessToken($clientId, $clientSecret) {
    $tokenUrl = 'https://anilist.co/api/v2/oauth/token';
    
    $postData = array(
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret
    );

    $ch = curl_init($tokenUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['access_token'])) {
        return $data['access_token'];
    } else {
        return null;
    }
}

// Database connection
$db_host = "localhost";
$db_name = "ccgnimex";
$db_user = "ccgnimex";
$db_password = "aaaaaaac";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
if (isset($_SESSION['telegram_id'])) {
    $telegramId = $_SESSION['telegram_id'];

    $sql = "SELECT * FROM notif_anime WHERE telegram_id = $telegramId AND is_read = 0 ORDER BY created_at DESC";
    $result = $conn->query($sql);

    $api_url = "https://graphql.anilist.co/";
?>

<li class="nav-item dropdown no-arrow mx-1">
    <div class="nav-item dropdown no-arrow">
        <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">
            <span class="badge bg-danger badge-counter"><?php echo $result->num_rows; ?></span>
            <i class="fas fa-bell fa-fw"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
            <h6 class="dropdown-header">Alerts Center</h6>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $animeId = $row['anilist_id'];
                    $notificationDate = date('F j, Y', strtotime($row['notification_date']));
                    $episode = $row['episode'];

                    $query = '{
                        Media(id: '.$animeId.', type: ANIME) {
                            id
                            title {
                                romaji
                            }
                            coverImage {
                                medium
                            }
                        }
                    }';

                    $ch = curl_init($api_url);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query]));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $accessToken,
                    ]);

                    $response = curl_exec($ch);
                    curl_close($ch);

                    $data = json_decode($response, true);

                    if (isset($data['data']['Media'])) {
                        $anime = $data['data']['Media'];
                        $title = $anime['title']['romaji'];
                        $coverImage = $anime['coverImage']['medium'];
                    }
            ?>
                    <a class="dropdown-item d-flex align-items-center" href="streaming.php?id=<?php echo $animeId; ?>&episode=<?php echo $episode; ?>" onclick="markAsRead(<?php echo $row['id']; ?>)">
                        <div class="me-3">
                            <img src="<?php echo $coverImage; ?>" alt="Anime Cover" width="40" height="40" class="rounded-circle">
                        </div>
                        <div>
                            <span class="small text-gray-500"><?php echo $notificationDate; ?></span>
                            <p><strong><?php echo $title; ?></strong> (Episode <?php echo $episode; ?>) Sudah Tersedia</p>
                        </div>
                    </a>
            <?php
                }
            } else {
                echo '<p class="dropdown-item text-center small text-gray-500">Tidak ada notifikasi tersedia, silahkan aktifkan notifikasi anime, dihalaman streaming, agar nanti muncul, jika admin update</p>';
            }
            ?>
            <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
        </div>
    </div>
</li>

<script>
function markAsRead(notificationId) {
    $.ajax({
        url: "update_notification.php",
        method: "POST",
        data: { notification_id: notificationId },
        success: function(response) {
            console.log("Notification marked as read");
            // Atur tampilan notifikasi sesuai keinginan Anda
        },
        error: function(error) {
            console.error("Error updating notification:", error);
        }
    });
}
</script>

<?php
    $conn->close();
} else {
}
?>


                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">Hai, <?php echo $first_name . ' ' . $last_name; ?> <?= $NAMA ?></h3>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-primary py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>User Web & Bot</span></div>
                                            <div class="text-dark fw-bold h5 mb-0"><span><?php echo $web; ?> | <?php echo $bot; ?></span></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-success py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
    <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>Anime Tersedia</span></div>
    <div class="text-dark fw-bold h5 mb-0"><span><?php echo $jumlahanime; ?> Anime</span></div>
</div>
                                        <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-info py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-info fw-bold text-xs mb-1"><span>Ongoing</span></div>
                                            <div class="row g-0 align-items-center">
                                                <div class="col-auto">
                                                    <div class="text-dark fw-bold h5 mb-0 me-3"><span>50%</span></div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar bg-info" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;"><span class="visually-hidden">50%</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-warning py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-warning fw-bold text-xs mb-1"><span>Requestan User</span></div>
                                            <div class="text-dark fw-bold h5 mb-0"><span>18</span></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<div class="card mb-3" style="margin-bottom: calc(1.5rem + 10px) !important;">
  <div class="card-header" id="Riwayat">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Informasi</strong>
      <div class="dropdown"> 
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
          Riwayat Tontonan
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
              <li><a class="dropdown-item" href="#" onclick="r_bot(); return false;">Bot</a></li>
          <li><a class="dropdown-item" href="#" onclick="r_web(); return false;">Web</a></li>
        </ul>
      </div>
    </div>
  </div>
    <div id="content-container1" class="card-body">
    <?php  echo '<div class="text-center mt-3">';
    echo '<p><i class="fas fa-clock"></i> <strong>Silahkan share web ccgnimex ke teman-teman kalian agar project ini tetap dilanjut!</strong></p>';?>
    <script type='text/javascript' src='https://assets.trakteer.id/js/trbtn-overlay.min.js'></script><script type='text/javascript' class='troverlay'>(function() {var trbtnId = trbtnOverlay.init('Dukung Kami','#2196F3','https://trakteer.id/ccgnimeX/tip/embed/modal','https://cdn.trakteer.id/images/embed/trbtn-icon.png','40','inline');trbtnOverlay.draw(trbtnId);})();</script>
  </div>
</div>
</div>

<script>
  function r_bot() {
  $('#dropdownMenuButton1').html('Bot');
  $('#Riwayat strong').text('Riwayat Tontonan');
  $.ajax({
    url: "riwayat_bot.php",
    success: function(result){
      $("#content-container1").html(result);
    }
  });
  return false;
}

function r_web() {
  $('#dropdownMenuButton1').html('Web');
 $('#Riwayat strong').text('Riwayat Tontonan');
  $.ajax({
    url: "riwayat_web.php",
    success: function(result){
      $("#content-container1").html(result);
    }
  });
  return false;
}
  
</script>
                    
<?php
// Check if a search query was submitted
if (isset($_GET['search'])) {
    // Get the search query from the URL parameter
    $search_query = $_GET['search'];
    ?>
    <div class="card mb-3" style="margin-bottom: calc(1.5rem + 10px) !important;">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <?php
                // Change the text to "Hasil penelusuran" and display the search query
                echo '<span>Hasil penelusuran: ' . htmlspecialchars($search_query) . '</span>';
                ?>
                <i class="fas fa-male"></i>
            </div>
        </div>
        <div class="card-body">
            <?php
            // Include the cari.php file
            include 'cari.php';
            ?>
        </div>
    </div>
    <?php
}
?>


<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Anime Tersedia</strong>
      <div class="dropdown"> 
        <button class="btn btn-secondary dropdown-toggle" type="button" id="animeDropdownButton" data-bs-toggle="dropdown" aria-expanded="false">
          Pilih Tipe
        </button>
        <ul class="dropdown-menu" aria-labelledby="animeDropdownButton">
          <li><a class="dropdown-item" href="#" onclick="loadOngoing(); return false;">Ongoing</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadWebAnime(); return false;">Tamat | Web</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadPagAnime(); return false;">Tamat | Bot</a></li>
        </ul>
      </div>
    </div>
  </div>

  <!-- Container for Anime content -->
  <div id="animeContainer" class="card-body">
    <?php include 'ongoing.php'; ?>
  </div>
</div>

<!-- AJAX script to dynamically load anime content -->
<script>
  function loadWebAnime() {
    $('#animeDropdownButton').html('Tamat | Web');
    $.ajax({
      url: "web_anime.php",
      success: function(result){
        $("#animeContainer").html(result);
      }
    });
    return false;
  }
  
  function loadOngoing() {
    $('#animeDropdownButton').html('Ongoing');
    $.ajax({
      url: "ongoing.php",
      success: function(result){
        $("#animeContainer").html(result);
      }
    });
    return false;
  }
  
  function loadPagAnime() {
    $('#animeDropdownButton').html('Tamat | Bot');
    $.ajax({
      url: "pag_anime.php",
      success: function(result){
        $("#animeContainer").html(result);
      }
    });
    return false;
  }
</script>

<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Tipe Tersedia</strong>
      <div class="dropdown"> 
        <button class="btn btn-secondary dropdown-toggle" type="button" id="mediaDropdownButton" data-bs-toggle="dropdown" aria-expanded="false">
          Pilih Tipe
        </button>
        <ul class="dropdown-menu" aria-labelledby="mediaDropdownButton">
          <li><a class="dropdown-item" href="#" onclick="loadMovies(); return false;">Movies</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadSeries(); return false;">Series (TV)</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadOva(); return false;">Ova</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadOna(); return false;">Ona</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadSpecial(); return false;">Special</a></li>
        </ul>
      </div>
    </div>
  </div>

    <!-- Container for Movie content -->
  <div id="movieContainer" class="card-body">
    <div class="text-center mt-3">
      <p><i class="fas fa-wifi"></i> <strong>Klik pilihan yang tersedia yang ingin dibuka</strong></p>
    </div>
    <div class="col-12 text-center">
      <button class="btn btn-secondary btn-block mb-2" onclick="loadMedia('Movies');">Movies</button>
      <button class="btn btn-secondary btn-block mb-2" onclick="loadMedia('Series');">Series (TV)</button>
      <button class="btn btn-secondary btn-block mb-2" onclick="loadMedia('Ova');">Ova</button>
      <button class="btn btn-secondary btn-block mb-2" onclick="loadMedia('Ona');">Ona</button>
      <button class="btn btn-secondary btn-block mb-2" onclick="loadMedia('Special');">Special</button>
    </div>
  </div>
</div>

<!-- AJAX script to dynamically load media content -->
<script>
  function loadMedia(mediaType) {
    // Set the dropdown button text to the selected media type
    $('#mediaDropdownButton').html(mediaType);
    
    // Determine the URL for the PHP file based on the selected media type
    var url;
    switch (mediaType) {
      case 'Movies':
        url = 'anime_movie.php';
        break;
      case 'Series':
        url = 'anime_tv.php';
        break;
      case 'Ova':
        url = 'anime_ova-type.php';
        break;
      case 'Ona':
        url = 'anime_ona-type.php';
        break;
      case 'Special':
        url = 'anime_spesial.php';
        break;
    }

    // Make an AJAX request to load the selected media content
    $.ajax({
      url: url,
      success: function(result) {
        $("#movieContainer").html(result);
      }
    });
  }
</script>
<!-- AJAX script to dynamically load movie.php or series.php content -->
<script>
  function loadMovies() {
    $('#mediaDropdownButton').html('Movies');
    $.ajax({
      url: "anime_movie.php",
      success: function(result){
        $("#movieContainer").html(result);
      }
    });
    return false;
  }
  
  function loadSeries() {
    $('#mediaDropdownButton').html('Series');
    $.ajax({
      url: "anime_tv.php",
      success: function(result){
        $("#movieContainer").html(result);
      }
    });
    return false;
  }
  
  function loadOva() {
    $('#mediaDropdownButton').html('Ova');
    $.ajax({
      url: "anime_ova-type.php",
      success: function(result){
        $("#movieContainer").html(result);
      }
    });
    return false;
  }

  function loadOna() {
    $('#mediaDropdownButton').html('Ona');
    $.ajax({
      url: "anime_ona-type.php",
      success: function(result){
        $("#movieContainer").html(result);
      }
    });
    return false;
  }
  
  function loadSpecial() {
    $('#mediaDropdownButton').html('Special');
    $.ajax({
      url: "anime_spesial.php",
      success: function(result){
        $("#movieContainer").html(result);
      }
    });
    return false;
  }
  
</script>




        <div class="card mb-3" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Anime Terbaik</strong>
      <i class="fas fa-male"></i>
    </div>
  </div>
      <?php
      include 'top_anime.php';
      ?>
            </div>
            </div>
            
<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Berita Terbaru</strong>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="mediaDropdownButton" data-bs-toggle="dropdown" aria-expanded="false">
          Pilih Tipe
        </button>
        <ul class="dropdown-menu" aria-labelledby="mediaDropdownButton">
          <li><a class="dropdown-item" href="#" onclick="loadBerita(); return false;">Proses</a></li>
          <li><a class="dropdown-item" href="#" onclick="loadBerita(); return false;">Proses</a></li>
        </ul>
      </div>
    </div>
  </div>

  <!-- Container for Movie content -->
  <div id="beritaContainer" class="card-body">
  <?php
  // Set the URL of the website you want to scrape
  $url = 'https://animenewsplus.net/';

  // Use cURL to get the HTML content of the website
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $html = curl_exec($ch);
  curl_close($ch);

  // Create a new DOMDocument and load the HTML content
  $dom = new DOMDocument();
  @$dom->loadHTML($html);

  // Use DOMXPath to query the DOM and get the elements you want
  $xpath = new DOMXPath($dom);
  $containers = $xpath->query('//div[contains(@class, "td_block_wrap")]');

  $targetContainer = null;
  foreach ($containers as $container) {
    // Check if the container has the necessary attributes or elements
    $classAttr = $container->getAttribute("class");
    if (strpos($classAttr, "td_flex_block_1") !== false &&
        strpos($classAttr, "td_with_ajax_pagination") !== false &&
        strpos($classAttr, "td-pb-border-top") !== false &&
        strpos($classAttr, "td_block_template_8") !== false &&
        strpos($classAttr, "td_flex_block") !== false) {
      // Found the target container
      $targetContainer = $container;
      break;
    }
  }

  if ($targetContainer) {
    $images = $xpath->query('.//div[@class="td-module-thumb"]/a/span/@data-img-url', $targetContainer);
    $categories = $xpath->query('.//div[@class="td-module-meta-info"]/a', $targetContainer);
    $titles = $xpath->query('.//h3[@class="entry-title td-module-title"]/a', $targetContainer);
    $dates = $xpath->query('.//div[@class="td-editor-date"]/span/span/time', $targetContainer);


    // Rest of your code to display the scraped data
} else {
    echo "Container element not found.";
}

    echo '
    <style>
      .card-columns {
        column-count: 1;
      }

      @media (min-width: 576px) {
        .card-columns {
          column-count: 2;
        }
      }

      @media (min-width: 768px) {
        .card-columns {
          column-count: 3;
        }
      }

      @media (min-width: 992px) {
        .card-columns {
          column-count: 4;
        }
      }

      @media (min-width: 1200px) {
        .card-columns {
          column-count: 5;
        }
      }

      .card {
        margin-bottom: 1rem;
        overflow: hidden;
      }

      .card-img-top {
        height: 200px;
        object-fit: cover;
      }

      .card-title {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 0.5rem;
      }

      .card-text {
        font-size: 14px;
        margin-bottom: 0.5rem;
      }

      .card-footer {
        font-size: 12px;
        color: #6c757d;
        background-color: #f8f9fa;
        border-top: 1px solid #dee2e6;
      }
    </style>
    <script>
      function toggleTitle(event) {
        var titleElement = event.target.parentNode.querySelector(".card-title");
        if (titleElement.style.whiteSpace === "normal") {
          titleElement.style.whiteSpace = "nowrap";
        } else {
          titleElement.style.whiteSpace = "normal";
        }
      }
    </script>
    <div class="card-columns">';

    for ($i = 0; $i < $images->length; $i++) {
      $image = htmlspecialchars($images->item($i)->nodeValue);
      $category = htmlspecialchars($categories->item($i)->nodeValue);
      $title = htmlspecialchars($titles->item($i)->nodeValue);
      $link = htmlspecialchars($titles->item($i)->getAttribute('href'));
      $date = htmlspecialchars($dates->item($i)->textContent);

      echo '
      <div class="card">
        <img src="' . $image . '" class="card-img-top" alt="' . $title . '" onclick="toggleTitle(event)">
        <div class="card-body">
          <h5 class="card-title" title="' . $title . '" onclick="toggleTitle(event)">' . $title . '</h5>
          <p class="card-text">' . $category . '</p>
          <a href="berita.php?url=' . urlencode($link) . '&title=' . urlencode($title) . '" class="btn btn-primary">Baca Artikel</a>
        </div>
        <div class="card-footer">
          ' . htmlspecialchars($date) . '
        </div>
      </div>';
    }

    echo '</div>';
    ?>
  </div>
</div>



<!-- AJAX script to dynamically load movie.php or series.php content -->
<script>
  function loadBerita() {
    $('#mediaDropdownButton').html('Movies');
    $.ajax({
      url: "anime_movie.php",
      success: function(result){
        $("#beritaContainer").html(result);
      }
    });
    return false;
  }
  
  function loadBerita() {
    $('#mediaDropdownButton').html('Series');
    $.ajax({
      url: "anime_tv.php",
      success: function(result){
        $("#beritaContainer").html(result);
      }
    });
    return false;
  }
</script>
</div>
<style>.card-body {
    max-width: 100%;
    overflow: hidden;
}
.owl-carousel {
            max-width: 100%;
            margin: 0 auto;
        }
@media (max-width: 600px) {
    .owl-carousel {
        max-width: 90%;
    }
}
        </style>
                  
            </div>
            <div class="position-fixed bottom-0 start-0 p-3" style="z-index: 5">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#telegramModal">
        <i class="fas fa-comment"></i>
    </button>
</div>

<div class="modal fade" id="telegramModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body"></div>
        </div>
    </div>
</div>

<script>
    var telegramModal = document.getElementById('telegramModal')
    var modalBody = telegramModal.querySelector('.modal-body')

    telegramModal.addEventListener('hidden.bs.modal', function (event) {
        modalBody.innerHTML = ''
    })

    telegramModal.addEventListener('show.bs.modal', function (event) {
        var script = document.createElement('script')
        script.async = true
        script.src = 'https://telegram.org/js/telegram-widget.js?21'
        script.setAttribute('data-telegram-discussion', 'otakuindonew/1')
        script.setAttribute('data-comments-limit', '3')
        script.setAttribute('data-height', '400')
        script.setAttribute('data-colorful', '1')
        modalBody.appendChild(script)
    })
</script>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © ccgnimex</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script>$(document).ready(function() {
    // Collapse the sidebar upon page load
    $("#sidebarToggle").trigger("click");
});</script>

<script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', 'update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', 'retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>

<script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>
